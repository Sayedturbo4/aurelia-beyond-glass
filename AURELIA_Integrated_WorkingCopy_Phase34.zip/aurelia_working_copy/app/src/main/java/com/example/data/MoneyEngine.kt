package com.example.data

import java.math.BigInteger
import java.text.NumberFormat
import java.util.Locale

/**
 * Exact money helpers for the Android prototype.
 *
 * Persisted values remain Long minor units. All parsing, formatting and arithmetic
 * avoid Float/Double. Operations fail explicitly on overflow instead of wrapping.
 */
object MoneyEngine {
    private val TEN = BigInteger.TEN

    data class TransferBalances(
        val sourceBalanceMinorUnits: Long,
        val destinationBalanceMinorUnits: Long,
    )

    fun scaleFor(currencyCode: String): Int = when (currencyCode.uppercase(Locale.ROOT)) {
        "JPY" -> 0
        "KWD" -> 3
        else -> 2
    }

    fun parseMajorToMinor(input: String, currencyCode: String): Long {
        val scale = scaleFor(currencyCode)
        val raw = input.trim()
        require(raw.isNotEmpty()) { "Amount is required" }
        require(Regex("^[+]?(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\\.[0-9]+)?$").matches(raw)) {
            "Enter a valid positive amount"
        }
        val normalized = raw.replace(",", "").removePrefix("+")
        val parts = normalized.split(".", limit = 2)
        val whole = parts[0].toBigInteger()
        val fraction = parts.getOrNull(1).orEmpty()
        require(fraction.length <= scale) {
            "$currencyCode supports up to $scale decimal places"
        }

        val paddedFraction = fraction.padEnd(scale, '0')
        val factor = TEN.pow(scale)
        val minor = whole.multiply(factor).add(
            if (paddedFraction.isEmpty()) BigInteger.ZERO else paddedFraction.toBigInteger()
        )
        return minor.longValueExact()
    }

    fun formatMinor(minorUnits: Long, currencyCode: String, isVisible: Boolean = true): String {
        if (!isVisible) return "••••••"
        val scale = scaleFor(currencyCode)
        val amount = BigInteger.valueOf(minorUnits)
        val negative = amount.signum() < 0
        val absolute = amount.abs()
        val factor = TEN.pow(scale)
        val whole = absolute.divide(factor)
        val fraction = absolute.remainder(factor)

        val integerFormat = NumberFormat.getIntegerInstance(Locale.US).apply {
            isGroupingUsed = true
            maximumFractionDigits = 0
        }
        val wholeText = integerFormat.format(whole)
        val number = if (scale == 0) {
            wholeText
        } else {
            wholeText + "." + fraction.toString().padStart(scale, '0')
        }
        val symbol = when (currencyCode.uppercase(Locale.ROOT)) {
            "BDT" -> "৳"
            "USD" -> "$"
            "EUR" -> "€"
            "GBP" -> "£"
            "INR" -> "₹"
            "SAR" -> "﷼"
            "AED" -> "د.إ"
            "MYR" -> "RM"
            "SGD" -> "S$"
            "CAD" -> "CA$"
            "AUD" -> "AU$"
            "KWD" -> "KD"
            "JPY" -> "¥"
            else -> currencyCode.uppercase(Locale.ROOT)
        }
        return (if (negative) "-$symbol " else "$symbol ") + number
    }

    fun addExact(leftMinor: Long, rightMinor: Long): Long =
        Math.addExact(leftMinor, rightMinor)

    fun subtractExact(leftMinor: Long, rightMinor: Long): Long =
        Math.subtractExact(leftMinor, rightMinor)

    fun validatePositive(amountMinor: Long) {
        require(amountMinor > 0L) { "Amount must be greater than zero" }
    }

    fun validateRepayment(repaymentMinor: Long, outstandingMinor: Long) {
        validatePositive(repaymentMinor)
        require(outstandingMinor >= 0L) { "Outstanding amount cannot be negative" }
        require(repaymentMinor <= outstandingMinor) { "Repayment exceeds outstanding balance" }
    }

    /** Calculates a same-currency transfer. The fee is charged to the source wallet. */
    fun calculateTransferBalances(
        sourceBalanceMinorUnits: Long,
        destinationBalanceMinorUnits: Long,
        amountMinorUnits: Long,
        feeMinorUnits: Long,
    ): TransferBalances {
        validatePositive(amountMinorUnits)
        require(feeMinorUnits >= 0L) { "Transfer fee cannot be negative" }
        val totalDebit = addExact(amountMinorUnits, feeMinorUnits)
        require(sourceBalanceMinorUnits >= totalDebit) { "Insufficient source wallet balance" }
        return TransferBalances(
            sourceBalanceMinorUnits = subtractExact(sourceBalanceMinorUnits, totalDebit),
            destinationBalanceMinorUnits = addExact(destinationBalanceMinorUnits, amountMinorUnits),
        )
    }
}
