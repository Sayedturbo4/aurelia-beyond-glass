package com.example.export

import org.junit.Assert.assertEquals
import org.junit.Test

class FinanceCsvExporterTest {
  @Test fun quotesCommaAndNewline() {
    assertEquals("\"food, home\"", FinanceCsvExporter.escapeCell("food, home"))
    assertEquals("\"line1\nline2\"", FinanceCsvExporter.escapeCell("line1\nline2"))
    assertEquals("\"say \"\"hello\"\"\"", FinanceCsvExporter.escapeCell("say \"hello\""))
  }

  @Test fun prefixesSpreadsheetFormulaTriggers() {
    listOf("=1+1", "+SUM(A1:A2)", "-10+2", "@cmd", "  =1+1", "\t=1+1").forEach { value ->
      assertEquals(true, FinanceCsvExporter.escapeCell(value).startsWith("\"'"))
    }
  }

  @Test fun leavesOrdinaryTextUnchangedAndRemovesNullByte() {
    assertEquals("\"Coffee\"", FinanceCsvExporter.escapeCell("Coffee"))
    assertEquals("\"ab\"", FinanceCsvExporter.escapeCell("a\u0000b"))
  }
}
