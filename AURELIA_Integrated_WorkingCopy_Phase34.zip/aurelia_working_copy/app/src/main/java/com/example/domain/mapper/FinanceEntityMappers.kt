package com.example.domain.mapper

import com.example.data.local.LoanEntity
import com.example.data.local.PersonEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.WalletEntity
import com.example.domain.model.CurrencyWalletSummary
import com.example.domain.model.FinanceTransaction
import com.example.domain.model.FinanceTransactionType
import com.example.domain.model.Loan
import com.example.domain.model.LoanDirection
import com.example.domain.model.Person
import com.example.domain.model.Wallet

fun PersonEntity.toDomain(): Person = Person(
  id = id,
  name = name,
  phone = phone,
  email = email,
  note = note,
  isArchived = isArchived,
)

fun WalletEntity.toDomain(): Wallet = Wallet(
  id = id,
  name = name,
  category = category,
  currencyCode = currencyCode,
  balanceMinorUnits = balanceMinorUnits,
  colorHex = colorHex,
  iconName = iconName,
  isArchived = isArchived,
)

fun LoanEntity.toDomain(personName: String): Loan = Loan(
  id = id,
  personId = personId,
  personName = personName,
  direction = when (type) {
    "LENT" -> LoanDirection.LENT
    "BORROWED" -> LoanDirection.BORROWED
    else -> throw IllegalArgumentException("Unsupported loan type: $type")
  },
  principalMinorUnits = principalMinorUnits,
  repaidMinorUnits = repaidMinorUnits,
  currencyCode = currencyCode,
  openedAtMillis = openedAtMillis,
  dueAtMillis = dueAtMillis,
  note = note,
  isArchived = isArchived,
)

fun TransactionEntity.toDomain(): FinanceTransaction = FinanceTransaction(
  id = id,
  title = title,
  categoryId = categoryId,
  type = when (type) {
    "INCOME" -> FinanceTransactionType.INCOME
    "EXPENSE" -> FinanceTransactionType.EXPENSE
    "TRANSFER" -> FinanceTransactionType.TRANSFER
    "PEOPLE" -> FinanceTransactionType.PEOPLE
    else -> FinanceTransactionType.UNKNOWN
  },
  amountMinorUnits = amountMinorUnits,
  currencyCode = currencyCode,
  walletId = walletId,
  destinationWalletId = destinationWalletId,
  personId = personId,
  occurredAtMillis = occurredAtMillis,
  note = note,
)

/** Keeps balances segregated by currency. Overflow fails loudly instead of corrupting a total. */
fun Iterable<Wallet>.summarizeByCurrency(): List<CurrencyWalletSummary> =
  groupBy { it.currencyCode }
    .map { (currency, wallets) ->
      CurrencyWalletSummary(
        currencyCode = currency,
        walletCount = wallets.size,
        totalBalanceMinorUnits = wallets.fold(0L) { total, wallet -> Math.addExact(total, wallet.balanceMinorUnits) },
      )
    }
    .sortedBy { it.currencyCode }
