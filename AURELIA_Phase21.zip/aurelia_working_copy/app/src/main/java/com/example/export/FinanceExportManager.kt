package com.example.export

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.MoneyEngine
import com.example.data.local.TransactionEntity
import com.example.domain.report.FinanceReport
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Creates local-only report files and shares them through Android's chooser. */
object FinanceExportManager {
  private val dateTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
  private val fileDate = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US)

  fun createCsv(
    context: Context,
    transactions: List<TransactionEntity>,
    rangeLabel: String,
    currencyCode: String,
  ): File {
    val filtered = transactions.filter { row ->
      (row.type == "INCOME" || row.type == "EXPENSE") &&
        (currencyCode == "ALL" || row.currencyCode == currencyCode)
    }.sortedBy { it.occurredAtMillis }

    val rows = mutableListOf(
      listOf("AURELIA Financial Report", rangeLabel, if (currencyCode == "ALL") "All currencies (separate rows)" else currencyCode),
      listOf("Date", "Type", "Title", "Category ID", "Wallet ID", "Amount", "Amount (minor units)", "Currency", "Note"),
    )
    filtered.forEach { row ->
      rows += listOf(
        dateTime.format(Date(row.occurredAtMillis)), row.type, row.title, row.categoryId,
        row.walletId, MoneyEngine.formatMinor(row.amountMinorUnits, row.currencyCode), row.amountMinorUnits.toString(), row.currencyCode, row.note,
      )
    }
    val directory = File(context.cacheDir, "exports").apply { mkdirs() }
    return File(directory, "aurelia_transactions_${fileDate.format(Date())}.csv").apply {
      writeText(FinanceCsvExporter.encode(rows), Charsets.UTF_8)
    }
  }

  fun createPdf(context: Context, report: FinanceReport, rangeLabel: String, currencyCode: String): File {
    val summaries = report.currencySummaries.filter { currencyCode == "ALL" || it.currencyCode == currencyCode }
    val categories = report.categoryExpenses.filter { currencyCode == "ALL" || it.currencyCode == currencyCode }
    val wallets = report.walletSummaries.filter { currencyCode == "ALL" || it.currencyCode == currencyCode }
    val document = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val margin = 42f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 10f }
    var pageNumber = 0
    var page: PdfDocument.Page? = null
    var canvas: android.graphics.Canvas? = null
    var y = 0f

    fun startPage() {
      pageNumber++
      page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
      canvas = page!!.canvas
      y = 52f
      paint.textSize = 18f
      paint.isFakeBoldText = true
      canvas!!.drawText("AURELIA — Financial Report", margin, y, paint)
      paint.isFakeBoldText = false
      paint.textSize = 9f
      y += 22f
      canvas!!.drawText("Period: $rangeLabel    Currency: $currencyCode", margin, y, paint)
      y += 24f
    }
    fun line(text: String, bold: Boolean = false) {
      if (y > pageHeight - 55f) {
        document.finishPage(page!!)
        startPage()
      }
      paint.textSize = if (bold) 11f else 9f
      paint.isFakeBoldText = bold
      canvas!!.drawText(text.take(105), margin, y, paint)
      paint.isFakeBoldText = false
      y += if (bold) 18f else 15f
    }

    startPage()
    line("INCOME & EXPENSE SUMMARY", true)
    if (summaries.isEmpty()) line("No income or expense records in this period.")
    summaries.forEach { s ->
      line("${s.currencyCode}  |  Income ${MoneyEngine.formatMinor(s.incomeMinorUnits, s.currencyCode)}  |  Expense ${MoneyEngine.formatMinor(s.expenseMinorUnits, s.currencyCode)}")
      line("Net ${MoneyEngine.formatMinor(s.netMinorUnits, s.currencyCode)}  |  Income records ${s.incomeCount}  |  Expense records ${s.expenseCount}")
    }
    y += 8f
    line("CATEGORY EXPENSE BREAKDOWN", true)
    if (categories.isEmpty()) line("No category expenses.")
    categories.forEach { c -> line("${c.currencyCode}  |  ${c.categoryId}  |  ${MoneyEngine.formatMinor(c.expenseMinorUnits, c.currencyCode)}  |  ${c.transactionCount} records") }
    y += 8f
    line("WALLET ACTIVITY", true)
    if (wallets.isEmpty()) line("No wallet activity.")
    wallets.forEach { w ->
      line("${w.walletName} (${w.currencyCode})")
      line("Income ${MoneyEngine.formatMinor(w.incomeMinorUnits, w.currencyCode)}  |  Expense ${MoneyEngine.formatMinor(w.expenseMinorUnits, w.currencyCode)}  |  Net ${MoneyEngine.formatMinor(w.netMinorUnits, w.currencyCode)}")
    }
    y += 8f
    val exportedRecordCount = summaries.sumOf { it.incomeCount + it.expenseCount }
    line("$exportedRecordCount income/expense records included. Transfers and loan entries excluded.")
    line("Generated locally by AURELIA. Different currencies are reported separately.")
    document.finishPage(page!!)

    val directory = File(context.cacheDir, "exports").apply { mkdirs() }
    val file = File(directory, "aurelia_report_${fileDate.format(Date())}.pdf")
    FileOutputStream(file).use { document.writeTo(it) }
    document.close()
    return file
  }


  /** Copies a generated private-cache export to a user-selected SAF destination. */
  fun saveToUri(context: Context, source: File, destination: Uri) {
    require(source.exists() && source.isFile) { "Export file is unavailable" }
    val output = context.contentResolver.openOutputStream(destination, "w")
      ?: error("Unable to open the selected destination")
    output.use { target -> source.inputStream().use { input -> input.copyTo(target) } }
  }

  fun share(context: Context, file: File, mimeType: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
      type = mimeType
      putExtra(Intent.EXTRA_STREAM, uri)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share AURELIA report"))
  }
}
