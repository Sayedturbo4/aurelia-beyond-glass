package com.example.domain.model

/** Domain models intentionally contain no Room or Compose types. */
data class Person(
  val id: String,
  val name: String,
  val phone: String,
  val email: String,
  val note: String,
  val isArchived: Boolean,
)

data class Wallet(
  val id: String,
  val name: String,
  val category: String,
  val currencyCode: String,
  val balanceMinorUnits: Long,
  val colorHex: Long,
  val iconName: String,
  val isArchived: Boolean,
)

enum class LoanDirection { LENT, BORROWED }

data class Loan(
  val id: String,
  val personId: String,
  val personName: String,
  val direction: LoanDirection,
  val principalMinorUnits: Long,
  val repaidMinorUnits: Long,
  val currencyCode: String,
  val openedAtMillis: Long,
  val dueAtMillis: Long?,
  val note: String,
  val isArchived: Boolean,
) {
  init {
    require(principalMinorUnits > 0L)
    require(repaidMinorUnits in 0L..principalMinorUnits)
  }

  val outstandingMinorUnits: Long get() = Math.subtractExact(principalMinorUnits, repaidMinorUnits)
  val isClosed: Boolean get() = outstandingMinorUnits == 0L
}

enum class FinanceTransactionType { INCOME, EXPENSE, TRANSFER, PEOPLE, UNKNOWN }

data class FinanceTransaction(
  val id: String,
  val title: String,
  val categoryId: String,
  val type: FinanceTransactionType,
  val amountMinorUnits: Long,
  val currencyCode: String,
  val walletId: String,
  val destinationWalletId: String?,
  val personId: String?,
  val occurredAtMillis: Long,
  val note: String,
)

data class CurrencyWalletSummary(
  val currencyCode: String,
  val walletCount: Int,
  val totalBalanceMinorUnits: Long,
)
