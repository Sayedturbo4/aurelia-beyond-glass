package com.example.data.backup

import androidx.room.withTransaction
import com.example.data.local.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

/** Versioned, offline JSON backup. Restore is merge-only: existing IDs are never overwritten. */
data class FinanceBackupPayload(
  val format: String = FORMAT,
  val schemaVersion: Int = CURRENT_SCHEMA,
  val exportedAtMillis: Long,
  val people: List<PersonEntity>,
  val wallets: List<WalletEntity>,
  val loans: List<LoanEntity>,
  val transactions: List<TransactionEntity>,
  val budgets: List<BudgetEntity>,
  val savingsGoals: List<SavingsGoalEntity>,
  val savingsContributions: List<SavingsContributionEntity>,
  val categories: List<CategoryEntity>,
  val metadata: List<AppMetadataEntity>,
) {
  companion object { const val FORMAT = "AURELIA_OFFLINE_BACKUP"; const val CURRENT_SCHEMA = 1 }
}

data class BackupPreview(
  val exportedAtMillis: Long,
  val people: Int,
  val wallets: Int,
  val loans: Int,
  val transactions: Int,
  val budgets: Int,
  val savingsGoals: Int,
  val savingsContributions: Int,
  val categories: Int,
)

data class BackupRestoreResult(val inserted: Map<String, Int>, val skippedDuplicates: Map<String, Int>)

class FinanceBackupManager(private val database: AureliaDatabase) {
  private val adapter = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    .adapter(FinanceBackupPayload::class.java)

  suspend fun exportJson(nowMillis: Long = System.currentTimeMillis()): String {
    val payload = FinanceBackupPayload(
      exportedAtMillis = nowMillis,
      people = database.personDao().exportAll(),
      wallets = database.walletDao().exportAll(),
      loans = database.loanDao().exportAll(),
      transactions = database.transactionDao().exportAll(),
      budgets = database.budgetDao().exportAll(),
      savingsGoals = database.savingsGoalDao().exportAll(),
      savingsContributions = database.savingsContributionDao().exportAll(),
      categories = database.categoryDao().exportAll(),
      metadata = database.appMetadataDao().exportAll(),
    )
    return adapter.toJson(payload)
  }

  /** Parse and validate without modifying the database. Call before showing restore confirmation. */
  fun preview(json: String): BackupPreview {
    require(json.isNotBlank()) { "Backup file is empty" }
    require(json.length <= MAX_JSON_CHARS) { "Backup file is too large" }
    val payload = adapter.fromJson(json) ?: throw IllegalArgumentException("Invalid backup JSON")
    validate(payload)
    return BackupPreview(
      payload.exportedAtMillis, payload.people.size, payload.wallets.size, payload.loans.size,
      payload.transactions.size, payload.budgets.size, payload.savingsGoals.size,
      payload.savingsContributions.size, payload.categories.size,
    )
  }

  /** Merge-only restore. Existing IDs are skipped; no local row is updated or deleted. */
  suspend fun restoreMerge(json: String): BackupRestoreResult {
    val payload = adapter.fromJson(json) ?: throw IllegalArgumentException("Invalid backup JSON")
    validate(payload)
    val inserted = linkedMapOf<String, Int>()
    val skipped = linkedMapOf<String, Int>()
    database.withTransaction {
      // Never merge a ledger onto a wallet snapshot that disagrees with the backup.
      // Doing so could make the cached balance disagree with imported transaction history.
      payload.wallets.forEach { incoming ->
        val existing = database.walletDao().findById(incoming.id)
        if (existing != null) {
          require(existing.currencyCode == incoming.currencyCode && existing.balanceMinorUnits == incoming.balanceMinorUnits) {
            "Wallet '${incoming.name}' already exists with a different currency or balance. Use a fresh/empty profile or reconcile it before restore."
          }
        }
      }
      payload.savingsGoals.forEach { incoming ->
        val existing = database.savingsGoalDao().findById(incoming.id)
        if (existing != null) {
          require(existing.currencyCode == incoming.currencyCode && existing.savedMinorUnits == incoming.savedMinorUnits && existing.targetMinorUnits == incoming.targetMinorUnits) {
            "Savings goal '${incoming.name}' already exists with different totals; restore was stopped to protect its history."
          }
        }
      }
      fun record(name: String, results: List<Long>, sourceSize: Int) {
        val added = results.count { it != -1L }
        inserted[name] = added
        skipped[name] = sourceSize - added
      }
      record("people", database.personDao().importIgnore(payload.people), payload.people.size)
      record("wallets", database.walletDao().importIgnore(payload.wallets), payload.wallets.size)
      record("categories", database.categoryDao().importIgnore(payload.categories), payload.categories.size)
      record("loans", database.loanDao().importIgnore(payload.loans), payload.loans.size)
      record("savingsGoals", database.savingsGoalDao().importIgnore(payload.savingsGoals), payload.savingsGoals.size)
      record("transactions", database.transactionDao().importIgnore(payload.transactions), payload.transactions.size)
      record("budgets", database.budgetDao().importIgnore(payload.budgets), payload.budgets.size)
      record("savingsContributions", database.savingsContributionDao().importIgnore(payload.savingsContributions), payload.savingsContributions.size)
      record("metadata", database.appMetadataDao().importIgnore(payload.metadata), payload.metadata.size)
    }
    return BackupRestoreResult(inserted, skipped)
  }

  private fun validate(p: FinanceBackupPayload) {
    require(p.format == FinanceBackupPayload.FORMAT) { "This is not an AURELIA backup" }
    require(p.schemaVersion == FinanceBackupPayload.CURRENT_SCHEMA) { "Unsupported backup version: ${p.schemaVersion}" }
    require(p.exportedAtMillis > 0L) { "Invalid backup timestamp" }
    unique(p.people.map { it.id }, "people")
    unique(p.wallets.map { it.id }, "wallets")
    unique(p.loans.map { it.id }, "loans")
    unique(p.transactions.map { it.id }, "transactions")
    unique(p.budgets.map { it.id }, "budgets")
    unique(p.savingsGoals.map { it.id }, "savings goals")
    unique(p.savingsContributions.map { it.id }, "savings contributions")
    unique(p.categories.map { it.id }, "categories")
    unique(p.metadata.map { it.key }, "metadata")

    val people = p.people.map { it.id }.toSet()
    val wallets = p.wallets.associateBy { it.id }
    val goals = p.savingsGoals.map { it.id }.toSet()
    p.people.forEach { require(it.id.isNotBlank() && it.name.isNotBlank()) { "Invalid person record" } }
    p.wallets.forEach { require(it.id.isNotBlank() && it.name.isNotBlank() && validCurrency(it.currencyCode)) { "Invalid wallet record" } }
    p.loans.forEach {
      require(it.id.isNotBlank() && it.personId in people && validCurrency(it.currencyCode)) { "Loan references a missing person or invalid currency" }
      require(it.principalMinorUnits > 0 && it.repaidMinorUnits in 0..it.principalMinorUnits) { "Invalid loan amount" }
    }
    p.transactions.forEach {
      require(it.id.isNotBlank() && it.walletId in wallets && validCurrency(it.currencyCode)) { "Transaction references a missing wallet or invalid currency" }
      require(wallets[it.walletId]?.currencyCode == it.currencyCode) { "Transaction currency does not match its wallet" }
      require(it.destinationWalletId == null || it.destinationWalletId in wallets) { "Transfer destination wallet is missing" }
      require(it.personId == null || it.personId in people) { "Transaction person is missing" }
      require(it.amountMinorUnits > 0 && it.transferFeeMinorUnits >= 0) { "Invalid transaction amount" }
    }
    p.budgets.forEach { require(it.limitMinorUnits > 0 && validCurrency(it.currencyCode) && it.periodEndMillis > it.periodStartMillis) { "Invalid budget record" } }
    p.savingsGoals.forEach { require(it.id.isNotBlank() && it.name.isNotBlank() && it.targetMinorUnits > 0 && it.savedMinorUnits >= 0 && validCurrency(it.currencyCode)) { "Invalid savings goal" } }
    p.savingsContributions.forEach {
      require(it.goalId in goals && it.amountMinorUnits > 0 && validCurrency(it.currencyCode)) { "Savings contribution references a missing goal or invalid amount" }
      require(p.savingsGoals.first { goal -> goal.id == it.goalId }.currencyCode == it.currencyCode) { "Savings contribution currency mismatch" }
    }
    p.categories.forEach { require(it.id.isNotBlank() && it.name.isNotBlank() && it.type in setOf("EXPENSE", "INCOME")) { "Invalid category record" } }
  }

  private fun unique(ids: List<String>, label: String) {
    require(ids.none { it.isBlank() } && ids.size == ids.toSet().size) { "Duplicate or empty IDs in $label" }
  }
  private fun validCurrency(code: String) = code.matches(Regex("^[A-Z]{3}$"))

  companion object { private const val MAX_JSON_CHARS = 25 * 1024 * 1024 }
}
