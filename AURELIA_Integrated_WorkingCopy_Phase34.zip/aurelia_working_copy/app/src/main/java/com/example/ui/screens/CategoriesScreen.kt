package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.local.CategoryEntity
import com.example.ui.viewmodel.FinanceOverviewViewModel

@Composable
fun CategoriesScreen(viewModel: FinanceOverviewViewModel, modifier: Modifier = Modifier) {
  val expenses by viewModel.expenseCategories.collectAsState()
  val incomes by viewModel.incomeCategories.collectAsState()
  val archived by viewModel.archivedCategories.collectAsState()
  var selectedType by remember { mutableStateOf("EXPENSE") }
  var name by remember { mutableStateOf("") }
  var editing by remember { mutableStateOf<CategoryEntity?>(null) }
  var showArchived by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf<String?>(null) }
  val rows = if (showArchived) archived else if (selectedType == "EXPENSE") expenses else incomes

  LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { Text("Categories", style = androidx.compose.material3.MaterialTheme.typography.headlineSmall) }
    item {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { selectedType = "EXPENSE"; showArchived = false }) { Text("Expense") }
        OutlinedButton(onClick = { selectedType = "INCOME"; showArchived = false }) { Text("Income") }
        OutlinedButton(onClick = { showArchived = !showArchived }) { Text(if (showArchived) "Active" else "Archived") }
      }
    }
    if (!showArchived) item {
      OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, label = { Text("New category name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
      Button(onClick = {
        viewModel.createCategory(name, selectedType) { result ->
          result.onSuccess { name = ""; error = null }.onFailure { error = it.message ?: "Could not create category" }
        }
      }, enabled = name.isNotBlank()) { Text("Add category") }
    }
    error?.let { message -> item { Text(message, color = androidx.compose.material3.MaterialTheme.colorScheme.error) } }
    if (rows.isEmpty()) item { Text(if (showArchived) "No archived categories" else "No categories yet") }
    items(rows, key = { it.id }) { category ->
      Column(Modifier.fillMaxWidth().clickable(enabled = !category.isSystem && !showArchived) { editing = category }.padding(14.dp)) {
        Text(category.name, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
        Text("${category.type} · ${if (category.isSystem) "System" else if (showArchived) "Archived" else "Custom"}", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          if (showArchived) TextButton(onClick = { viewModel.restoreCategory(category.id) { it.onFailure { e -> error = e.message } } }) { Text("Restore") }
          else if (!category.isSystem) TextButton(onClick = { editing = category }) { Text("Edit") }
          if (!showArchived && !category.isSystem) TextButton(onClick = { viewModel.archiveCategory(category.id) { it.onFailure { e -> error = e.message } } }) { Text("Archive") }
        }
      }
    }
  }
  editing?.let { category ->
    var editedName by remember(category.id) { mutableStateOf(category.name) }
    AlertDialog(
      onDismissRequest = { editing = null },
      title = { Text("Edit category") },
      text = { OutlinedTextField(value = editedName, onValueChange = { editedName = it.take(40) }, label = { Text("Name") }, singleLine = true) },
      confirmButton = { TextButton(onClick = { viewModel.updateCategory(category.copy(name = editedName)) { result -> result.onSuccess { editing = null }.onFailure { error = it.message } } }, enabled = editedName.isNotBlank()) { Text("Save") } },
      dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } },
    )
  }
}
