package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.MoneyEngine
import com.example.data.local.BudgetEntity
import com.example.data.local.SavingsGoalEntity
import com.example.domain.model.BudgetExpenseRecord
import com.example.domain.model.calculateBudgetProgress
import com.example.ui.viewmodel.FinanceOverviewViewModel
import java.util.Calendar
import java.util.UUID

/** Local-only budget and savings overview. Savings progress is tracking-only and does not move wallet funds. */
@Composable
fun PlanningScreen(
  viewModel: FinanceOverviewViewModel = viewModel(),
  modifier: Modifier = Modifier,
) {
  val budgets by viewModel.budgets.collectAsState()
  val goals by viewModel.savingsGoals.collectAsState()
  val transactions by viewModel.allTransactions.collectAsState()
  var category by remember { mutableStateOf("") }
  var budgetAmount by remember { mutableStateOf("") }
  var currency by remember { mutableStateOf("BDT") }
  var goalName by remember { mutableStateOf("") }
  var goalTarget by remember { mutableStateOf("") }
  var goalSaved by remember { mutableStateOf("0") }
  var message by remember { mutableStateOf("") }

  val now = System.currentTimeMillis()
  val calendar = Calendar.getInstance().apply { timeInMillis = now; set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
  val periodStart = calendar.timeInMillis
  calendar.add(Calendar.MONTH, 1)
  val periodEnd = calendar.timeInMillis

  LazyColumn(
    modifier = modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Text("Planning", style = androidx.compose.material3.MaterialTheme.typography.headlineMedium)
      Text("Budgets & savings goals · Stored on this device", style = androidx.compose.material3.MaterialTheme.typography.bodyMedium)
    }
    item {
      Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Create monthly budget", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
          OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category ID (e.g. food)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          OutlinedTextField(value = budgetAmount, onValueChange = { budgetAmount = it }, label = { Text("Budget amount") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          OutlinedTextField(value = currency, onValueChange = { currency = it.uppercase().take(3) }, label = { Text("Currency code") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          Button(onClick = {
            val result = runCatching {
              val minor = MoneyEngine.parseMajorToMinor(budgetAmount, currency)
              BudgetEntity(UUID.randomUUID().toString(), category.trim(), minor, currency, periodStart, periodEnd, now, now)
            }
            result.onSuccess { entity -> viewModel.createBudget(entity) { outcome -> message = outcome.fold({ "Budget saved" }, { it.message ?: "Could not save budget" }) } }
              .onFailure { message = it.message ?: "Invalid budget" }
          }, modifier = Modifier.fillMaxWidth()) { Text("Save Budget") }
          if (message.isNotBlank()) Text(message, style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
        }
      }
    }
    item { Text("Your budgets", style = androidx.compose.material3.MaterialTheme.typography.titleLarge) }
    items(budgets, key = { it.id }) { budget ->
      val progress = remember(budget, transactions) {
        calculateBudgetProgress(
          budget.id, budget.categoryId, budget.currencyCode, budget.limitMinorUnits,
          budget.periodStartMillis, budget.periodEndMillis,
          transactions.map { BudgetExpenseRecord(it.categoryId, it.currencyCode, it.type, it.amountMinorUnits, it.occurredAtMillis) },
        )
      }
      val ratio = (progress.spentMinorUnits.toDouble() / progress.limitMinorUnits.toDouble()).coerceIn(0.0, 1.0).toFloat()
      Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(budget.categoryId)
            Text(if (progress.isOverBudget) "Over budget" else "On track")
          }
          Text("Spent ${MoneyEngine.formatMinor(progress.spentMinorUnits, budget.currencyCode)} / ${MoneyEngine.formatMinor(budget.limitMinorUnits, budget.currencyCode)}")
          LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth())
          Text("Remaining ${MoneyEngine.formatMinor(progress.remainingMinorUnits, budget.currencyCode)} · ${budget.currencyCode}")
          Button(onClick = { viewModel.deleteBudget(budget.id) { outcome -> message = outcome.fold({ "Budget deleted" }, { it.message ?: "Delete failed" }) } }) { Text("Delete") }
        }
      }
    }
    item {
      Card(shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Create savings goal", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
          OutlinedTextField(value = goalName, onValueChange = { goalName = it }, label = { Text("Goal name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          OutlinedTextField(value = goalTarget, onValueChange = { goalTarget = it }, label = { Text("Target amount") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          OutlinedTextField(value = goalSaved, onValueChange = { goalSaved = it }, label = { Text("Already saved (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          Button(onClick = {
            val result = runCatching {
              val target = MoneyEngine.parseMajorToMinor(goalTarget, currency)
              val saved = MoneyEngine.parseMajorToMinor(goalSaved.ifBlank { "0" }, currency)
              require(saved >= 0L) { "Saved amount cannot be negative" }
              SavingsGoalEntity(UUID.randomUUID().toString(), goalName.trim(), target, saved, currency, createdAtMillis = now, updatedAtMillis = now)
            }
            result.onSuccess { entity -> viewModel.createSavingsGoal(entity) { outcome -> message = outcome.fold({ "Savings goal saved" }, { it.message ?: "Could not save goal" }) } }
              .onFailure { message = it.message ?: "Invalid savings goal" }
          }, modifier = Modifier.fillMaxWidth()) { Text("Save Goal") }
          Text("Progress is tracked separately; creating a goal does not move money between wallets.", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
        }
      }
    }
    item { Text("Savings goals", style = androidx.compose.material3.MaterialTheme.typography.titleLarge) }
    items(goals, key = { it.id }) { goal ->
      val ratio = (goal.savedMinorUnits.toDouble() / goal.targetMinorUnits.toDouble()).coerceIn(0.0, 1.0).toFloat()
      Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(goal.name)
            Text(if (goal.isCompleted) "Completed" else goal.currencyCode)
          }
          Text("${MoneyEngine.formatMinor(goal.savedMinorUnits, goal.currencyCode)} / ${MoneyEngine.formatMinor(goal.targetMinorUnits, goal.currencyCode)}")
          LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth())
          Button(onClick = { viewModel.deleteSavingsGoal(goal.id) { outcome -> message = outcome.fold({ "Goal deleted" }, { it.message ?: "Delete failed" }) } }) { Text("Delete") }
        }
      }
    }
    item { Spacer(Modifier.height(20.dp)) }
  }
}
