package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** Local-first finance database. No network or cloud dependency is used here. */
@Database(
  entities = [
    PersonEntity::class,
    WalletEntity::class,
    LoanEntity::class,
    TransactionEntity::class,
    BudgetEntity::class,
    SavingsGoalEntity::class,
    SavingsContributionEntity::class,
    AppMetadataEntity::class,
    CategoryEntity::class,
  ],
  version = 5,
  exportSchema = false,
)
abstract class AureliaDatabase : RoomDatabase() {
  abstract fun personDao(): PersonDao
  abstract fun walletDao(): WalletDao
  abstract fun loanDao(): LoanDao
  abstract fun transactionDao(): TransactionDao
  abstract fun budgetDao(): BudgetDao
  abstract fun savingsGoalDao(): SavingsGoalDao
  abstract fun savingsContributionDao(): SavingsContributionDao
  abstract fun appMetadataDao(): AppMetadataDao
  abstract fun categoryDao(): CategoryDao

  companion object {
    /** Adds metadata without touching existing finance records. */
    private val MIGRATION_1_2 = object : Migration(1, 2) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_metadata (`key` TEXT NOT NULL, `value` TEXT NOT NULL, updatedAtMillis INTEGER NOT NULL, PRIMARY KEY(`key`))")
      }
    }

    private val MIGRATION_2_3 = object : Migration(2, 3) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE transactions ADD COLUMN isVoided INTEGER NOT NULL DEFAULT 0")
      }
    }

    private val MIGRATION_3_4 = object : Migration(3, 4) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS savings_contributions (id TEXT NOT NULL, goalId TEXT NOT NULL, amountMinorUnits INTEGER NOT NULL, currencyCode TEXT NOT NULL, occurredAtMillis INTEGER NOT NULL, note TEXT NOT NULL, PRIMARY KEY(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_savings_contributions_goalId_occurredAtMillis ON savings_contributions(goalId, occurredAtMillis)")
      }
    }

    private val MIGRATION_4_5 = object : Migration(4, 5) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS categories (id TEXT NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL, iconName TEXT NOT NULL, colorHex INTEGER NOT NULL, isSystem INTEGER NOT NULL, isArchived INTEGER NOT NULL, createdAtMillis INTEGER NOT NULL, updatedAtMillis INTEGER NOT NULL, PRIMARY KEY(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_categories_type_isArchived ON categories(type, isArchived)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_categories_name ON categories(name)")
        val now = System.currentTimeMillis()
        val defaults = listOf(
          "Food & Dining|Food & Dining|EXPENSE|restaurant", "Work & Client|Work & Client|EXPENSE|work",
          "Housing & Bills|Housing & Bills|EXPENSE|receipt", "Transport|Transport|EXPENSE|directions_car",
          "Tech & Tools|Tech & Tools|EXPENSE|devices", "Health & Fitness|Health & Fitness|EXPENSE|medical_services",
          "Entertainment|Entertainment|EXPENSE|movie", "Shopping|Shopping|EXPENSE|shopping_bag",
          "Salary|Salary|INCOME|payments", "Business|Business|INCOME|store",
          "Gifts|Gifts|INCOME|redeem", "Other Income|Other Income|INCOME|category"
        )
        defaults.forEach { row ->
          val parts = row.split('|')
          db.execSQL("INSERT OR IGNORE INTO categories (id,name,type,iconName,colorHex,isSystem,isArchived,createdAtMillis,updatedAtMillis) VALUES (?,?,?,?,?,1,0,?,?)", arrayOf(parts[0], parts[1], parts[2], parts[3], 0xFF8B7CF6.toLong(), now, now))
        }
      }
    }

    @Volatile private var INSTANCE: AureliaDatabase? = null

    fun getInstance(context: Context): AureliaDatabase =
      INSTANCE ?: synchronized(this) {
        INSTANCE ?: Room.databaseBuilder(
          context.applicationContext,
          AureliaDatabase::class.java,
          "aurelia_local.db",
        ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build().also { INSTANCE = it }
      }
  }
}
