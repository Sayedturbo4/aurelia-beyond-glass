package com.example.security

/** Security defaults for a local-first personal finance application. */
object AppSecurityPolicy {
  const val DEFAULT_AUTO_LOCK_TIMEOUT_MILLIS: Long = 60_000L
  const val MIN_AUTO_LOCK_TIMEOUT_MILLIS: Long = 0L
  const val MAX_AUTO_LOCK_TIMEOUT_MILLIS: Long = 15 * 60_000L

  fun shouldLock(
    enabled: Boolean,
    backgroundDurationMillis: Long,
    timeoutMillis: Long = DEFAULT_AUTO_LOCK_TIMEOUT_MILLIS,
  ): Boolean {
    if (!enabled) return false
    if (backgroundDurationMillis < 0L) return true
    val safeTimeout = timeoutMillis.coerceIn(MIN_AUTO_LOCK_TIMEOUT_MILLIS, MAX_AUTO_LOCK_TIMEOUT_MILLIS)
    return backgroundDurationMillis >= safeTimeout
  }

  fun shouldRequireReauthenticationAfterProcessRestart(enabled: Boolean): Boolean = enabled

  fun isValidTimeout(timeoutMillis: Long): Boolean =
    timeoutMillis in MIN_AUTO_LOCK_TIMEOUT_MILLIS..MAX_AUTO_LOCK_TIMEOUT_MILLIS
}
