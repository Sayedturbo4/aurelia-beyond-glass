# AURELIA — Phase 34: Final Integration & GitHub APK Release Preparation

তারিখ: 2026-11-03

## এই Phase-এ করা হয়েছে

1. Phase 33 cumulative working copy-কে Phase 34 baseline হিসেবে নেওয়া হয়েছে।
2. Root README-কে পুরোনো Phase 7 handoff নির্দেশনা থেকে বর্তমান GitHub Actions debug-build workflow অনুযায়ী হালনাগাদ করা হয়েছে।
3. Android ফোন থেকে GitHub Actions চালানো, সফল run যাচাই, artifact ডাউনলোড, ZIP extract ও APK install করার ধাপ যোগ করা হয়েছে।
4. Debug APK বনাম Play Store release APK-এর পার্থক্য এবং signing-key নিরাপত্তা স্পষ্ট করা হয়েছে।
5. `.env`, API key, `google-services.json` ও ব্যক্তিগত signing key commit না করার সতর্কতা যুক্ত করা হয়েছে।
6. Production release-এর আগে প্রয়োজনীয় blocker checklist এবং সীমাবদ্ধতা নথিভুক্ত করা হয়েছে।
7. Phase 34 source/package preflight script যোগ করা হয়েছে।

## GitHub APK পাওয়ার নির্দিষ্ট ধাপ (Android ফোন)

1. `https://github.com/Sayedturbo4/aurelia-beyond-glass` খুলুন।
2. **Actions → AURELIA Android Debug Build** নির্বাচন করুন।
3. সর্বশেষ run খুলে `compileDebugKotlin`, `testDebugUnitTest`, `assembleDebug`—তিনটি ধাপ সফল হয়েছে কি না দেখুন।
4. **Artifacts** থেকে `aurelia-debug-apk-<run number>` ডাউনলোড করুন।
5. Artifact ZIP extract করে APK ইনস্টল করুন।
6. একই artifact-এর `SHA256SUMS.txt` ও `BUILD_INFO.txt` রেখে দিন।

Failed run-এর artifact ইনস্টল করবেন না। কোনো ধাপ ব্যর্থ হলে সেই ধাপের log সংগ্রহ করে আগে সংশোধন করতে হবে।

## Release blockers — এখনো অসম্পন্ন

- এই পরিবেশে Android Gradle build চালানো হয়নি; GitHub Actions-এ বাস্তব compile/test/APK result এখনো run-specificভাবে যাচাই করতে হবে।
- Emulator/physical Android device-এ installation, navigation, keyboard, dark/light theme, biometric, backup/restore, financial workflows ও rendering QA বাকি।
- Production release signing, private upload key, Play App Signing configuration এবং release variant pipeline তৈরি/যাচাই বাকি।
- App privacy/data-safety disclosures, Play Store listing, versioning/release policy ও final security review বাকি।
- Debug APK production distribution-এর জন্য নয়।

## Architectural boundaries

- Original AI Studio Phase 4.6 project এই working copy দিয়ে overwrite করা হয়নি।
- এই package আলাদা repository working copy; AI Studio-তে automatic sync নেই।
- Debug keystore production signing-এ ব্যবহার করা যাবে না।
- Offline-first/local data boundary বজায় থাকবে; cloud sync/auth/realtime messaging/online billing এই release scope-এ ধরে নেওয়া যাবে না।

## Phase 34 verification

`AURELIA_PHASE34_CHECKS.py` source/package consistency checks চালায়। এগুলো Android compilation, Room/KSP generated-code compilation, JUnit execution বা device QA-এর বিকল্প নয়।
