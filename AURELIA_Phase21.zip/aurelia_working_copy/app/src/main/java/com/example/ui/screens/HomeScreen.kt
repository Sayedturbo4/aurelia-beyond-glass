package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataProvider
import com.example.data.TransactionType
import com.example.domain.model.FinanceTransaction
import com.example.domain.model.FinanceTransactionType
import com.example.domain.model.Wallet
import com.example.ui.components.AureliaBadge
import com.example.ui.components.AureliaGlassCard
import com.example.ui.components.AureliaPagerIndicator
import com.example.ui.components.GlassStyle
import com.example.ui.theme.AureliaThemeTokens
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
  isBalanceVisible: Boolean,
  onToggleBalanceVisibility: () -> Unit,
  isDarkTheme: Boolean,
  onToggleTheme: () -> Unit,
  onOpenQuickAdd: (TransactionType) -> Unit,
  onViewAllWallets: () -> Unit,
  onViewAllActivity: () -> Unit,
  onNavigateToPeople: () -> Unit,
  wallets: List<Wallet>,
  transactions: List<FinanceTransaction>,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  val currencies = DemoDataProvider.supportedCurrencies
  val pagerState = rememberPagerState(initialPage = 0, pageCount = { currencies.size })
  val scope = rememberCoroutineScope()

  val activeCurrency = currencies[pagerState.currentPage]
  val walletsForActiveCurrency = wallets.filter { !it.isArchived && it.currencyCode == activeCurrency.code }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    // 1. Personalized Header
    item {
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(CircleShape)
              .background(colors.auroraLavender.copy(alpha = 0.35f)),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = "A",
              fontWeight = FontWeight.Bold,
              fontSize = 20.sp,
              color = colors.textPrimary,
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "AURELIA — Beyond Glass",
              fontSize = 12.sp,
              color = colors.textSecondary,
              fontWeight = FontWeight.Medium,
            )
            Text(
              text = "Good morning, Rahim",
              fontSize = 17.sp,
              fontWeight = FontWeight.SemiBold,
              color = colors.textPrimary,
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          // Balance visibility toggle
          IconButton(
            onClick = onToggleBalanceVisibility,
            modifier = Modifier.testTag("toggle_balance_privacy"),
          ) {
            Icon(
              imageVector = if (isBalanceVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
              contentDescription = "Toggle Balance Privacy",
              tint = colors.textSecondary,
            )
          }

          // Light / Dark Theme toggle
          IconButton(
            onClick = onToggleTheme,
            modifier = Modifier.testTag("toggle_app_theme"),
          ) {
            Icon(
              imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
              contentDescription = "Toggle Theme",
              tint = colors.auroraLavender,
            )
          }

          // People shortcut
          IconButton(onClick = onNavigateToPeople) {
            Icon(
              imageVector = Icons.Default.People,
              contentDescription = "People & Loans",
              tint = colors.auroraBlue,
            )
          }
        }
      }
    }

    // 2. SWIPEABLE BALANCE HERO (HorizontalPager Currency Carousel)
    item {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Net Vault Balance (Swipe to switch)",
            fontSize = 13.sp,
            color = colors.textSecondary,
            fontWeight = FontWeight.Medium,
          )

          // Accessible navigation buttons for users who cannot swipe
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = {
                if (pagerState.currentPage > 0) {
                  scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) }
                }
              },
              enabled = pagerState.currentPage > 0,
              modifier = Modifier.size(28.dp),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Previous Currency",
                tint = if (pagerState.currentPage > 0) colors.textPrimary else colors.textSecondary.copy(alpha = 0.3f),
                modifier = Modifier.size(16.dp),
              )
            }
            Spacer(modifier = Modifier.width(4.dp))
            IconButton(
              onClick = {
                if (pagerState.currentPage < currencies.size - 1) {
                  scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                }
              },
              enabled = pagerState.currentPage < currencies.size - 1,
              modifier = Modifier.size(28.dp),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Next Currency",
                tint = if (pagerState.currentPage < currencies.size - 1) colors.textPrimary else colors.textSecondary.copy(alpha = 0.3f),
                modifier = Modifier.size(16.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        HorizontalPager(
          state = pagerState,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("swipeable_balance_hero_pager"),
        ) { pageIndex ->
          val currency = currencies[pageIndex]
          val pageWallets = wallets.filter { !it.isArchived && it.currencyCode == currency.code }
          val pageTransactions = transactions.filter { it.currencyCode == currency.code }
          val totalMinorUnits = pageWallets.fold(0L) { total, wallet -> Math.addExact(total, wallet.balanceMinorUnits) }
          val incomeMinorUnits = pageTransactions
            .filter { it.type == FinanceTransactionType.INCOME }
            .fold(0L) { total, transaction -> Math.addExact(total, transaction.amountMinorUnits) }
          val expenseMinorUnits = pageTransactions
            .filter { it.type == FinanceTransactionType.EXPENSE }
            .fold(0L) { total, transaction -> Math.addExact(total, transaction.amountMinorUnits) }

          AureliaGlassCard(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("balance_hero_card_${currency.code}"),
            glassStyle = GlassStyle.PEARL,
            shape = RoundedCornerShape(28.dp),
          ) {
            Column(
              modifier = Modifier.padding(22.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "${currency.flagEmoji} ${currency.code} — ${currency.name}",
                    fontSize = 14.sp,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                  )
                }
                AureliaBadge(text = "${pageIndex + 1}/${currencies.size}", color = colors.auroraLavender)
              }

              Spacer(modifier = Modifier.height(10.dp))

              // Amount
              Text(
                text = DemoDataProvider.formatMoney(
                  minorUnits = totalMinorUnits,
                  currencyCode = currency.code,
                  isVisible = isBalanceVisible,
                ),
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                letterSpacing = (-0.5).sp,
              )

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text("Recorded income", fontSize = 11.sp, color = colors.textSecondary)
                  Text(
                    DemoDataProvider.formatMoney(incomeMinorUnits, currency.code, isBalanceVisible),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.financialIncome,
                  )
                }
                Column(modifier = Modifier.weight(1f)) {
                  Text("Recorded expense", fontSize = 11.sp, color = colors.textSecondary)
                  Text(
                    DemoDataProvider.formatMoney(expenseMinorUnits, currency.code, isBalanceVisible),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.financialExpense,
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(verticalAlignment = Alignment.CenterVertically) {
                AureliaBadge(
                  text = "Live local balance",
                  color = colors.auroraBlue,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "${pageWallets.size} wallets active",
                  fontSize = 12.sp,
                  color = colors.textSecondary,
                )
              }

              Spacer(modifier = Modifier.height(18.dp))

              // Quick Action Triad
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                HeroActionButton(
                  label = "Income",
                  icon = Icons.Default.ArrowDownward,
                  iconColor = colors.financialIncome,
                  onClick = { onOpenQuickAdd(TransactionType.INCOME) },
                  modifier = Modifier.weight(1f),
                )
                HeroActionButton(
                  label = "Expense",
                  icon = Icons.Default.ArrowUpward,
                  iconColor = colors.financialExpense,
                  onClick = { onOpenQuickAdd(TransactionType.EXPENSE) },
                  modifier = Modifier.weight(1f),
                )
                HeroActionButton(
                  label = "Transfer",
                  icon = Icons.Default.SyncAlt,
                  iconColor = colors.auroraLavender,
                  onClick = { onOpenQuickAdd(TransactionType.TRANSFER) },
                  modifier = Modifier.weight(1f),
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Page Indicator
        AureliaPagerIndicator(
          pageCount = currencies.size,
          currentPage = pagerState.currentPage,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }

    // 3. Quick Currency Switcher Pills
    item {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Supported Currencies (13)",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary,
          )
          Text(
            text = "Wallets Hub ➔",
            fontSize = 12.sp,
            color = colors.auroraLavender,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.clickable(onClick = onViewAllWallets),
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(currencies.indices.toList()) { index ->
            val curr = currencies[index]
            val isSelected = index == pagerState.currentPage
            AureliaGlassCard(
              modifier = Modifier
                .clickable {
                  scope.launch { pagerState.animateScrollToPage(index) }
                },
              glassStyle = if (isSelected) GlassStyle.CRYSTAL else GlassStyle.SMOKE,
              shape = RoundedCornerShape(14.dp),
              borderWidth = if (isSelected) 1.5.dp else 1.dp,
            ) {
              Box(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = "${curr.flagEmoji} ${curr.code}",
                  fontSize = 12.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) colors.textPrimary else colors.textSecondary,
                )
              }
            }
          }
        }
      }
    }

    // 4. Wallets for Currently Active Swiped Currency
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "${activeCurrency.code} Wallets (${walletsForActiveCurrency.size})",
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textPrimary,
        )
        Text(
          text = "View All ➔",
          fontSize = 12.sp,
          color = colors.auroraLavender,
          fontWeight = FontWeight.Medium,
          modifier = Modifier.clickable(onClick = onViewAllWallets),
        )
      }
    }

    if (walletsForActiveCurrency.isEmpty()) {
      item {
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(18.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(
              text = "No ${activeCurrency.code} wallets yet",
              fontSize = 13.sp,
              color = colors.textSecondary,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "+ Add ${activeCurrency.code} Wallet in Wallets Tab",
              fontSize = 12.sp,
              color = colors.auroraLavender,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.clickable(onClick = onViewAllWallets),
            )
          }
        }
      }
    } else {
      items(walletsForActiveCurrency.take(2)) { wallet ->
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(18.dp),
          onClick = onViewAllWallets,
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(Color(wallet.colorHex).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = wallet.category.take(1),
                  fontWeight = FontWeight.Bold,
                  color = Color(wallet.colorHex),
                  fontSize = 16.sp,
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = wallet.name,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = colors.textPrimary,
                )
                Text(
                  text = "${wallet.category} Vault",
                  fontSize = 12.sp,
                  color = colors.textSecondary,
                )
              }
            }
            Text(
              text = DemoDataProvider.formatMoney(wallet.balanceMinorUnits, wallet.currencyCode, isBalanceVisible),
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = colors.textPrimary,
            )
          }
        }
      }
    }

    // 5. People & Loans Feature Banner
    item {
      AureliaGlassCard(
        modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onNavigateToPeople),
        glassStyle = GlassStyle.AURORA,
        shape = RoundedCornerShape(22.dp),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(colors.auroraLavender.copy(alpha = 0.3f)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Default.People,
                contentDescription = null,
                tint = colors.textPrimary,
                modifier = Modifier.size(22.dp),
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "People & Interest-Free Loans",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textPrimary,
              )
              Text(
                text = "Track lent money, borrowings & repayments",
                fontSize = 12.sp,
                color = colors.textSecondary,
              )
            }
          }
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = colors.textSecondary,
            modifier = Modifier.size(18.dp),
          )
        }
      }
    }

    // 6. Recent Activity Preview
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Recent Transactions",
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textPrimary,
        )
        Text(
          text = "View Ledger ➔",
          fontSize = 12.sp,
          color = colors.auroraLavender,
          fontWeight = FontWeight.Medium,
          modifier = Modifier.clickable(onClick = onViewAllActivity),
        )
      }
    }

    if (transactions.isEmpty()) {
      item {
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(18.dp),
        ) {
          Text(
            text = "Your recent transactions will appear here",
            modifier = Modifier.padding(18.dp),
            fontSize = 13.sp,
            color = colors.textSecondary,
          )
        }
      }
    } else {
      items(transactions.take(3), key = { it.id }) { tx ->
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.SMOKE,
        shape = RoundedCornerShape(18.dp),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(
                  when (tx.type) {
                    FinanceTransactionType.INCOME -> colors.financialIncome.copy(alpha = 0.2f)
                    FinanceTransactionType.EXPENSE -> colors.financialExpense.copy(alpha = 0.2f)
                    FinanceTransactionType.TRANSFER -> colors.auroraLavender.copy(alpha = 0.2f)
                    FinanceTransactionType.PEOPLE, FinanceTransactionType.UNKNOWN -> colors.auroraBlue.copy(alpha = 0.2f)
                  },
                ),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = when (tx.type) {
                  FinanceTransactionType.INCOME -> Icons.Default.ArrowDownward
                  FinanceTransactionType.EXPENSE -> Icons.Default.ArrowUpward
                  FinanceTransactionType.TRANSFER -> Icons.Default.SyncAlt
                  FinanceTransactionType.PEOPLE, FinanceTransactionType.UNKNOWN -> Icons.Default.People
                },
                contentDescription = null,
                tint = when (tx.type) {
                  FinanceTransactionType.INCOME -> colors.financialIncome
                  FinanceTransactionType.EXPENSE -> colors.financialExpense
                  FinanceTransactionType.TRANSFER -> colors.auroraLavender
                  FinanceTransactionType.PEOPLE, FinanceTransactionType.UNKNOWN -> colors.auroraBlue
                },
                modifier = Modifier.size(18.dp),
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = tx.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textPrimary,
              )
              Text(
                text = "${tx.categoryId.replace('_', ' ')} • ${wallets.firstOrNull { it.id == tx.walletId }?.name ?: "Wallet"}",
                fontSize = 12.sp,
                color = colors.textSecondary,
              )
            }
          }

          val prefix = when (tx.type) {
            FinanceTransactionType.INCOME -> "+"
            FinanceTransactionType.EXPENSE -> "-"
            FinanceTransactionType.TRANSFER -> "⇄ "
            FinanceTransactionType.PEOPLE, FinanceTransactionType.UNKNOWN -> "👥 "
          }
          val amountColor = when (tx.type) {
            FinanceTransactionType.INCOME -> colors.financialIncome
            FinanceTransactionType.EXPENSE -> colors.financialExpense
            FinanceTransactionType.TRANSFER -> colors.textPrimary
            FinanceTransactionType.PEOPLE, FinanceTransactionType.UNKNOWN -> colors.auroraBlue
          }
          Text(
            text = "$prefix${DemoDataProvider.formatMoney(tx.amountMinorUnits, tx.currencyCode, isBalanceVisible)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = amountColor,
          )
        }
      }
      }
    }

    item {
      Spacer(modifier = Modifier.height(84.dp))
    }
  }
}

@Composable
private fun HeroActionButton(
  label: String,
  icon: ImageVector,
  iconColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  AureliaGlassCard(
    modifier = modifier.defaultMinSize(minHeight = 44.dp),
    shape = RoundedCornerShape(16.dp),
    glassStyle = GlassStyle.LIQUID,
    borderWidth = 1.dp,
    onClick = onClick,
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 10.dp, horizontal = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = iconColor,
        modifier = Modifier.size(16.dp),
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = label,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = colors.textPrimary,
      )
    }
  }
}
