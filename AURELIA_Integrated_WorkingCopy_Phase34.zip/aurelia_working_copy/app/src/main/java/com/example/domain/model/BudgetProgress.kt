package com.example.domain.model

/** Minimal immutable input for budget calculations; amounts are integer minor units. */
data class BudgetExpenseRecord(
  val categoryId: String,
  val currencyCode: String,
  val type: String,
  val amountMinorUnits: Long,
  val occurredAtMillis: Long,
)

data class BudgetProgress(
  val budgetId: String,
  val categoryId: String,
  val currencyCode: String,
  val limitMinorUnits: Long,
  val spentMinorUnits: Long,
) {
  val remainingMinorUnits: Long get() = Math.subtractExact(limitMinorUnits, spentMinorUnits)
  val isOverBudget: Boolean get() = spentMinorUnits > limitMinorUnits
  /** Can exceed 100 when overspent; callers may clamp only the visual progress indicator. */
  val progressPercent: Int get() = if (limitMinorUnits <= 0L) 0 else
    (java.math.BigInteger.valueOf(spentMinorUnits)
      .multiply(java.math.BigInteger.valueOf(100))
      .divide(java.math.BigInteger.valueOf(limitMinorUnits)))
      .coerceAtLeast(java.math.BigInteger.ZERO)
      .min(java.math.BigInteger.valueOf(Int.MAX_VALUE.toLong())).toInt()
}

/** Calculates one budget without mixing currencies, categories, or non-expense entries. */
fun calculateBudgetProgress(
  budgetId: String,
  categoryId: String,
  currencyCode: String,
  limitMinorUnits: Long,
  periodStartMillis: Long,
  periodEndMillis: Long,
  transactions: Iterable<BudgetExpenseRecord>,
): BudgetProgress {
  require(budgetId.isNotBlank())
  require(categoryId.isNotBlank())
  require(currencyCode.matches(Regex("^[A-Z]{3}$")))
  require(limitMinorUnits > 0L)
  require(periodStartMillis < periodEndMillis)
  val spent = transactions.asSequence()
    .filter { it.type == "EXPENSE" }
    .filter { it.categoryId == categoryId && it.currencyCode == currencyCode }
    .filter { it.occurredAtMillis >= periodStartMillis && it.occurredAtMillis < periodEndMillis }
    .fold(0L) { total, item ->
      require(item.amountMinorUnits > 0L) { "Expense amount must be positive" }
      Math.addExact(total, item.amountMinorUnits)
    }
  return BudgetProgress(budgetId, categoryId, currencyCode, limitMinorUnits, spent)
}
