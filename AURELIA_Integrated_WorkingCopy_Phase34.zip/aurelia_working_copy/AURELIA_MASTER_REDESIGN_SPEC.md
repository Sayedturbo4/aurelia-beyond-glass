# AURELIA — Master Redesign & Functional Improvement Specification

**Baseline:** `AURELIA_Phase21.zip` (uploaded 2026-11-03)  
**Working copy:** `AURELIA_Redesign_WorkingCopy/aurelia_working_copy`  
**Original Google AI Studio project:** untouched; continuation checkpoint remains Phase 4.6, with Phase 4.7 not yet applied there.  
**Product constraints:** Native Android Kotlin + Jetpack Compose; offline-first; Room/SQLite; no online backend, auth, cloud sync, or real-time services in this refinement; Android first, iOS later; do not mix with Project 2 or older PWA.

## 1. Product quality bar

AURELIA must be a premium, calm, readable and easy-to-use personal finance app. The design language is Pearl Light + Midnight Glass Dark, with restrained Aurora accents, real translucent layered surfaces where supported, clear hierarchy, compact workflows, and accessible contrast. Visual polish must never obscure financial data or reduce usability.

No existing feature is to be removed merely to simplify the interface. Reduce complexity through progressive disclosure, better grouping, contextual defaults, and shorter flows.

## 2. Evidence-based baseline findings

### 2.1 Visual / interaction observations from the supplied 154.6-second screen recording

- Activity & Ledger has search, type filters, inflow/outflow summary and a generic empty state. The first-run experience can show no matching records without a sufficiently guided next action.
- More contains Active Features, Appearance & System, and a Future Online Modules Roadmap. Budgets & Savings Goals and Reports & Analytics appear in both active and roadmap groupings, creating contradictory availability messaging.
- The Reports screen uses a dense dark presentation with several period controls, currency filter, export controls and a large empty-state panel. It needs stronger information hierarchy and consistent theme behavior.
- People & Loans is presented as a dark, dense ledger with a large outstanding summary, search, contacts and multiple monetary figures. The screen needs more compact, scannable person rows and clearer per-currency grouping.
- A black/blank transition frame appears in the recording during navigation/theme transition; determine whether it is a capture artifact, system-bar transition, or app rendering issue with device testing before changing animation code.
- The overall app reads as stacked tinted cards with gradients/borders rather than a convincing, consistent liquid-glass system. A true backdrop blur implementation is not present in the supplied Kotlin source (no RenderEffect/backdrop blur usage found).

### 2.2 Source-code findings

- `MainActivity.kt` owns destination state, back handling, sheet state, theme state, snackbar and screen routing. This is a compact prototype root but is becoming a navigation/state bottleneck.
- Navigation is custom state-based rather than Navigation Compose. Back behavior uses `previousDestination` for several secondary destinations; nested flows need a defined navigation stack and predictable back behavior.
- `GlassComponents.kt` provides multiple named glass styles, but surfaces are primarily alpha-tinted fills, gradients, borders, sheen and shadows. They do not sample/blur the background behind the surface. Do not describe this as true backdrop blur.
- Theme typography uses `FontFamily.Default`; Plus Jakarta Sans and Hind Siliguri are not bundled/assigned in the inspected theme source.
- `QuickAddSheet.kt` maintains selection by list indices (`selectedWalletIndex`, `destWalletIndex`, `selectedPersonIndex`, `selectedLoanIndex`). This is fragile when Room data changes/reorders. Store stable IDs instead.
- Quick Add has a multi-purpose conditional form for Expense, Income, Transfer and People/Loans. This increases cognitive load and conditional-state complexity. Split into contextual flows while retaining a shared shell and common controls.
- Quick Add falls back to `DemoDataProvider.demoWallets` if database wallet rows are empty. This can make a non-persisted demo wallet appear selectable; saving must never be possible against an object that is not a real Room wallet.
- `FinanceOverviewViewModel` automatically invokes `seedDemoDataIfNeeded` on first launch. Repository code imports demo people, wallets and loans into a fresh database. This is unsuitable as a default production first-run experience for a personal finance product. Replace with explicit optional sample-data mode or a true onboarding flow; never silently seed fake financial records.
- `TransactionDao` currently exposes insert/find/observe operations but no update/delete APIs. `WalletDao` has insert/update/balance update but no archive or edit workflow API. Person archive exists; full profile editing is not exposed in the inspected DAO surface. These are feature completeness gaps for the requested ledger UX.
- Loan repayments are persisted as transactions whose loan association is embedded in a free-text note (`Repayment for loan <id>`). The transaction entity has `personId` but no structured `loanId`; a dedicated repayment relation/record is needed for reliable repayment history, editing, audit and reconciliation.
- There is no dedicated audit-log entity/table in the current Room schema, despite Audit History being a product requirement.
- Savings goal changes are explicitly tracking-only and do not mutate wallet balances. Preserve this rule unless a separately designed contribution transaction model is implemented.
- Budget and savings progress display ratios use `Double`/`Float` for visual proportions. These are display-only calculations, not monetary storage; still prefer overflow-safe BigDecimal/ratio helpers for extreme values.
- Build configuration includes online-oriented Firebase, Retrofit, OkHttp and related dependencies although the app is currently offline-first. Do not remove blindly; inventory references and remove only after dependency graph/build verification.
- Room database is version 2 with a migration 1→2. Every schema change in this redesign requires an explicit migration and migration tests. Never use destructive migration.
- Existing project is a single Android module, not yet a Kotlin Multiplatform project. Do not perform a risky KMP conversion as part of the UI redesign.

## 3. Design system contract

### 3.1 Visual language

- Light theme: Pearl Light — warm white / cool pearl canvas, subtle blue-lavender-mint ambient light, crisp readable foreground.
- Dark theme: Midnight Glass — deep navy/charcoal canvas, restrained aurora lighting, high-contrast text and controlled translucency.
- Accent: aurora violet/blue/cyan/mint used sparingly; financial semantic colors are consistent and never communicated by color alone.
- Glass levels: Canvas / Frosted Control / Elevated Glass / Crystal Overlay. Avoid making every row a separate heavy card.
- True backdrop blur must be implemented only on supported API/device paths, with a documented fallback. Foreground text must never be blurred. Benchmark performance on the target phone.
- No huge decorative cards, excessive vertical gaps, repeated horizontal chip carousels, or redundant sections.

### 3.2 Typography

- English: Plus Jakarta Sans.
- Bangla: Hind Siliguri.
- Financial amounts: tabular numerals where supported.
- Dynamic type/font scaling and Bengali line-height must be tested. Bundle licensed font files in the app; no runtime font download.

### 3.3 Layout and touch

- 4/8-point spacing rhythm; consistent screen gutters and section spacing.
- Minimum 48dp interactive target, visible focus/pressed/disabled states.
- Primary action clear on each screen; secondary actions visually quieter.
- Bottom navigation remains Home / Activity / Quick Add / Wallets / More, with stable selected state for secondary pages and a predictable back stack.
- Sheets are keyboard-aware, scrollable, safe-area aware, and retain input state through configuration changes where appropriate.

## 4. Information architecture

### Primary navigation
1. Home — financial overview, quick actions, recent activity, wallet snapshot, budget and loan reminders.
2. Activity — searchable ledger, filters, date grouping, transaction detail and edit actions.
3. Quick Add — contextual entry point; opens dedicated Expense, Income, Transfer or Loan/Repayment flow.
4. Wallets — currency-separated wallet overview, detail, create/edit/archive and transfer entry.
5. More — grouped secondary destinations.

### More groups
- Financial management: People & Loans, Budgets, Savings Goals, Reports & Analytics.
- Tools & data: Categories, Audit History, Backup & Restore.
- App settings: Appearance, Privacy & Security, General Settings.
- Future online modules must be labeled as future and must not duplicate active offline features.

## 5. Screen requirements

### Home
- One clear primary balance context with explicit currency selector; never sum unlike currencies.
- Compact Income / Expense / Transfer actions.
- Recent transactions with View All.
- Wallet snapshot grouped by currency.
- Budget and savings progress, and upcoming loan reminders.
- New-user empty state with Create Wallet / Add First Transaction; no fake seeded records by default.

### Activity
- All / Income / Expense / Transfer / Loan filters (loan entries clearly separated from income/expense reports).
- Search across title, note, category, wallet and amount.
- Date range, wallet, category and currency filters; clear-all action.
- Group by local date; detail screen with complete provenance.
- Edit/delete with confirmation, undo where safe, and audit event.

### Quick Add
- Dedicated contextual flows; do not show irrelevant fields.
- Amount first, currency derived from selected wallet and clearly visible.
- Wallet selection via searchable bottom sheet/list, not long horizontal chip rail.
- Category picker as searchable categorized grid/list.
- Default date/time, optional note, advanced fields collapsed.
- Inline validation, idempotent submit, pending state, clear errors, success undo.
- Stable entity IDs, never selection indices.
- No demo fallback wallet in production path.

### Wallets
- Currency-grouped overview; no cross-currency total without explicit FX conversion.
- Create/edit/archive; wallet detail with ledger and balance reconciliation.
- Currency immutable after financial activity unless a reviewed migration/conversion flow exists.

### People & Loans
- People list with search, per-person detail and currency-separated balances.
- Add/edit/archive person.
- Lent / Borrowed loan creation with person, principal, currency, source/destination wallet, date, optional due date and note.
- Partial/full repayment history with structured loan ID.
- Overpayment prevention, no interest, clear receivable/payable treatment.
- Never classify loan principal as ordinary income/expense.

### Budgets & Savings
- Budgets by category/currency/period; period overlap validation and progress.
- Savings goals are tracking-only until a contribution model is explicitly approved; must not silently double-count wallet funds.

### Reports
- Daily/weekly/monthly/yearly/custom date intervals.
- Currency-separated income, expense and net totals.
- Category and wallet breakdown, trends, budget performance, loan receivable/payable view.
- PDF/CSV export; formula injection protection; selected scope and currency visible.

### Audit / Backup / Security
- Append-only audit history for financial mutations.
- User-controlled encrypted backup design with preview/dry-run, merge/skip duplicate/replace confirmation and rollback protection.
- Local app lock/biometric design with secure key storage; do not claim protection until implemented and tested.

## 6. Financial invariants

- Money persisted as integer minor units (`Long`) with exact arithmetic and BigInteger intermediates where required.
- Currency scale: JPY 0, standard 2, KWD 3.
- No Double/Float monetary calculations or storage.
- No aggregation across currencies without an explicit FX snapshot and conversion model.
- Income/expense updates and ledger insertion are atomic.
- Transfers atomically debit source and credit destination; fee handling explicit; cross-currency transfer remains unsupported until reviewed.
- Loan opening and repayment atomically update wallet, loan and structured repayment record.
- Loan overpayment is rejected; interest remains zero.
- Savings goals must not double-count wallet balances.
- Every financial mutation must be reversible or auditable according to a documented policy.

## 7. Delivery phases

### R0 — Baseline audit and specification
- Preserve exact Phase 21 source baseline.
- Produce evidence-based audit and master redesign spec.
- Inventory functions, Room schema, dependencies, and known verification gaps.

### R1 — Design foundation
- Tokenized typography, color, spacing, shapes, elevation, motion.
- Glass surface primitives with API-aware blur/fallback plan.
- Reusable inputs, pickers, buttons, sheets, empty/loading/error states.
- Light/dark parity and accessibility baseline.

### R2 — Core navigation and financial UX
- Navigation/back-stack stabilization.
- Home, Activity, Quick Add, Wallets redesign.

### R3 — People, Loans and Planning
- People, loan lifecycle, repayments, budgets, savings.

### R4 — Reports, audit, backup, settings
- Reports/export, audit history, backup/restore, security settings.

### R5 — QA and integration
- Room migrations, unit tests, UI tests, accounting reconciliation, device testing, performance and accessibility.
- Produce a new standalone build ZIP and a separate AI Studio continuation package/prompt. Do not overwrite the original AI Studio project.

## 8. Acceptance criteria

- Every visible control has a verified action or is explicitly disabled with explanation.
- No silent demo data in a fresh production profile.
- No fake wallet fallback can be submitted.
- No transaction/loan/transfer can partially update balances.
- Currency never mixes silently.
- No screen has clipped controls under keyboard, system bars or font scaling.
- All sheets/pickers share consistent behavior and visual language.
- Light and dark themes are equally complete.
- Back navigation returns to the expected previous destination.
- Full Gradle build, Room/KSP generation, unit tests, UI tests and real-device smoke tests are reported separately; never claim an unrun test passed.
