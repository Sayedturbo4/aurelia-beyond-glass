# AURELIA Phase 2 — Design System Foundation

## Scope delivered

This phase adds a reusable design foundation without replacing existing screens or changing financial/domain behavior.

### Added
- `ui/design/AureliaDesignTokens.kt`: centralized spacing, radii, touch targets and motion durations.
- `ui/components/AureliaPrimitives.kt`: reusable translucent surface, section header and action button primitives.
- Updated `ui/theme/Type.kt`: more consistent compact typography hierarchy and explicit Bengali-friendly line heights.
- Corrected a misleading comment in `GlassComponents.kt`: existing glass card rendering uses translucent fills, gradient borders and sheen; it is not backdrop blur.

## Important implementation truth

`AureliaGlassSurface` is a layered translucent alpha surface. It does **not** sample or blur pixels behind itself. True backdrop blur is deferred until a dedicated renderer can be validated on supported Android API levels and on-device for performance. No true blur claim is made in this phase.

The requested Plus Jakarta Sans and Hind Siliguri font files are not present in the supplied source archive. Typography therefore continues to use `FontFamily.Default` with a clear source comment. Licensed font assets must be added before switching to those families; no runtime font download is introduced.

## Compatibility and safety

- No Room entities, database version, DAO, repository, money engine, or financial posting logic changed.
- No navigation or existing screen flow changed.
- No existing feature removed.
- Existing components remain available; new primitives are additive.

## Verification status

- Source-level review completed for the added Kotlin files.
- Full Gradle/Android build, Compose compiler, Room/KSP generation, unit tests and device rendering have **not** been run in this environment because the working environment has no configured Android SDK and no Gradle wrapper executable/JAR in the supplied project.
- The next verification must run in the user's GitHub Actions cloud runner before merging this phase into the main APK build.

## Next phase

Phase 3: Home screen information architecture and implementation using the new tokens/primitives, preserving existing ViewModel/repository contracts and real data behavior.
