from pathlib import Path
root = Path(__file__).parent
base = root / 'app/src/main/java/com/example'
checks = {
    'contribution entity': 'data/local/FinanceEntities.kt',
    'contribution DAO': 'data/local/FinanceDao.kt',
    'Room migration 3 to 4': 'data/local/AureliaDatabase.kt',
    'atomic contribution persistence': 'data/local/FinanceLocalRepository.kt',
    'ViewModel contribution stream': 'ui/viewmodel/FinanceOverviewViewModel.kt',
    'Planning UI history and entry': 'ui/screens/PlanningScreen.kt',
}
needles = {
    'contribution entity': 'data class SavingsContributionEntity',
    'contribution DAO': 'interface SavingsContributionDao',
    'Room migration 3 to 4': 'MIGRATION_3_4',
    'atomic contribution persistence': 'savingsContributionDao().insert',
    'ViewModel contribution stream': 'val savingsContributions:',
    'Planning UI history and entry': 'Add Contribution',
}
for name, rel in checks.items():
    text = (base / rel).read_text()
    assert needles[name] in text, f'FAIL: {name}'
    print(f'PASS: {name}')
repo = (base / 'data/local/FinanceLocalRepository.kt').read_text()
assert 'database.withTransaction {' in repo and 'savingsContributionDao().deleteForGoal' in repo
print('PASS: transactional contribution and goal cleanup')
db = (base / 'data/local/AureliaDatabase.kt').read_text()
assert 'version = 4' in db and 'MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4' in db
print('PASS: complete Room migration chain')
