package com.example.domain.report

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class FinanceReportCalculatorTest {
  private val range = ReportDateRange(1_000L, 10_000L)

  private fun tx(
    id: String,
    type: String,
    amount: Long,
    currency: String = "BDT",
    category: String = "food",
    wallet: String = "cash",
    at: Long = 5_000L,
  ) = ReportTransaction(id, type, amount, currency, category, wallet, at)

  @Test fun incomeExpenseTotalsAndNetAreExact() {
    val report = FinanceReportCalculator.calculate(
      listOf(tx("1", "INCOME", 10_000), tx("2", "EXPENSE", 2_500)),
      mapOf("cash" to "Cash"), range,
    )
    val bdt = report.currencySummaries.single()
    assertEquals(10_000L, bdt.incomeMinorUnits)
    assertEquals(2_500L, bdt.expenseMinorUnits)
    assertEquals(7_500L, bdt.netMinorUnits)
  }

  @Test fun currenciesNeverCombine() {
    val report = FinanceReportCalculator.calculate(
      listOf(tx("1", "INCOME", 10_000, "BDT"), tx("2", "INCOME", 20_000, "USD")),
      emptyMap(), range,
    )
    assertEquals(listOf("BDT", "USD"), report.currencySummaries.map { it.currencyCode })
  }

  @Test fun transfersAndPeopleEntriesAreExcluded() {
    val report = FinanceReportCalculator.calculate(
      listOf(tx("1", "TRANSFER", 50_000), tx("2", "PEOPLE", 40_000)), emptyMap(), range,
    )
    assertEquals(0, report.includedTransactionCount)
    assertEquals(0, report.currencySummaries.size)
  }

  @Test fun dateRangeIsHalfOpen() {
    val report = FinanceReportCalculator.calculate(
      listOf(tx("before", "INCOME", 1, at = 999), tx("start", "INCOME", 2, at = 1_000), tx("end", "INCOME", 4, at = 10_000)),
      emptyMap(), range,
    )
    assertEquals(1, report.includedTransactionCount)
    assertEquals(2L, report.currencySummaries.single().incomeMinorUnits)
  }

  @Test fun categoryAndWalletBreakdownsAreSeparated() {
    val report = FinanceReportCalculator.calculate(
      listOf(
        tx("1", "EXPENSE", 100, category = "food", wallet = "cash"),
        tx("2", "EXPENSE", 300, category = "travel", wallet = "card"),
      ),
      mapOf("cash" to "Cash", "card" to "Card"), range,
    )
    assertEquals(listOf("travel", "food"), report.categoryExpenses.map { it.categoryId })
    assertEquals(setOf("Cash", "Card"), report.walletSummaries.map { it.walletName }.toSet())
  }

  @Test fun overflowFailsInsteadOfWrapping() {
    assertThrows(ArithmeticException::class.java) {
      FinanceReportCalculator.calculate(
        listOf(tx("1", "INCOME", Long.MAX_VALUE), tx("2", "INCOME", 1)), emptyMap(), range,
      )
    }
  }

  @Test fun currentMonthRangeUsesLocalCalendarAndHalfOpenBoundary() {
    val utc = TimeZone.getTimeZone("UTC")
    val instant = Calendar.getInstance(utc).apply {
      set(2026, Calendar.NOVEMBER, 3, 8, 50, 0)
      set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val month = FinanceReportCalculator.currentMonthRange(instant, utc)
    val start = Calendar.getInstance(utc).apply { timeInMillis = month.fromInclusiveMillis }
    val end = Calendar.getInstance(utc).apply { timeInMillis = month.untilExclusiveMillis }
    assertEquals(1, start.get(Calendar.DAY_OF_MONTH))
    assertEquals(Calendar.NOVEMBER, start.get(Calendar.MONTH))
    assertEquals(Calendar.DECEMBER, end.get(Calendar.MONTH))
    assertEquals(1, end.get(Calendar.DAY_OF_MONTH))
  }
  @Test fun dayWeekAndYearPresetsHaveExpectedBoundaries() {
    val utc = TimeZone.getTimeZone("UTC")
    val instant = Calendar.getInstance(utc).apply {
      set(2026, Calendar.NOVEMBER, 3, 8, 50, 0)
      set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val day = FinanceReportCalculator.currentDayRange(instant, utc)
    val dayStart = Calendar.getInstance(utc).apply { timeInMillis = day.fromInclusiveMillis }
    val dayEnd = Calendar.getInstance(utc).apply { timeInMillis = day.untilExclusiveMillis }
    assertEquals(3, dayStart.get(Calendar.DAY_OF_MONTH))
    assertEquals(4, dayEnd.get(Calendar.DAY_OF_MONTH))

    val week = FinanceReportCalculator.currentWeekRange(instant, utc)
    val weekStart = Calendar.getInstance(utc).apply { timeInMillis = week.fromInclusiveMillis }
    val weekEnd = Calendar.getInstance(utc).apply { timeInMillis = week.untilExclusiveMillis }
    assertEquals(Calendar.MONDAY, weekStart.get(Calendar.DAY_OF_WEEK))
    assertEquals(7, ((week.untilExclusiveMillis - week.fromInclusiveMillis) / 86_400_000L).toInt())
    assertEquals(Calendar.MONDAY, weekEnd.get(Calendar.DAY_OF_WEEK))

    val year = FinanceReportCalculator.currentYearRange(instant, utc)
    val yearStart = Calendar.getInstance(utc).apply { timeInMillis = year.fromInclusiveMillis }
    val yearEnd = Calendar.getInstance(utc).apply { timeInMillis = year.untilExclusiveMillis }
    assertEquals(Calendar.JANUARY, yearStart.get(Calendar.MONTH))
    assertEquals(1, yearStart.get(Calendar.DAY_OF_MONTH))
    assertEquals(2027, yearEnd.get(Calendar.YEAR))
  }

}
