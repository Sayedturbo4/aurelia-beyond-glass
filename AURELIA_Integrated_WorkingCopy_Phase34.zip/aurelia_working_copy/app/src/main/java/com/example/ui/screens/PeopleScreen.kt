package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataProvider
import com.example.data.MoneyEngine
import com.example.data.LoanItem
import com.example.data.LoanType
import com.example.data.PersonItem
import com.example.data.TransactionItem
import com.example.data.TransactionType
import com.example.data.local.PersonEntity
import com.example.data.local.LoanEntity
import com.example.ui.viewmodel.FinanceOverviewViewModel
import com.example.ui.components.AureliaBadge
import com.example.ui.components.AureliaGlassButton
import com.example.ui.components.AureliaGlassCard
import com.example.ui.components.GlassStyle
import com.example.ui.theme.AureliaThemeTokens
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PeopleScreen(
  viewModel: FinanceOverviewViewModel,
  isBalanceVisible: Boolean,
  onNavigateBack: () -> Unit,
  onOpenQuickAddWithPeople: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  var searchQuery by remember { mutableStateOf("") }
  var isAddPersonSheetOpen by remember { mutableStateOf(false) }
  var isAddLoanSheetOpen by remember { mutableStateOf(false) }
  var initialLoanPersonId by remember { mutableStateOf<String?>(null) }
  var selectedPersonDetails by remember { mutableStateOf<PersonItem?>(null) }
  var editingPerson by remember { mutableStateOf<PersonItem?>(null) }
  var editPersonName by remember { mutableStateOf("") }
  var editPersonPhone by remember { mutableStateOf("") }
  var editPersonEmail by remember { mutableStateOf("") }
  var personActionError by remember { mutableStateOf<String?>(null) }
  var confirmArchivePerson by remember { mutableStateOf<PersonItem?>(null) }
  var loanToRepay by remember { mutableStateOf<LoanItem?>(null) }

  val addPersonSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val addLoanSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val personDetailSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val repaySheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val peopleRows by viewModel.people.collectAsState()
  val archivedPeopleRows by viewModel.archivedPeople.collectAsState()
  val loanRows by viewModel.loans.collectAsState()
  val walletRows by viewModel.wallets.collectAsState()
  var isSavingPerson by remember { mutableStateOf(false) }
  var isSavingRepayment by remember { mutableStateOf(false) }
  var isSavingLoan by remember { mutableStateOf(false) }

  val people = remember(peopleRows) {
    peopleRows.map { PersonItem(it.id, it.name, it.phone, it.email) }
  }
  val loans = remember(loanRows, peopleRows) {
    val names = peopleRows.associate { it.id to it.name }
    loanRows.mapNotNull { row ->
      val type = when (row.type) {
        "LENT" -> LoanType.LENT
        "BORROWED" -> LoanType.BORROWED
        else -> null
      }
      type?.let {
        LoanItem(row.id, row.personId, names[row.personId] ?: "Unknown person", it,
          row.principalMinorUnits, row.repaidMinorUnits, row.currencyCode,
          java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(java.util.Date(row.openedAtMillis)),
          row.dueAtMillis?.let { due -> java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(java.util.Date(due)) }, row.note)
      }
    }
  }
  val totalLent = loans.filter { it.type == LoanType.LENT && !it.isClosed && it.currencyCode == "BDT" }
    .fold(0L) { total, loan -> Math.addExact(total, loan.outstandingMinorUnits) }
  val totalBorrowed = loans.filter { it.type == LoanType.BORROWED && !it.isClosed && it.currencyCode == "BDT" }
    .fold(0L) { total, loan -> Math.addExact(total, loan.outstandingMinorUnits) }
  val filteredPeople = people.filter {
    it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery)
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1 & 2. Header & Subtitle
    item {
      Spacer(modifier = Modifier.height(4.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = onNavigateBack,
          modifier = Modifier.size(44.dp),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = colors.textPrimary,
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Column {
          Text(
            text = "People & Loans",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
          )
          Text(
            text = "Zero-interest peer-to-peer debt ledger",
            fontSize = 13.sp,
            color = colors.textSecondary,
          )
        }
      }
    }

    // 3. Clearly Visible Horizontal Add Person Button
    item {
      AureliaGlassButton(
        text = "+ Add New Person",
        onClick = { isAddPersonSheetOpen = true },
        icon = Icons.Default.PersonAdd,
        isPrimary = true,
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp),
      )
    }

    // 4, 5, 6, 7. Loan Overview Card (Total Outstanding, Money Lent, Money Borrowed)
    item {
      val netBalance = totalLent - totalBorrowed
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.PEARL,
        shape = RoundedCornerShape(24.dp),
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        ) {
          // Total Outstanding Net
          Text(
            text = "Total Outstanding (Net)",
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = colors.textSecondary,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            val prefix = if (netBalance > 0) "+" else if (netBalance < 0) "-" else ""
            val netColor = if (netBalance > 0) colors.auroraBlue else if (netBalance < 0) colors.auroraRose else colors.financialIncome
            Text(
              text = "$prefix${DemoDataProvider.formatMoney(kotlin.math.abs(netBalance), "BDT", isBalanceVisible)}",
              fontSize = 26.sp,
              fontWeight = FontWeight.Bold,
              color = netColor,
            )
            AureliaBadge(
              text = if (netBalance > 0) "Net Receivable" else if (netBalance < 0) "Net Payable" else "All Settled",
              color = netColor,
            )
          }

          Spacer(modifier = Modifier.height(16.dp))
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(1.dp)
              .background(colors.borderFrosted.copy(alpha = 0.35f)),
          )
          Spacer(modifier = Modifier.height(14.dp))

          // Money Lent vs Money Borrowed
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(colors.auroraBlue),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Money Lent",
                  fontSize = 12.sp,
                  color = colors.textSecondary,
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = DemoDataProvider.formatMoney(totalLent, "BDT", isBalanceVisible),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = colors.auroraBlue,
              )
              Text(
                text = "Receivable from others",
                fontSize = 10.sp,
                color = colors.textSecondary.copy(alpha = 0.8f),
              )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(colors.auroraRose),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Money Borrowed",
                  fontSize = 12.sp,
                  color = colors.textSecondary,
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = DemoDataProvider.formatMoney(totalBorrowed, "BDT", isBalanceVisible),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = colors.auroraRose,
              )
              Text(
                text = "Payable to others",
                fontSize = 10.sp,
                color = colors.textSecondary.copy(alpha = 0.8f),
              )
            }
          }
        }
      }
    }

    // 8. Search Field
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search contact name or phone...", color = colors.textSecondary.copy(alpha = 0.6f)) },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = colors.textSecondary,
          )
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = colors.textSecondary)
            }
          }
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.60f else 0.85f),
          unfocusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.45f else 0.70f),
          focusedBorderColor = colors.auroraLavender,
          unfocusedBorderColor = colors.borderFrosted.copy(alpha = 0.50f),
          focusedTextColor = colors.textPrimary,
          unfocusedTextColor = colors.textPrimary,
        ),
      )
    }

    // 9 & 10. People List with Navigation
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "All Contacts (${filteredPeople.size})",
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textPrimary,
        )
        Text(
          text = "Tap contact for details",
          fontSize = 12.sp,
          color = colors.textSecondary,
        )
      }
    }

    if (filteredPeople.isEmpty()) {
      item {
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(18.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(
              text = "No contact found matching '$searchQuery'",
              fontSize = 14.sp,
              color = colors.textSecondary,
            )
          }
        }
      }
    } else {
      items(filteredPeople) { person ->
        val personLoans = loans.filter { it.personId == person.id }
        val openLoans = personLoans.filter { !it.isClosed }
        val lentSum = openLoans.filter { it.type == LoanType.LENT }.sumOf { it.outstandingMinorUnits }
        val borrowedSum = openLoans.filter { it.type == LoanType.BORROWED }.sumOf { it.outstandingMinorUnits }
        val netPersonBalance = lentSum - borrowedSum

        AureliaGlassCard(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("person_item_${person.id}"),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(20.dp),
          onClick = { selectedPersonDetails = person },
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f),
            ) {
              Box(
                modifier = Modifier
                  .size(46.dp)
                  .clip(CircleShape)
                  .background(colors.auroraLavender.copy(alpha = 0.28f)),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = person.name.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                  fontWeight = FontWeight.Bold,
                  color = colors.textPrimary,
                  fontSize = 16.sp,
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column {
                Text(
                  text = person.name,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = colors.textPrimary,
                )
                if (person.phone.isNotBlank()) {
                  Text(text = person.phone, fontSize = 11.sp, color = colors.textSecondary)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  if (netPersonBalance > 0) {
                    AureliaBadge(text = "Owes You", color = colors.auroraBlue)
                  } else if (netPersonBalance < 0) {
                    AureliaBadge(text = "You Owe", color = colors.auroraRose)
                  } else {
                    AureliaBadge(text = "Settled", color = colors.financialIncome)
                  }
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "${openLoans.size} active",
                    fontSize = 11.sp,
                    color = colors.textSecondary,
                  )
                }
              }
            }

            // Outstanding Balance display
            Column(horizontalAlignment = Alignment.End) {
              val formattedAmount = DemoDataProvider.formatMoney(
                minorUnits = kotlin.math.abs(netPersonBalance),
                currencyCode = "BDT",
                isVisible = isBalanceVisible,
              )
              if (netPersonBalance > 0) {
                Text(
                  text = "+$formattedAmount",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = colors.auroraBlue,
                )
                Text(
                  text = "Receivable",
                  fontSize = 10.sp,
                  color = colors.textSecondary,
                )
              } else if (netPersonBalance < 0) {
                Text(
                  text = "-$formattedAmount",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = colors.auroraRose,
                )
                Text(
                  text = "Payable",
                  fontSize = 10.sp,
                  color = colors.textSecondary,
                )
              } else {
                Text(
                  text = "৳ 0.00",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Medium,
                  color = colors.textSecondary,
                )
                Text(
                  text = "No debt",
                  fontSize = 10.sp,
                  color = colors.textSecondary,
                )
              }
            }
          }
        }
      }
    }

    if (archivedPeopleRows.isNotEmpty()) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("Archived people", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
          Text("Restore a contact to make it available for new loans again.", fontSize = 12.sp, color = colors.textSecondary)
        }
      }
      items(archivedPeopleRows, key = { "archived-person-${it.id}" }) { archived ->
        AureliaGlassCard(modifier = Modifier.fillMaxWidth(), glassStyle = GlassStyle.PEARL, shape = RoundedCornerShape(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(archived.name, color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
              Text("Archived contact", color = colors.textSecondary, fontSize = 12.sp)
            }
            TextButton(onClick = {
              viewModel.restorePerson(archived.id, System.currentTimeMillis()) { result ->
                if (result.isFailure) personActionError = result.exceptionOrNull()?.message ?: "Could not restore person"
              }
            }) { Text("Restore") }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(84.dp))
    }
  }

  // 1. ADD PERSON MODAL SHEET
  if (isAddPersonSheetOpen) {
    var newName by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newEmail by remember { mutableStateOf("") }
    var addError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
      onDismissRequest = { isAddPersonSheetOpen = false },
      sheetState = addPersonSheetState,
      containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
      shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 24.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(text = "Add Contact Person", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
          IconButton(onClick = { isAddPersonSheetOpen = false }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = colors.textSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
          value = newName,
          onValueChange = {
            newName = it
            addError = null
          },
          label = { Text("Full Name *") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = newPhone,
          onValueChange = { newPhone = it },
          label = { Text("Phone Number (Optional)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = newEmail,
          onValueChange = { newEmail = it },
          label = { Text("Email Address (Optional)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
        )

        if (addError != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = addError!!, color = colors.financialExpense, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        AureliaGlassButton(
          text = if (isSavingPerson) "Saving..." else "Save Person",
          onClick = {
            if (isSavingPerson) return@AureliaGlassButton
            if (newName.isBlank()) {
              addError = "Please enter a valid person name"
              return@AureliaGlassButton
            }
            isSavingPerson = true
            viewModel.createPerson(
              PersonEntity(
                id = "p_${UUID.randomUUID()}",
                name = newName.trim(),
                phone = newPhone.trim(),
                email = newEmail.trim(),
                createdAtMillis = System.currentTimeMillis(),
                updatedAtMillis = System.currentTimeMillis(),
              ),
            ) { result ->
              isSavingPerson = false
              result.onSuccess { isAddPersonSheetOpen = false }
                .onFailure { addError = it.message ?: "Could not save person" }
            }
          },
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  // 2. DATABASE-BACKED ADD LOAN SHEET
  if (isAddLoanSheetOpen) {
    var selectedPersonId by remember(initialLoanPersonId) { mutableStateOf(initialLoanPersonId ?: people.firstOrNull()?.id.orEmpty()) }
    var loanType by remember { mutableStateOf("LENT") }
    var amountText by remember { mutableStateOf("") }
    var selectedWalletId by remember { mutableStateOf(walletRows.firstOrNull()?.id.orEmpty()) }
    var note by remember { mutableStateOf("") }
    var loanError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
      onDismissRequest = { isAddLoanSheetOpen = false },
      sheetState = addLoanSheetState,
      containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
      shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp),
      ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Add Loan", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
          IconButton(onClick = { isAddLoanSheetOpen = false }) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = colors.textSecondary)
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text("Loan direction", fontSize = 12.sp, color = colors.textSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          AureliaGlassButton(text = "I Lent", onClick = { loanType = "LENT" }, isPrimary = loanType == "LENT", modifier = Modifier.weight(1f))
          AureliaGlassButton(text = "I Borrowed", onClick = { loanType = "BORROWED" }, isPrimary = loanType == "BORROWED", modifier = Modifier.weight(1f))
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text("Person", fontSize = 12.sp, color = colors.textSecondary)
        if (people.isEmpty()) {
          Text("Add a person before creating a loan.", color = colors.financialExpense, fontSize = 12.sp)
        } else {
          val selectedPerson = people.firstOrNull { it.id == selectedPersonId } ?: people.first()
          Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(colors.surfaceGlass).clickable {
            val index = people.indexOfFirst { it.id == selectedPerson.id }
            selectedPersonId = people[(index + 1) % people.size].id
          }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${selectedPerson.name}  ·  Tap to change", color = colors.textPrimary, fontSize = 14.sp)
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(value = amountText, onValueChange = { amountText = it; loanError = null }, label = { Text("Principal amount *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        Spacer(modifier = Modifier.height(10.dp))
        Text("Wallet (currency is taken from wallet)", fontSize = 12.sp, color = colors.textSecondary)
        val matchingWallets = walletRows.filter { !it.isArchived }
        if (matchingWallets.isEmpty()) {
          Text("Create a wallet before adding a loan.", color = colors.financialExpense, fontSize = 12.sp)
        } else {
          val selectedWallet = matchingWallets.firstOrNull { it.id == selectedWalletId } ?: matchingWallets.first()
          Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(colors.surfaceGlass).clickable {
            val index = matchingWallets.indexOfFirst { it.id == selectedWallet.id }
            selectedWalletId = matchingWallets[(index + 1) % matchingWallets.size].id
          }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${selectedWallet.name}  ·  ${selectedWallet.currencyCode}  ·  Tap to change", color = colors.textPrimary, fontSize = 14.sp)
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
        if (loanError != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(loanError!!, color = colors.financialExpense, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))
        AureliaGlassButton(
          text = if (isSavingLoan) "Saving..." else "Save Loan",
          onClick = {
            if (isSavingLoan) return@AureliaGlassButton
            try {
              require(people.isNotEmpty()) { "Add a person first" }
              require(selectedPersonId.isNotBlank()) { "Select a person" }
              require(matchingWallets.isNotEmpty()) { "Create a wallet first" }
              val selectedWallet = matchingWallets.firstOrNull { it.id == selectedWalletId } ?: matchingWallets.first()
              val code = selectedWallet.currencyCode
              val amountMinor = MoneyEngine.parseMajorToMinor(amountText, code)
              MoneyEngine.validatePositive(amountMinor)
              isSavingLoan = true
              val now = System.currentTimeMillis()
              viewModel.createLoan(
                LoanEntity(
                  id = "loan_${UUID.randomUUID()}", personId = selectedPersonId, type = loanType,
                  principalMinorUnits = amountMinor, repaidMinorUnits = 0L, currencyCode = code,
                  openedAtMillis = now, note = note.trim(), createdAtMillis = now, updatedAtMillis = now,
                ),
                selectedWallet.id,
              ) { result ->
                isSavingLoan = false
                result.onSuccess { isAddLoanSheetOpen = false; initialLoanPersonId = null }
                  .onFailure { loanError = it.message ?: "Could not save loan" }
              }
            } catch (error: Exception) {
              loanError = error.message ?: "Check the loan details"
            }
          },
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  // 2. PROPER PERSON DETAILS PROFILE SHEET
  if (selectedPersonDetails != null) {
    val person = selectedPersonDetails!!
    val personLoans = loans.filter { it.personId == person.id }
    val openLoans = personLoans.filter { !it.isClosed }
    // The overview card is explicitly BDT; never combine balances from different currencies.
    val lentSum = openLoans.filter { it.type == LoanType.LENT && it.currencyCode == "BDT" }
      .fold(0L) { total, item -> Math.addExact(total, item.outstandingMinorUnits) }
    val borrowedSum = openLoans.filter { it.type == LoanType.BORROWED && it.currencyCode == "BDT" }
      .fold(0L) { total, item -> Math.addExact(total, item.outstandingMinorUnits) }

    ModalBottomSheet(
      onDismissRequest = { selectedPersonDetails = null },
      sheetState = personDetailSheetState,
      containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
      shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 24.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(colors.auroraLavender.copy(alpha = 0.35f)),
              contentAlignment = Alignment.Center,
            ) {
              Text(text = person.name.take(1), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = colors.textPrimary)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
              Text(text = person.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
              if (person.phone.isNotBlank()) {
                Text(text = person.phone, fontSize = 12.sp, color = colors.textSecondary)
              }
            }
          }
          IconButton(onClick = { selectedPersonDetails = null }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = colors.textSecondary)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          AureliaGlassButton(
            text = "Edit person",
            isPrimary = false,
            onClick = {
              editPersonName = person.name
              editPersonPhone = person.phone
              editPersonEmail = person.email
              personActionError = null
              editingPerson = person
            },
            modifier = Modifier.weight(1f),
          )
          AureliaGlassButton(
            text = "Archive",
            isPrimary = false,
            onClick = { personActionError = null; confirmArchivePerson = person },
            modifier = Modifier.weight(1f),
          )
        }
        personActionError?.let { message ->
          Spacer(modifier = Modifier.height(6.dp))
          Text(message, color = colors.financialExpense, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))

        // 3 Summary Metrics: Lent | Borrowed | Net Outstanding
        val netOutstanding = Math.subtractExact(lentSum, borrowedSum)
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.PEARL,
          shape = RoundedCornerShape(20.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(text = "Net Outstanding", fontSize = 12.sp, color = colors.textSecondary)
              val netColor = if (netOutstanding > 0) colors.auroraBlue else if (netOutstanding < 0) colors.auroraRose else colors.financialIncome
              val prefix = if (netOutstanding > 0) "+ " else if (netOutstanding < 0) "- " else ""
              Text(
                text = "$prefix${DemoDataProvider.formatMoney(kotlin.math.abs(netOutstanding), "BDT", isBalanceVisible)}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = netColor,
              )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(colors.borderFrosted.copy(alpha = 0.35f)),
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column {
                Text(text = "Total Lent", fontSize = 11.sp, color = colors.textSecondary)
                Text(
                  text = DemoDataProvider.formatMoney(lentSum, "BDT", isBalanceVisible),
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = colors.auroraBlue,
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "Total Borrowed", fontSize = 11.sp, color = colors.textSecondary)
                Text(
                  text = DemoDataProvider.formatMoney(borrowedSum, "BDT", isBalanceVisible),
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = colors.auroraRose,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Loans List
        Text(text = "Loan Records (${personLoans.size})", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        Spacer(modifier = Modifier.height(8.dp))

        if (personLoans.isEmpty()) {
          Text(text = "No loan records found for this contact.", fontSize = 12.sp, color = colors.textSecondary)
        } else {
          personLoans.forEach { loan ->
            AureliaGlassCard(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              glassStyle = GlassStyle.SMOKE,
              shape = RoundedCornerShape(16.dp),
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "${if (loan.type == LoanType.LENT) "Lent" else "Borrowed"} • ${loan.dateFormatted}",
                      fontSize = 13.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = if (loan.type == LoanType.LENT) colors.auroraBlue else colors.auroraRose,
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (loan.isClosed) {
                      AureliaBadge(text = "Paid Off", color = colors.financialIncome)
                    }
                  }
                  Text(
                    text = "Outstanding: ${DemoDataProvider.formatMoney(loan.outstandingMinorUnits, loan.currencyCode, isBalanceVisible)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = colors.textPrimary,
                  )
                  if (loan.repaidMinorUnits > 0) {
                    Text(
                      text = "Repaid: ${DemoDataProvider.formatMoney(loan.repaidMinorUnits, loan.currencyCode, isBalanceVisible)}",
                      fontSize = 11.sp,
                      color = colors.financialIncome,
                    )
                  }
                  if (loan.note.isNotBlank()) {
                    Text(text = loan.note, fontSize = 11.sp, color = colors.textSecondary)
                  }
                }
                if (!loan.isClosed) {
                  AureliaGlassButton(
                    text = "Repay",
                    isPrimary = true,
                    onClick = {
                      loanToRepay = loan
                    },
                    modifier = Modifier.defaultMinSize(minHeight = 36.dp),
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Repayment History Section
        val loansWithRepayments = personLoans.filter { it.repaidMinorUnits > 0 }
        if (loansWithRepayments.isNotEmpty()) {
          Text(text = "Repayment History", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
          Spacer(modifier = Modifier.height(6.dp))
          loansWithRepayments.forEach { rLoan ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "Repayment on ${rLoan.note}",
                fontSize = 12.sp,
                color = colors.textSecondary,
              )
              Text(
                text = "+${DemoDataProvider.formatMoney(rLoan.repaidMinorUnits, rLoan.currencyCode, isBalanceVisible)}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.financialIncome,
              )
            }
          }
          Spacer(modifier = Modifier.height(14.dp))
        }

        // Action Buttons: + Add Loan and Record Repayment
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          AureliaGlassButton(
            text = "+ Add Loan",
            onClick = {
              initialLoanPersonId = selectedPersonDetails?.id
              selectedPersonDetails = null
              isAddLoanSheetOpen = true
            },
            isPrimary = true,
            modifier = Modifier.weight(1f),
          )
          val firstOpenLoan = openLoans.firstOrNull()
          if (firstOpenLoan != null) {
            AureliaGlassButton(
              text = "Repay Loan",
              onClick = {
                loanToRepay = firstOpenLoan
              },
              isPrimary = false,
              modifier = Modifier.weight(1f),
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  if (editingPerson != null) {
    AlertDialog(
      onDismissRequest = { editingPerson = null },
      title = { Text("Edit person") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = editPersonName, onValueChange = { editPersonName = it }, label = { Text("Full name") }, singleLine = true)
          OutlinedTextField(value = editPersonPhone, onValueChange = { editPersonPhone = it }, label = { Text("Phone (optional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
          OutlinedTextField(value = editPersonEmail, onValueChange = { editPersonEmail = it }, label = { Text("Email (optional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
          personActionError?.let { Text(it, color = colors.financialExpense, fontSize = 12.sp) }
        }
      },
      confirmButton = {
        TextButton(onClick = {
          val selected = editingPerson ?: return@TextButton
          val existing = peopleRows.firstOrNull { it.id == selected.id }
          if (editPersonName.isBlank()) {
            personActionError = "Name is required"
          } else if (existing == null) {
            personActionError = "Person record could not be found"
          } else {
            viewModel.updatePerson(
              existing.copy(name = editPersonName.trim(), phone = editPersonPhone.trim(), email = editPersonEmail.trim()),
              System.currentTimeMillis(),
            ) { result ->
              result.onSuccess { editingPerson = null; selectedPersonDetails = null; personActionError = null }
                .onFailure { personActionError = it.message ?: "Could not update person" }
            }
          }
        }) { Text("Save changes") }
      },
      dismissButton = { TextButton(onClick = { editingPerson = null }) { Text("Cancel") } },
    )
  }

  if (confirmArchivePerson != null) {
    val target = confirmArchivePerson!!
    AlertDialog(
      onDismissRequest = { confirmArchivePerson = null },
      title = { Text("Archive ${target.name}?") },
      text = { Text("This hides the person from the active list but keeps historical records. All outstanding loans must be settled first.") },
      confirmButton = {
        TextButton(onClick = {
          viewModel.archivePerson(target.id, System.currentTimeMillis()) { result ->
            result.onSuccess { confirmArchivePerson = null; selectedPersonDetails = null; personActionError = null }
              .onFailure { personActionError = it.message ?: "Could not archive person"; confirmArchivePerson = null }
          }
        }) { Text("Archive") }
      },
      dismissButton = { TextButton(onClick = { confirmArchivePerson = null }) { Text("Cancel") } },
    )
  }

  // 3. REPAYMENT MODAL (With Overpayment Validation)
  if (loanToRepay != null) {
    val loan = loanToRepay!!
    var repayAmountInput by remember { mutableStateOf("") }
    var repayError by remember { mutableStateOf<String?>(null) }
    val repaymentWallet = walletRows.firstOrNull { it.currencyCode == loan.currencyCode && !it.isArchived }

    ModalBottomSheet(
      onDismissRequest = { loanToRepay = null },
      sheetState = repaySheetState,
      containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
      shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 24.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(text = "Record Loan Repayment", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
          IconButton(onClick = { loanToRepay = null }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = colors.textSecondary)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.AURORA,
          shape = RoundedCornerShape(18.dp),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Person: ${loan.personName}",
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Outstanding Balance: ${DemoDataProvider.formatMoney(loan.outstandingMinorUnits, loan.currencyCode, isBalanceVisible)}",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = if (loan.type == LoanType.LENT) colors.auroraBlue else colors.auroraRose,
            )
            Text(
              text = "Previously Repaid: ${DemoDataProvider.formatMoney(loan.repaidMinorUnits, loan.currencyCode, isBalanceVisible)}",
              fontSize = 12.sp,
              color = colors.textSecondary,
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = repayAmountInput,
          onValueChange = {
            repayAmountInput = it.filter { c -> c.isDigit() || c == '.' }
            repayError = null
          },
          label = { Text("Repayment Amount (${loan.currencyCode})") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
        )

        if (repayError != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = repayError!!, color = colors.financialExpense, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(18.dp))

        AureliaGlassButton(
          text = if (isSavingRepayment) "Saving..." else "Confirm Repayment",
          onClick = {
            if (isSavingRepayment) return@AureliaGlassButton
            val minor = try {
              MoneyEngine.parseMajorToMinor(repayAmountInput, loan.currencyCode).also {
                MoneyEngine.validateRepayment(it, loan.outstandingMinorUnits)
              }
            } catch (error: IllegalArgumentException) {
              repayError = error.message ?: "Enter a valid repayment amount"
              return@AureliaGlassButton
            } catch (error: ArithmeticException) {
              repayError = "Repayment is outside the supported range"
              return@AureliaGlassButton
            }

            if (repaymentWallet == null) {
              repayError = "No active ${loan.currencyCode} wallet is available"
              return@AureliaGlassButton
            }
            isSavingRepayment = true
            viewModel.recordLoanRepayment(
              loanId = loan.id,
              amountMinorUnits = minor,
              walletId = repaymentWallet.id,
              occurredAtMillis = System.currentTimeMillis(),
              transactionId = "tx_${UUID.randomUUID()}",
              nowMillis = System.currentTimeMillis(),
            ) { result ->
              isSavingRepayment = false
              result.onSuccess { loanToRepay = null }
                .onFailure { repayError = it.message ?: "Could not record repayment" }
            }
          },
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(14.dp))
      }
    }
  }
}
