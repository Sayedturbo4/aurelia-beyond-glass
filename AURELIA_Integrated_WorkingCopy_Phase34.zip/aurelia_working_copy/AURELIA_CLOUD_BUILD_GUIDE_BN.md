# AURELIA — GitHub Cloud Build Guide (বাংলা)

## উদ্দেশ্য

এই repository-তে `.github/workflows/android-debug.yml` GitHub Actions workflow যোগ করা হয়েছে। এটি GitHub-এর cloud runner-এ Java 21, Android SDK এবং Gradle 9.3.1 প্রস্তুত করে Unit Test চালাবে এবং Debug APK তৈরি করবে। স্থানীয় PC/Android Studio প্রয়োজন হবে না।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- এই workflow কেবল **Debug APK** তৈরি করে; Play Store Release APK/AAB নয়।
- Release signing key বা password GitHub repository-তে upload করা যাবে না।
- Workflow এখনো বাস্তবে GitHub-এ run করা হয়নি; প্রথম run-এর output-ই প্রকৃত compiler verdict দেবে।
- `compileSdk` বর্তমানে Android API 36 minor API level 1 চায়। Workflow-এ Android platform 36 ইনস্টল করা হয়েছে; runner-এ minor API extension অনুপস্থিত থাকলে build log অনুযায়ী SDK package/configuration সমন্বয় করতে হবে।
- Project-এ `gradlew` ও `gradle-wrapper.jar` নেই। এই প্রথম CI workflow system Gradle 9.3.1 install করে সরাসরি `gradle` command ব্যবহার করে। Build stable হলে official Gradle wrapper যোগ করা হবে।

## Android ফোন থেকে ব্যবহার

1. GitHub-এ একটি **Private repository** তৈরি করো, যেমন `aurelia-beyond-glass`।
2. Phase 20/পরবর্তী প্রস্তুত ZIP extract করে project-এর ভেতরের সব file ও folder repository root-এ upload করো। `.github` folder-সহ hidden files upload হয়েছে কি না নিশ্চিত করো।
3. `.env` বা কোনো release keystore/password/token upload করবে না। `.env.example` রাখা যাবে।
4. GitHub repository-র **Actions** tab খোলো।
5. `AURELIA Android Debug Build` workflow নির্বাচন করো।
6. **Run workflow** চাপো, branch `main` নির্বাচন করে আবার Run workflow চাপো।
7. Run শেষ হলে `debug-build` job-এর log দেখো। কোনো ধাপে লাল error হলে সেটির সম্পূর্ণ error text কপি করে ChatGPT-তে পাঠাও।
8. সফল হলে workflow run-এর **Artifacts** অংশ থেকে `aurelia-debug-apk-...` download করো। ZIP extract করে APK ফোনে install করো।

## প্রথম Build-এ কী যাচাই হবে

- Gradle plugin ও dependency resolution
- Android SDK / compileSdk availability
- Kotlin ও Compose compilation
- KSP ও Room code generation
- Unit test compilation/execution
- Debug APK packaging/signing

## নিরাপত্তা

- Repository private রাখার পরামর্শ দেওয়া হচ্ছে, যতক্ষণ না source code প্রকাশের সিদ্ধান্ত নেওয়া হয়।
- `.env`, `google-services.json` (যদি পরে sensitive project config থাকে), `*.jks`, `*.keystore`, signing passwords বা API secrets commit করবে না।
- বর্তমান workflow debug build-এর জন্য কোনো GitHub secret চায় না।
- `debug.keystore` কেবল debug signing-এর জন্য; production signing key নয়।
- AURELIA-এর original Google AI Studio project এই working copy workflow দ্বারা পরিবর্তিত হয় না।

## Build সফল হলে পরবর্তী QA

1. APK install ও cold launch
2. Person/Wallet/Loan তৈরি করে app restart persistence পরীক্ষা
3. Income, Expense, Transfer ও Repayment হিসাব পরীক্ষা
4. Budget ও Savings Goal পরীক্ষা
5. Reports date/currency filter পরীক্ষা
6. PDF/CSV share এবং Android Save picker পরীক্ষা
7. Database migration ও offline behaviour পরীক্ষা
