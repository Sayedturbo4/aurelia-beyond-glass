# AURELIA Phase 3 — Home Dashboard Redesign

## Scope
This phase replaces the old Home dashboard UI in the isolated ChatGPT Working Copy. It does not modify the Google AI Studio original project or the user's GitHub repository.

## Implemented
- Removed the hardcoded personal greeting/name.
- Replaced the 13-page currency swipe carousel plus duplicate currency chip row with one compact currency selector containing only currencies that have active wallets.
- Preserved currency separation: wallet balances are summed only for the selected currency. No exchange-rate conversion or cross-currency aggregation is performed.
- Rebuilt the balance hero with a clearer hierarchy, privacy toggle, active wallet count and three primary actions (Income, Expense, Transfer).
- Added consistent section headers and more compact wallet rows.
- Added contextual wallet empty state and a compact overflow link when more than two wallets exist.
- Added People & Loans shortcut.
- Added currency-specific outstanding loan summary (lent/to receive and borrowed/to repay), using the domain Loan outstanding amount and direction.
- Rebuilt recent activity rows with category, wallet, date/time and type-aware amount treatment.
- Preserved navigation callbacks to Wallets, Activity, People, Planning and Quick Add.
- Added/retained test tags for key Home controls.
- Kept balance privacy masking consistent across balance, wallet, transaction and loan values.

## Important correctness decisions
- The dashboard does not display an income/expense period total because the Home input currently represents the latest transaction projection, not necessarily the complete ledger. Showing it as a full-period total could mislead users.
- The selected currency defaults to BDT when available; otherwise it falls back to the first currency with an active wallet.
- Currency totals use exact Long addition with Math.addExact. Overflow is not silently wrapped.
- The loan summary excludes archived and fully repaid loans and keeps currency buckets separate.

## Files changed
- `app/src/main/java/com/example/ui/screens/HomeScreen.kt`
- `app/src/main/java/com/example/MainActivity.kt`

## Verification performed
- Source-level review of all HomeScreen parameters and MainActivity call site.
- Checked domain Loan model fields and enum values against the implementation.
- Checked currency/wallet/transaction model fields against the implementation.
- Checked referenced theme token names and design component signatures against the project.
- Checked that the former hardcoded greeting, 13-page pager and duplicate currency chip list are removed.
- Checked source delimiter balance and required callback wiring with a local static script.

## Not verified
- Full Android/Compose compilation.
- KSP/Room compilation.
- Emulator or physical-device rendering, blur behavior, font scaling and touch interaction.
- End-to-end Quick Add, navigation and persistence on device.

The current container does not have Gradle installed and this source archive has no Gradle wrapper executable/JAR. Do not describe this phase as Android-build verified until GitHub Actions or Android Studio successfully compiles it.

## Next phase
Phase 4: Quick Add Transaction redesign and functional validation. Before that, run this phase through the existing GitHub Actions cloud build using a separately updated working-copy ZIP; do not overwrite the AI Studio source checkpoint.
