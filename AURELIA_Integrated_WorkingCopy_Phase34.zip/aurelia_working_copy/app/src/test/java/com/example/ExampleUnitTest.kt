package com.example

import com.example.data.DemoDataProvider
import com.example.data.LoanItem
import com.example.data.LoanType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun testMoneyFormatting_standardDecimals() {
    val formattedUsd = DemoDataProvider.formatMoney(185000L, "USD")
    assertEquals("$ 1,850.00", formattedUsd)

    val formattedBdt = DemoDataProvider.formatMoney(7500000L, "BDT")
    assertEquals("৳ 75,000.00", formattedBdt)
  }

  @Test
  fun testMoneyFormatting_zeroDecimals_JPY() {
    val formattedJpy = DemoDataProvider.formatMoney(120000L, "JPY")
    assertEquals("¥ 120,000", formattedJpy)
  }

  @Test
  fun testMoneyFormatting_threeDecimals_KWD() {
    val formattedKwd = DemoDataProvider.formatMoney(850250L, "KWD")
    assertEquals("KD 850.250", formattedKwd)
  }

  @Test
  fun testMoneyFormatting_privacyMasked() {
    val masked = DemoDataProvider.formatMoney(185000L, "USD", isVisible = false)
    assertEquals("••••••", masked)
  }

  @Test
  fun testAll13CurrenciesSupported() {
    assertEquals(13, DemoDataProvider.supportedCurrencies.size)
    val codes = DemoDataProvider.supportedCurrencies.map { it.code }
    val expected = listOf("BDT", "USD", "EUR", "GBP", "INR", "SAR", "AED", "MYR", "SGD", "CAD", "AUD", "KWD", "JPY")
    assertEquals(expected, codes)
  }

  @Test
  fun testLoanOutstandingCalculations() {
    val loan = LoanItem(
      id = "test_l1",
      personId = "p1",
      personName = "Rahat Khan",
      type = LoanType.LENT,
      principalMinorUnits = 1500000L, // 15,000 BDT
      repaidMinorUnits = 500000L, // 5,000 BDT
      currencyCode = "BDT",
      dateFormatted = "Oct 15",
    )
    assertEquals(1000000L, loan.outstandingMinorUnits)
    assertEquals(false, loan.isClosed)

    val fullyRepaid = loan.copy(repaidMinorUnits = 1500000L)
    assertEquals(0L, fullyRepaid.outstandingMinorUnits)
    assertTrue(fullyRepaid.isClosed)
  }

  @Test
  fun testLoanOverpaymentPreventionLogic() {
    val outstanding = 1000000L // 10,000 BDT
    val repaymentAttempt = 1200000L // 12,000 BDT
    val isOverpayment = repaymentAttempt > outstanding
    assertTrue("Overpayment must be detected and blocked", isOverpayment)
  }
}
