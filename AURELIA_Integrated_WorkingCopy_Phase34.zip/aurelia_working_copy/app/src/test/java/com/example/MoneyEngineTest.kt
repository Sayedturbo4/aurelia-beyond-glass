package com.example

import com.example.data.MoneyEngine
import com.example.data.LoanItem
import com.example.data.LoanType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Test

class MoneyEngineTest {
    @Test
    fun parsesCurrenciesUsingTheirMinorUnitScale() {
        assertEquals(123456L, MoneyEngine.parseMajorToMinor("1,234.56", "BDT"))
        assertEquals(123456L, MoneyEngine.parseMajorToMinor("1234.56", "USD"))
        assertEquals(123456L, MoneyEngine.parseMajorToMinor("123.456", "KWD"))
        assertEquals(123L, MoneyEngine.parseMajorToMinor("123", "JPY"))
    }

    @Test
    fun rejectsExcessPrecisionInsteadOfRoundingSilently() {
        assertThrows(IllegalArgumentException::class.java) {
            MoneyEngine.parseMajorToMinor("1.001", "BDT")
        }
        assertThrows(IllegalArgumentException::class.java) {
            MoneyEngine.parseMajorToMinor("1.1", "JPY")
        }
    }

    @Test
    fun rejectsInvalidAndOverflowAmounts() {
        assertThrows(IllegalArgumentException::class.java) {
            MoneyEngine.parseMajorToMinor("-10.00", "USD")
        }
        assertThrows(ArithmeticException::class.java) {
            MoneyEngine.parseMajorToMinor("92233720368547758.08", "USD")
        }
    }

    @Test
    fun formatsWithoutFloatingPointLoss() {
        assertEquals("$ 1,850.00", MoneyEngine.formatMinor(185000L, "USD"))
        assertEquals("৳ 75,000.00", MoneyEngine.formatMinor(7500000L, "BDT"))
        assertEquals("¥ 120,000", MoneyEngine.formatMinor(120000L, "JPY"))
        assertEquals("KD 850.250", MoneyEngine.formatMinor(850250L, "KWD"))
        assertEquals("-$ 0.01", MoneyEngine.formatMinor(-1L, "USD"))
    }

    @Test
    fun hidesAmountsAndProtectsOverflow() {
        assertEquals("••••••", MoneyEngine.formatMinor(100L, "USD", false))
        assertThrows(ArithmeticException::class.java) {
            MoneyEngine.addExact(Long.MAX_VALUE, 1L)
        }
        assertThrows(ArithmeticException::class.java) {
            MoneyEngine.subtractExact(Long.MIN_VALUE, 1L)
        }
    }

    @Test
    fun loanModelRejectsInvalidPrincipalAndOverpayment() {
        fun loan(principal: Long, repaid: Long) = LoanItem(
            id = "loan-1",
            personId = "person-1",
            personName = "Test Person",
            type = LoanType.LENT,
            principalMinorUnits = principal,
            repaidMinorUnits = repaid,
            currencyCode = "BDT",
            dateFormatted = "Nov 3, 2026",
        )

        assertEquals(500L, loan(1000L, 500L).outstandingMinorUnits)
        assertEquals(0L, loan(1000L, 1000L).outstandingMinorUnits)
        assertThrows(IllegalArgumentException::class.java) { loan(0L, 0L) }
        assertThrows(IllegalArgumentException::class.java) { loan(1000L, -1L) }
        assertThrows(IllegalArgumentException::class.java) { loan(1000L, 1001L) }
    }

    @Test
    fun sameCurrencyTransferDebitsFeeFromSourceAndCreditsDestination() {
        val balances = MoneyEngine.calculateTransferBalances(
            sourceBalanceMinorUnits = 10_000L,
            destinationBalanceMinorUnits = 2_000L,
            amountMinorUnits = 3_000L,
            feeMinorUnits = 100L,
        )
        assertEquals(6_900L, balances.sourceBalanceMinorUnits)
        assertEquals(5_000L, balances.destinationBalanceMinorUnits)
    }

    @Test
    fun transferRejectsInsufficientFundsNegativeFeeAndOverflow() {
        assertThrows(IllegalArgumentException::class.java) {
            MoneyEngine.calculateTransferBalances(3_000L, 0L, 3_000L, 1L)
        }
        assertThrows(IllegalArgumentException::class.java) {
            MoneyEngine.calculateTransferBalances(5_000L, 0L, 1_000L, -1L)
        }
        assertThrows(ArithmeticException::class.java) {
            MoneyEngine.calculateTransferBalances(Long.MAX_VALUE, 0L, Long.MAX_VALUE, 1L)
        }
        assertThrows(ArithmeticException::class.java) {
            MoneyEngine.calculateTransferBalances(10_000L, Long.MAX_VALUE, 1L, 0L)
        }
    }

    @Test
    fun repaymentMustNotExceedOutstanding() {
        MoneyEngine.validateRepayment(500L, 1000L)
        assertThrows(IllegalArgumentException::class.java) {
            MoneyEngine.validateRepayment(1001L, 1000L)
        }
    }
}
