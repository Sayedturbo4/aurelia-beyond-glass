package com.example.security

import android.content.Context
import androidx.biometric.BiometricManager

/** Reports device capability only; it never treats capability as successful authentication. */
object BiometricAvailability {
  fun canAuthenticate(context: Context): Boolean {
    val manager = BiometricManager.from(context)
    val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
      BiometricManager.Authenticators.DEVICE_CREDENTIAL
    return manager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
  }
}
