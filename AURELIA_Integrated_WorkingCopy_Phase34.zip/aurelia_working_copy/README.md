# AURELIA — Beyond Glass

AURELIA is an offline-first Android finance application working copy built with Kotlin and Jetpack Compose. This repository is a separate redesign/build workspace; it does **not** automatically update the original Google AI Studio project.

## Current validation status

- Source preflight and phase-specific static checks are included in the repository.
- GitHub Actions is configured to compile Kotlin, run local unit tests, assemble a **debug** APK, and upload the APK with SHA-256 and build metadata.
- A successful source preflight is not proof of Android compilation or device compatibility. Check the latest GitHub Actions run before installing.
- Emulator/physical-device QA and production release signing remain outstanding until explicitly completed.

## Build from GitHub on Android

1. Open `https://github.com/Sayedturbo4/aurelia-beyond-glass` in a browser and sign in.
2. Open **Actions** and select **AURELIA Android Debug Build**.
3. Open the latest successful run on the `main` branch. Confirm all steps, especially Kotlin compilation, unit tests, and APK assembly, are green.
4. Under **Artifacts**, download `aurelia-debug-apk-<run number>`.
5. Extract the downloaded artifact ZIP, then install the APK on the Android device. Android may ask permission to install unknown apps for the browser/file manager used.
6. Keep the matching `SHA256SUMS.txt` and `BUILD_INFO.txt` with the APK. The checksum can be used to verify that the APK has not changed after download.

If the workflow fails, do not install an APK from that failed run. Open the failed step and share its complete error log for diagnosis.

## Trigger a fresh build

A push to `main`/`master`, a pull request to those branches, or **Actions → AURELIA Android Debug Build → Run workflow** starts the debug pipeline. Manual dispatch is useful when the source has not changed.

## Important security and release notes

- The generated artifact is a **debug APK**, not a Play Store release.
- The repository's Android debug signing key is for development/testing only. Never use it as a production upload/release key.
- Do not commit `.env`, API keys, `google-services.json`, personal signing keys, or passwords. `.env.example` contains placeholders only.
- Before a Play Store release, configure a private upload key through protected GitHub secrets, define release signing, review app identity/versioning and privacy disclosures, and run release-build plus device QA.
- Financial records are intended to remain on-device in the current offline-first scope. Do not assume cloud sync, online messaging, or production-grade encryption exists unless separately implemented and audited.

## Build command (CI environment)

```bash
gradle --no-daemon clean :app:compileDebugKotlin :app:testDebugUnitTest :app:assembleDebug
```

Gradle wrapper scripts/JAR are not present in this snapshot; the GitHub workflow installs Gradle 9.3.1 directly. The complete Android build has not been certified by this documentation alone.
