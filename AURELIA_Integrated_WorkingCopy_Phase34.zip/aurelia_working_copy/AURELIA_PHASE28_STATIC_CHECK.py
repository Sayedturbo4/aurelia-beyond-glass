from pathlib import Path
root = Path(__file__).parent
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

dao = (root/'app/src/main/java/com/example/data/local/FinanceDao.kt').read_text()
manager = (root/'app/src/main/java/com/example/data/backup/FinanceBackupManager.kt').read_text()
main = (root/'app/src/main/java/com/example/MainActivity.kt').read_text()
more = (root/'app/src/main/java/com/example/ui/screens/MoreScreen.kt').read_text()
entities = ['people','wallets','loans','transactions','budgets','savings_goals','savings_contributions','app_metadata','categories']
for table in entities:
    check(f'{table} export query', f'SELECT * FROM {table}' in dao)
    check(f'{table} import ignore', 'OnConflictStrategy.IGNORE' in dao[dao.find(f'interface {table.title().replace("_", "")}Dao'):] if f'interface {table.title().replace("_", "")}Dao' in dao else 'importIgnore' in dao)
check('versioned schema validation', 'CURRENT_SCHEMA' in manager and 'Unsupported backup version' in manager)
check('duplicate-safe merge', 'OnConflictStrategy.IGNORE' in dao and 'restoreMerge' in manager)
check('atomic restore', 'database.withTransaction' in manager)
check('wallet snapshot conflict protection', 'different currency or balance' in manager)
check('preview before confirmation', 'backupManager.preview(json)' in main and 'Review Backup' in main)
check('SAF export and import', 'CreateDocument' in main and 'OpenDocument' in main)
check('backup UI actions', 'onExportBackup' in more and 'onImportBackup' in more)
check('sensitive backup warning', 'sensitive financial and contact information' in more)
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' ' + name)
print(f'RESULT {sum(ok for _,ok in checks)}/{len(checks)}')
if not all(ok for _,ok in checks): raise SystemExit(1)
