# AURELIA Phase 28 — JSON Backup & Safe Restore

## Implemented
- Versioned offline JSON backup payload covering people, wallets, loans, transactions (including voided rows), budgets, savings goals, savings contribution history, categories, and app metadata.
- Export uses Android Storage Access Framework `CreateDocument`; no broad storage permission is required.
- Import uses `OpenDocument`, validates format/schema/size/IDs/amounts/currencies/references, and shows a record-count preview before confirmation.
- Restore is merge-only and uses Room `withTransaction`; inserts use `OnConflictStrategy.IGNORE`, so existing IDs are not overwritten.
- Restore aborts when an existing wallet or savings goal has conflicting currency/balance/target snapshots, protecting cached financial totals from unsafe merges.
- Sensitive-data warning shown in the UI. JSON backups are not encrypted; users must store them privately.

## Safety boundaries
- No delete/replace restore mode is provided.
- Invalid or unsupported schema versions are rejected.
- Backup size is capped at 25 MiB at validation.
- This is local file export/import; no cloud sync or network service is used.

## Verification
- Targeted source checks and ZIP integrity check passed.
- Full Android/Compose/KSP compilation and runtime Room restore tests have NOT been run in this environment because Gradle and the Gradle wrapper are absent. Treat the feature as implementation-complete but build/runtime-unverified until GitHub Actions and device tests pass.
