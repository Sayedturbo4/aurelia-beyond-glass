package com.example.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchPickerFilterTest {
    private val options = listOf(
        SearchPickerItem("bkash", "bKash", "MFS · BDT"),
        SearchPickerItem("cash", "Cash Wallet", "Cash · BDT"),
        SearchPickerItem("usd", "USD Savings", "Bank · USD"),
    )

    @Test
    fun blankQueryReturnsAllOptionsInOriginalOrder() {
        assertEquals(options, filterSearchPickerItems(options, "  "))
    }

    @Test
    fun searchMatchesTitleWithoutCaseSensitivity() {
        assertEquals(listOf(options[0]), filterSearchPickerItems(options, "BKASH"))
    }

    @Test
    fun searchMatchesSubtitleAndCurrency() {
        assertEquals(listOf(options[2]), filterSearchPickerItems(options, "usd"))
    }

    @Test
    fun unmatchedQueryReturnsEmptyList() {
        assertTrue(filterSearchPickerItems(options, "nagad").isEmpty())
    }
}
