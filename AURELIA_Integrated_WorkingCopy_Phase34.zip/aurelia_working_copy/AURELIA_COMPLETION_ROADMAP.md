# AURELIA — Full Completion Roadmap

This roadmap is for the isolated redesign working copy. The Google AI Studio Phase 4.6 original remains the authoritative continuation checkpoint until the user deliberately applies a reviewed update there.

## Completed working-copy phases
- Phase 1: baseline audit and master redesign specification.
- Phase 2: design token and reusable glass primitive foundation.
- Phase 3: Home dashboard redesign.
- Phase 4: Quick Add keyboard, same-currency transfer and repayment validation refinements.
- Phase 5: searchable pickers for wallet, destination wallet, person, active loan and category.

## Remaining implementation phases
- Phase 6: contextual Quick Add flows (separate Income, Expense, Transfer and People/Loan journeys), date/note controls, review/confirmation, safe double-submit behavior.
- Phase 7: Wallets redesign (wallet list, create/edit, details, archive, currency-safe history).
- Phase 8: People & Loans redesign (person details, lent/borrowed, repayment history, due dates, partial/full repayment, audit-safe edit/delete).
- Phase 9: Activity and transaction detail/edit/delete/undo/search/filter/date range.
- Phase 10: Budgets and Savings Goals end-to-end flows and progress calculations.
- Phase 11: Reports and analytics with strictly separated currency buckets and date ranges.
- Phase 12: Categories, audit history, backup/restore, app lock/security settings.
- Phase 13: onboarding, first-run wallet/currency setup, empty/loading/error states and localization.
- Phase 14: repository/domain/data-layer audit, atomicity, migrations, currency scale, overflow and reconciliation tests.
- Phase 15: Compose UI tests, accessibility, touch target, keyboard, rotation/font scaling and performance review.
- Phase 16: cloud build verification, APK installation, physical-device QA, bug fixing and release candidate.
- Phase 17: AI Studio continuation package from Phase 4.6, with exact file changes, prompts and integration order; no automatic sync is assumed.

## Definition of done
AURELIA is not considered complete until:
1. All required screens and user journeys exist and work.
2. No financial operation relies on floating-point money arithmetic.
3. Wallet and transaction currency rules are enforced in UI and repository/domain layers.
4. Transfer and loan operations are atomic and reconcile correctly.
5. Data survives app restart and backup/restore is validated.
6. Automated unit/repository/UI tests pass.
7. A clean cloud Android build succeeds and the APK installs on a real device.
8. The user verifies the actual UI and core workflows on their phone.
9. AI Studio continuation instructions preserve the original Phase 4.6 work and clearly identify all manual import/apply steps.

## Important constraints
- Android Kotlin + Jetpack Compose; Android-first, iOS later.
- Offline-first; no cloud backend, authentication, real-time messaging or billing in this offline milestone.
- Keep AURELIA separate from Project 2 and any other finance PWA.
- Keep all ChatGPT changes in a separate working copy; do not claim changes synced to AI Studio or GitHub.
- Never claim full build/device verification unless the relevant build and device tests were actually run.

## Phase 7 update — Wallet lifecycle safety
- Implemented safe zero-balance wallet archival, confirmation UI, ViewModel boundary, and historical-data preservation.
- Still pending: wallet edit, detail ledger/aggregates, archived-wallet restore, compact searchable currency selection, full Android build and device QA.


## Phase 30 Update
- Onboarding and persistent global preferences implemented in the integrated working copy.
- Android build and device verification remain pending.


## Phase 33 — Automated Testing & Android Build Verification
- CI pipeline expanded to preflight, compile, unit test, assemble APK, and publish checksum/build metadata.
- 16/16 local structural checks passed. Android CI execution and physical-device verification remain pending.
