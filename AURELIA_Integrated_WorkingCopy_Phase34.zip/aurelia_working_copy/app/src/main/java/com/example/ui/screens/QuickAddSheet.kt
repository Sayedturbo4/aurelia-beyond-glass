package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataProvider
import com.example.data.MoneyEngine
import com.example.data.LoanItem
import com.example.data.LoanType
import com.example.data.PeopleSubtype
import com.example.data.PersonItem
import com.example.data.TransactionType
import com.example.data.WalletItem
import com.example.data.local.TransactionEntity
import com.example.data.local.PersonEntity
import com.example.data.local.LoanEntity
import com.example.ui.viewmodel.FinanceOverviewViewModel
import com.example.ui.components.AureliaBadge
import com.example.ui.components.SearchablePickerField
import com.example.ui.components.SearchPickerItem
import com.example.ui.components.AureliaChip
import com.example.ui.components.AureliaGlassButton
import com.example.ui.components.AureliaGlassCard
import com.example.ui.components.GlassStyle
import com.example.ui.theme.AureliaThemeTokens
import java.util.UUID
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAddSheet(
  sheetState: SheetState,
  initialType: TransactionType = TransactionType.EXPENSE,
  onDismiss: () -> Unit,
  onSuccess: (String) -> Unit,
  viewModel: FinanceOverviewViewModel,
) {
  val colors = AureliaThemeTokens.colors
  var selectedType by remember { mutableStateOf(initialType) }
  var peopleSubtype by remember { mutableStateOf(PeopleSubtype.LENT) }
  var amountInput by remember { mutableStateOf("") }
  var selectedWalletIndex by remember { mutableStateOf(0) }
  var destWalletIndex by remember { mutableStateOf(1) }
  var selectedCategory by remember { mutableStateOf("Food & Dining") }
  var noteInput by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isSubmitting by remember { mutableStateOf(false) }

  // All selectable finance records are projected from Room. Demo fixtures are used only
  // during the first seed emission to avoid an empty first frame; writes never target them.
  val walletRows by viewModel.wallets.collectAsState()
  val peopleRows by viewModel.people.collectAsState()
  val loanRows by viewModel.loans.collectAsState()
  val databaseWallets = remember(walletRows) { walletRows.map { row ->
    WalletItem(row.id, row.name, row.category, row.currencyCode, row.balanceMinorUnits, row.colorHex, row.iconName)
  } }
  val databasePeople = remember(peopleRows) { peopleRows.map { row ->
    PersonItem(row.id, row.name, row.phone, row.email)
  } }
  val databaseLoans = remember(loanRows, databasePeople) {
    val names = databasePeople.associate { it.id to it.name }
    loanRows.mapNotNull { row ->
      val type = when (row.type) { "LENT" -> LoanType.LENT; "BORROWED" -> LoanType.BORROWED; else -> null }
      type?.let { loanType -> LoanItem(row.id, row.personId, names[row.personId] ?: "Unknown Person", loanType,
        row.principalMinorUnits, row.repaidMinorUnits, row.currencyCode,
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(row.openedAtMillis)), row.dueAtMillis?.let { due ->
          SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(due))
        }, row.note) }
    }
  }
  val availableWallets = if (databaseWallets.isNotEmpty()) databaseWallets else DemoDataProvider.demoWallets.toList()
  val availablePeople = databasePeople
  val availableLoans = databaseLoans

  // People & Loans state
  var selectedPersonIndex by remember { mutableStateOf(0) }
  var isAddingNewPerson by remember { mutableStateOf(false) }
  var newPersonNameInput by remember { mutableStateOf("") }
  var newPersonPhoneInput by remember { mutableStateOf("") }
  var selectedLoanIndex by remember { mutableStateOf(0) }

  val categories = listOf(
    "Food & Dining",
    "Work & Client",
    "Housing & Bills",
    "Transport",
    "Tech & Tools",
    "Health & Fitness",
    "Entertainment",
    "Shopping",
  )

  val sourceWallet = availableWallets.getOrNull(selectedWalletIndex) ?: availableWallets.firstOrNull() ?: DemoDataProvider.demoWallets.first()
  val destWallet = availableWallets.getOrNull(destWalletIndex) ?: availableWallets.getOrNull(1)
  val selectedPerson = availablePeople.getOrNull(selectedPersonIndex)

  // Loans relevant for the selected person
  val personLoans = availableLoans.filter {
    selectedPerson != null && it.personId == selectedPerson.id && !it.isClosed
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(top = 12.dp)
          .size(width = 44.dp, height = 4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(colors.borderFrosted.copy(alpha = 0.5f)),
      )
    },
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .imePadding()
        .navigationBarsPadding()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 10.dp),
    ) {
      // Top header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Quick Add Transaction",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = colors.textPrimary,
        )
        IconButton(onClick = onDismiss) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = colors.textSecondary,
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Responsive 2x2 Transaction Type Selector
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          TypeSegmentCard(
            title = "Expense",
            icon = Icons.Default.ArrowUpward,
            isSelected = selectedType == TransactionType.EXPENSE,
            accentColor = colors.financialExpense,
            onClick = {
              selectedType = TransactionType.EXPENSE
              errorMessage = null
            },
            modifier = Modifier.weight(1f),
          )
          TypeSegmentCard(
            title = "Income",
            icon = Icons.Default.ArrowDownward,
            isSelected = selectedType == TransactionType.INCOME,
            accentColor = colors.financialIncome,
            onClick = {
              selectedType = TransactionType.INCOME
              errorMessage = null
            },
            modifier = Modifier.weight(1f),
          )
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          TypeSegmentCard(
            title = "Transfer",
            icon = Icons.Default.SyncAlt,
            isSelected = selectedType == TransactionType.TRANSFER,
            accentColor = colors.auroraLavender,
            onClick = {
              selectedType = TransactionType.TRANSFER
              errorMessage = null
            },
            modifier = Modifier.weight(1f),
          )
          TypeSegmentCard(
            title = "People & Loans",
            icon = Icons.Default.People,
            isSelected = selectedType == TransactionType.PEOPLE,
            accentColor = colors.auroraBlue,
            onClick = {
              selectedType = TransactionType.PEOPLE
              errorMessage = null
            },
            modifier = Modifier.weight(1f),
          )
        }
      }

      // If People tab selected, show clear actions: Money Lent | Money Borrowed | Loan Repayment
      if (selectedType == TransactionType.PEOPLE) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Action Type",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textSecondary,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          PeopleSubtypeChip(
            title = "Money Lent",
            isSelected = peopleSubtype == PeopleSubtype.LENT,
            accentColor = colors.auroraBlue,
            onClick = {
              peopleSubtype = PeopleSubtype.LENT
              errorMessage = null
            },
            modifier = Modifier.weight(1f),
          )
          PeopleSubtypeChip(
            title = "Money Borrowed",
            isSelected = peopleSubtype == PeopleSubtype.BORROWED,
            accentColor = colors.auroraRose,
            onClick = {
              peopleSubtype = PeopleSubtype.BORROWED
              errorMessage = null
            },
            modifier = Modifier.weight(1f),
          )
          PeopleSubtypeChip(
            title = "Loan Repayment",
            isSelected = peopleSubtype == PeopleSubtype.REPAYMENT,
            accentColor = colors.auroraMint,
            onClick = {
              peopleSubtype = PeopleSubtype.REPAYMENT
              errorMessage = null
            },
            modifier = Modifier.weight(1f),
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Amount Input Field
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.AURORA,
        shape = RoundedCornerShape(22.dp),
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Amount (${sourceWallet.currencyCode})",
            fontSize = 12.sp,
            color = colors.textSecondary,
            fontWeight = FontWeight.Medium,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            val curr = DemoDataProvider.getCurrency(sourceWallet?.currencyCode ?: "BDT")
            Text(
              text = curr.symbol,
              fontSize = 30.sp,
              fontWeight = FontWeight.Bold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
              value = amountInput,
              onValueChange = {
                amountInput = it.filter { char -> char.isDigit() || char == '.' }
                errorMessage = null
              },
              placeholder = { Text("0.00", fontSize = 28.sp, color = colors.textSecondary.copy(alpha = 0.4f)) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
              ),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent,
              ),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("input_transaction_amount"),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // PEOPLE SPECIFIC FIELDS
      if (selectedType == TransactionType.PEOPLE) {
        Text(
          text = "Select Person",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textPrimary,
        )
        Spacer(modifier = Modifier.height(6.dp))

        if (availablePeople.isNotEmpty()) {
          SearchablePickerField(
            label = "Person",
            placeholder = "Choose a person",
            selectedItem = if (isAddingNewPerson) null else availablePeople.getOrNull(selectedPersonIndex)?.let {
              SearchPickerItem(it.id, it.name, it.phone.ifBlank { it.email })
            },
            items = availablePeople.map { SearchPickerItem(it.id, it.name, it.phone.ifBlank { it.email }) },
            onSelect = { item ->
              val nextPersonIndex = availablePeople.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
              if (nextPersonIndex != selectedPersonIndex) selectedLoanIndex = 0
              selectedPersonIndex = nextPersonIndex
              isAddingNewPerson = false
              errorMessage = null
            },
            emptyMessage = "No people found. Add a new person below.",
          )
        }
        AureliaGlassButton(
          text = if (isAddingNewPerson) "Cancel new person" else "Add new person",
          onClick = {
            isAddingNewPerson = !isAddingNewPerson
            errorMessage = null
          },
          modifier = Modifier.fillMaxWidth(),
        )

        // Inline new person entry
        if (isAddingNewPerson) {
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedTextField(
              value = newPersonNameInput,
              onValueChange = { newPersonNameInput = it },
              placeholder = { Text("Person Full Name") },
              singleLine = true,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(14.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.auroraLavender,
                unfocusedBorderColor = colors.borderFrosted,
              ),
            )
            OutlinedTextField(
              value = newPersonPhoneInput,
              onValueChange = { newPersonPhoneInput = it },
              placeholder = { Text("Phone (Optional)") },
              singleLine = true,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(14.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.auroraLavender,
                unfocusedBorderColor = colors.borderFrosted,
              ),
            )
          }
        }

        // Loan Repayment specific loan picker & outstanding balance preview
        if (peopleSubtype == PeopleSubtype.REPAYMENT && !isAddingNewPerson) {
          Spacer(modifier = Modifier.height(10.dp))
          if (personLoans.isEmpty()) {
            AureliaBadge(
              text = "No open loans with ${selectedPerson?.name ?: "this person"}",
              color = colors.textSecondary,
            )
          } else {
            Text(
              text = "Active Loan to Repay",
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(6.dp))
            SearchablePickerField(
              label = "Active loan",
              placeholder = "Choose a loan to repay",
              selectedItem = personLoans.getOrNull(selectedLoanIndex)?.let { loan ->
                SearchPickerItem(loan.id, if (loan.type == LoanType.LENT) "Money lent" else "Money borrowed", "Outstanding ${DemoDataProvider.formatMoney(loan.outstandingMinorUnits, loan.currencyCode)}")
              },
              items = personLoans.map { loan ->
                SearchPickerItem(loan.id, if (loan.type == LoanType.LENT) "Money lent" else "Money borrowed", "Outstanding ${DemoDataProvider.formatMoney(loan.outstandingMinorUnits, loan.currencyCode)}")
              },
              onSelect = { item -> selectedLoanIndex = personLoans.indexOfFirst { it.id == item.id }.coerceAtLeast(0) },
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Source Wallet Selection
      val walletLabel = when (selectedType) {
        TransactionType.TRANSFER -> "From Source Wallet"
        TransactionType.PEOPLE -> when (peopleSubtype) {
          PeopleSubtype.LENT -> "Debit From Wallet (যেখান থেকে টাকা দিলেন)"
          PeopleSubtype.BORROWED -> "Credit To Wallet (টাকা গ্রহণ করলেন)"
          PeopleSubtype.REPAYMENT -> "Wallet (লেনদেনকৃত ওয়ালেট)"
        }
        else -> "Wallet"
      }
      Text(
        text = walletLabel,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = colors.textPrimary,
      )
      Spacer(modifier = Modifier.height(6.dp))
      SearchablePickerField(
        label = walletLabel,
        placeholder = "Choose a wallet",
        selectedItem = sourceWallet.let { SearchPickerItem(it.id, it.name, "${it.currencyCode} · ${DemoDataProvider.formatMoney(it.balanceMinorUnits, it.currencyCode)}") },
        items = availableWallets.map { SearchPickerItem(it.id, it.name, "${it.currencyCode} · ${DemoDataProvider.formatMoney(it.balanceMinorUnits, it.currencyCode)}") },
        onSelect = { item ->
          selectedWalletIndex = availableWallets.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
          if (destWalletIndex == selectedWalletIndex) destWalletIndex = availableWallets.indices.firstOrNull { it != selectedWalletIndex && availableWallets[it].currencyCode == availableWallets[selectedWalletIndex].currencyCode } ?: selectedWalletIndex
        },
      )

      // Transfer Destination Wallet
      if (selectedType == TransactionType.TRANSFER) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "To Destination Wallet",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textPrimary,
        )
        Spacer(modifier = Modifier.height(6.dp))
        val compatibleDestinationIndices = availableWallets.indices.filter { index ->
          index != selectedWalletIndex && availableWallets[index].currencyCode == sourceWallet.currencyCode
        }
        if (compatibleDestinationIndices.isEmpty()) {
          AureliaBadge(
            text = "No other ${sourceWallet.currencyCode} wallet available. Cross-currency transfers are not supported yet.",
            color = colors.textSecondary,
          )
        } else {
          SearchablePickerField(
            label = "Destination wallet",
            placeholder = "Choose destination",
            selectedItem = availableWallets.getOrNull(destWalletIndex)?.takeIf { destWalletIndex in compatibleDestinationIndices }?.let {
              SearchPickerItem(it.id, it.name, "${it.currencyCode} · ${DemoDataProvider.formatMoney(it.balanceMinorUnits, it.currencyCode)}")
            },
            items = compatibleDestinationIndices.map { index -> availableWallets[index] }.map {
              SearchPickerItem(it.id, it.name, "${it.currencyCode} · ${DemoDataProvider.formatMoney(it.balanceMinorUnits, it.currencyCode)}")
            },
            onSelect = { item -> destWalletIndex = availableWallets.indexOfFirst { it.id == item.id }.coerceAtLeast(0) },
          )
        }
      }

      // Category Selection (for standard Income and Expense)
      if (selectedType == TransactionType.INCOME || selectedType == TransactionType.EXPENSE) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Category",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textPrimary,
        )
        Spacer(modifier = Modifier.height(6.dp))
        SearchablePickerField(
          label = "Category",
          placeholder = "Choose a category",
          selectedItem = SearchPickerItem(selectedCategory, selectedCategory),
          items = categories.map { SearchPickerItem(it, it) },
          onSelect = { selectedCategory = it.id },
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Note Field
      OutlinedTextField(
        value = noteInput,
        onValueChange = { noteInput = it.take(500) },
        placeholder = { Text("Add a note (optional)", color = colors.textSecondary.copy(alpha = 0.6f)) },
        minLines = 2,
        maxLines = 4,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = colors.auroraLavender,
          unfocusedBorderColor = colors.borderFrosted,
        ),
      )

      if (errorMessage != null) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = errorMessage!!,
          color = colors.financialExpense,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
        )
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Confirm Button
      AureliaGlassButton(
        text = when (selectedType) {
          TransactionType.EXPENSE -> "Confirm Expense"
          TransactionType.INCOME -> "Confirm Income"
          TransactionType.TRANSFER -> "Confirm Transfer"
          TransactionType.PEOPLE -> when (peopleSubtype) {
            PeopleSubtype.LENT -> "Record Money Lent"
            PeopleSubtype.BORROWED -> "Record Borrowed Money"
            PeopleSubtype.REPAYMENT -> "Record Loan Repayment"
          }
        },
        onClick = {
          if (isSubmitting) return@AureliaGlassButton
          if (walletRows.isEmpty()) {
            errorMessage = "Local wallets are still loading. Please try again."
            return@AureliaGlassButton
          }
          val activeWallet = sourceWallet
          val minorUnits = try {
            MoneyEngine.parseMajorToMinor(amountInput, activeWallet.currencyCode).also {
              MoneyEngine.validatePositive(it)
            }
          } catch (error: IllegalArgumentException) {
            errorMessage = error.message ?: "Enter a valid amount"
            return@AureliaGlassButton
          } catch (error: ArithmeticException) {
            errorMessage = "Amount is outside the supported range"
            return@AureliaGlassButton
          }

          // Persist every Quick Add operation through Room. The legacy demo mutation path
          // below remains unreachable as a defensive fallback during this migration phase.
          val now = System.currentTimeMillis()
          val txId = "tx_${UUID.randomUUID()}"
          val titleText = when (selectedType) {
            TransactionType.EXPENSE -> selectedCategory
            TransactionType.INCOME -> if (noteInput.isNotBlank()) noteInput.trim() else "Income Payout"
            TransactionType.TRANSFER -> "Transfer to ${destWallet?.name ?: "Wallet"}"
            TransactionType.PEOPLE -> "People & Loans"
          }
          val dbTransaction = TransactionEntity(
            id = txId,
            title = titleText,
            categoryId = if (selectedType == TransactionType.TRANSFER) "transfer" else selectedCategory,
            type = when (selectedType) { TransactionType.INCOME -> "INCOME"; TransactionType.EXPENSE -> "EXPENSE"; TransactionType.TRANSFER -> "TRANSFER"; else -> "PEOPLE" },
            amountMinorUnits = minorUnits,
            currencyCode = sourceWallet.currencyCode,
            walletId = activeWallet.id,
            destinationWalletId = if (selectedType == TransactionType.TRANSFER) destWallet?.id else null,
            occurredAtMillis = now,
            note = noteInput.trim(),
            transferExchangeRateSnapshot = if (selectedType == TransactionType.TRANSFER) "1" else null,
            createdAtMillis = now,
            updatedAtMillis = now,
          )
          isSubmitting = true
          when (selectedType) {
            TransactionType.INCOME, TransactionType.EXPENSE -> viewModel.postCashTransaction(dbTransaction, now) { result ->
              isSubmitting = false
              result.onSuccess { onSuccess("Transaction recorded successfully!"); onDismiss() }
                .onFailure { errorMessage = it.message ?: "Could not save transaction" }
            }
            TransactionType.TRANSFER -> {
              if (destWallet == null) {
                isSubmitting = false
                errorMessage = "Please select a destination wallet"
                return@AureliaGlassButton
              }
              if (destWallet.id == activeWallet.id) {
                isSubmitting = false
                errorMessage = "Source and destination wallets must be different"
                return@AureliaGlassButton
              }
              if (destWallet.currencyCode != activeWallet.currencyCode) {
                isSubmitting = false
                errorMessage = "Transfers currently require wallets with the same currency"
                return@AureliaGlassButton
              }
              viewModel.postWalletTransfer(dbTransaction, now) { result ->
                isSubmitting = false
                result.onSuccess { onSuccess("Transfer completed successfully!"); onDismiss() }
                  .onFailure { errorMessage = it.message ?: "Could not complete transfer" }
              }
            }
            TransactionType.PEOPLE -> {
              val person = if (isAddingNewPerson) null else selectedPerson
              if (peopleSubtype == PeopleSubtype.REPAYMENT) {
                val loan = personLoans.getOrNull(selectedLoanIndex)
                if (loan == null) {
                  isSubmitting = false
                  errorMessage = "No open loan selected"
                  return@AureliaGlassButton
                }
                if (loan.currencyCode != activeWallet.currencyCode) {
                  isSubmitting = false
                  errorMessage = "Choose a ${loan.currencyCode} wallet for this loan repayment"
                  return@AureliaGlassButton
                }
                if (minorUnits > loan.outstandingMinorUnits) {
                  isSubmitting = false
                  errorMessage = "Repayment exceeds the outstanding ${loan.currencyCode} balance"
                  return@AureliaGlassButton
                }
                viewModel.recordLoanRepayment(loan.id, minorUnits, activeWallet.id, now, txId, now) { result ->
                  isSubmitting = false
                  result.onSuccess { onSuccess("Loan repayment recorded!"); onDismiss() }
                    .onFailure { errorMessage = it.message ?: "Could not record repayment" }
                }
              } else {
                val personId = person?.id ?: "p_${UUID.randomUUID()}"
                val loanType = if (peopleSubtype == PeopleSubtype.LENT) "LENT" else "BORROWED"
                val loanId = "loan_${UUID.randomUUID()}"
                val newPersonEntity = if (person == null) PersonEntity(
                  id = personId, name = newPersonNameInput.trim(), phone = newPersonPhoneInput.trim(),
                  createdAtMillis = now, updatedAtMillis = now,
                ) else null
                if (newPersonEntity != null && newPersonEntity.name.isBlank()) {
                  isSubmitting = false
                  errorMessage = "Please enter the person's name"
                  return@AureliaGlassButton
                }
                val loanEntity = LoanEntity(
                  id = loanId, personId = personId, type = loanType,
                  principalMinorUnits = minorUnits, repaidMinorUnits = 0L,
                  currencyCode = sourceWallet.currencyCode, openedAtMillis = now,
                  note = noteInput.trim(), createdAtMillis = now, updatedAtMillis = now,
                )
                val onLoanResult: (Result<Unit>) -> Unit = { result ->
                  isSubmitting = false
                  result.onSuccess { onSuccess("Loan recorded successfully!"); onDismiss() }
                    .onFailure { errorMessage = it.message ?: "Could not create loan" }
                }
                if (newPersonEntity != null) {
                  viewModel.createPersonAndLoan(newPersonEntity, loanEntity, activeWallet.id, onLoanResult)
                } else {
                  viewModel.createLoan(loanEntity, activeWallet.id, onLoanResult)
                }
              }
            }
          }
          return@AureliaGlassButton
        },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("btn_confirm_transaction"),
      )

      Spacer(modifier = Modifier.height(8.dp))
    }
  }
}

@Composable
private fun TypeSegmentCard(
  title: String,
  icon: ImageVector,
  isSelected: Boolean,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  val bg = if (isSelected) {
    accentColor.copy(alpha = if (colors.isDark) 0.28f else 0.18f)
  } else {
    colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.50f else 0.65f)
  }
  val borderColor = if (isSelected) accentColor else colors.borderFrosted.copy(alpha = 0.40f)
  val textColor = if (isSelected) colors.textPrimary else colors.textSecondary

  Surface(
    modifier = modifier
      .defaultMinSize(minHeight = 44.dp)
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(14.dp),
    color = bg,
    border = BorderStroke(1.2.dp, borderColor),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (isSelected) accentColor else textColor,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = title,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        fontSize = 13.sp,
        color = textColor,
      )
    }
  }
}

@Composable
private fun PeopleSubtypeChip(
  title: String,
  isSelected: Boolean,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  val bg = if (isSelected) {
    accentColor.copy(alpha = if (colors.isDark) 0.30f else 0.22f)
  } else {
    colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.45f else 0.60f)
  }
  val borderColor = if (isSelected) accentColor else colors.borderFrosted.copy(alpha = 0.35f)
  val textColor = if (isSelected) colors.textPrimary else colors.textSecondary

  Surface(
    modifier = modifier
      .defaultMinSize(minHeight = 40.dp)
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(12.dp),
    color = bg,
    border = BorderStroke(1.dp, borderColor),
  ) {
    Box(
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = title,
        fontSize = 12.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
        color = textColor,
      )
    }
  }
}
