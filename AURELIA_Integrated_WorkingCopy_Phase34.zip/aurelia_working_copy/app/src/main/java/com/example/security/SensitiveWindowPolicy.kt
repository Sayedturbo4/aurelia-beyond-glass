package com.example.security

import android.app.Activity
import android.view.WindowManager

/** Applies Android's secure-window flag to screens containing private financial information. */
object SensitiveWindowPolicy {
  fun setScreenshotProtection(activity: Activity, enabled: Boolean) {
    if (enabled) activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
    else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
  }
}
