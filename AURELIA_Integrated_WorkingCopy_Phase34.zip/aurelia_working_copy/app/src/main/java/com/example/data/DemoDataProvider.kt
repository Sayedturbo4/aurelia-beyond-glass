package com.example.data

import androidx.compose.runtime.mutableStateListOf
import java.text.NumberFormat
import java.util.Locale

enum class TransactionType {
  INCOME,
  EXPENSE,
  TRANSFER,
  PEOPLE, // Money Lent, Borrowed or Repayment
}

enum class LoanType {
  LENT, // Money Lent to someone (I will receive it back)
  BORROWED, // Money Borrowed from someone (I must repay it)
}

enum class PeopleSubtype {
  LENT,
  BORROWED,
  REPAYMENT,
}

data class PersonItem(
  val id: String,
  val name: String,
  val phone: String = "",
  val email: String = "",
)

data class LoanItem(
  val id: String,
  val personId: String,
  val personName: String,
  val type: LoanType,
  val principalMinorUnits: Long,
  val repaidMinorUnits: Long,
  val currencyCode: String,
  val dateFormatted: String,
  val dueDateFormatted: String? = null,
  val note: String = "",
) {
  init {
    require(id.isNotBlank()) { "Loan id is required" }
    require(personId.isNotBlank()) { "Loan person id is required" }
    require(personName.isNotBlank()) { "Loan person name is required" }
    require(currencyCode.isNotBlank()) { "Loan currency is required" }
    require(principalMinorUnits > 0L) { "Loan principal must be greater than zero" }
    require(repaidMinorUnits >= 0L) { "Repaid amount cannot be negative" }
    require(repaidMinorUnits <= principalMinorUnits) { "Repaid amount cannot exceed loan principal" }
  }

  // Invalid loan states are rejected at creation; never silently hide an overpayment.
  val outstandingMinorUnits: Long
    get() = MoneyEngine.subtractExact(principalMinorUnits, repaidMinorUnits)

  val isClosed: Boolean
    get() = outstandingMinorUnits == 0L
}

data class CurrencyInfo(
  val code: String,
  val symbol: String,
  val name: String,
  val flagEmoji: String,
  val scale: Int, // e.g. BDT: 2, USD: 2, EUR: 2, JPY: 0, KWD: 3
)

data class WalletItem(
  val id: String,
  val name: String,
  val category: String, // "MFS", "Bank", "Cash", "Card", "Vault"
  val currencyCode: String,
  val balanceMinorUnits: Long,
  val colorHex: Long,
  val iconName: String,
)

data class TransactionItem(
  val id: String,
  val title: String,
  val category: String,
  val type: TransactionType,
  val amountMinorUnits: Long,
  val currencyCode: String,
  val dateFormatted: String,
  val walletName: String,
  val destWalletName: String? = null,
  val personName: String? = null,
  val note: String = "",
)

data class BudgetItem(
  val id: String,
  val category: String,
  val spentMinorUnits: Long,
  val limitMinorUnits: Long,
  val currencyCode: String,
  val iconName: String,
)

data class SavingsGoalItem(
  val id: String,
  val name: String,
  val savedMinorUnits: Long,
  val targetMinorUnits: Long,
  val currencyCode: String,
  val iconName: String,
)

object DemoDataProvider {
  // All 13 approved currencies
  val supportedCurrencies = listOf(
    CurrencyInfo(code = "BDT", symbol = "৳", name = "Bangladeshi Taka", flagEmoji = "🇧🇩", scale = 2),
    CurrencyInfo(code = "USD", symbol = "$", name = "US Dollar", flagEmoji = "🇺🇸", scale = 2),
    CurrencyInfo(code = "EUR", symbol = "€", name = "Euro", flagEmoji = "🇪🇺", scale = 2),
    CurrencyInfo(code = "GBP", symbol = "£", name = "British Pound", flagEmoji = "🇬🇧", scale = 2),
    CurrencyInfo(code = "INR", symbol = "₹", name = "Indian Rupee", flagEmoji = "🇮🇳", scale = 2),
    CurrencyInfo(code = "SAR", symbol = "﷼", name = "Saudi Riyal", flagEmoji = "🇸🇦", scale = 2),
    CurrencyInfo(code = "AED", symbol = "د.إ", name = "UAE Dirham", flagEmoji = "🇦🇪", scale = 2),
    CurrencyInfo(code = "MYR", symbol = "RM", name = "Malaysian Ringgit", flagEmoji = "🇲🇾", scale = 2),
    CurrencyInfo(code = "SGD", symbol = "S$", name = "Singapore Dollar", flagEmoji = "🇸🇬", scale = 2),
    CurrencyInfo(code = "CAD", symbol = "CA$", name = "Canadian Dollar", flagEmoji = "🇨🇦", scale = 2),
    CurrencyInfo(code = "AUD", symbol = "AU$", name = "Australian Dollar", flagEmoji = "🇦🇺", scale = 2),
    CurrencyInfo(code = "KWD", symbol = "KD", name = "Kuwaiti Dinar", flagEmoji = "🇰🇼", scale = 3),
    CurrencyInfo(code = "JPY", symbol = "¥", name = "Japanese Yen", flagEmoji = "🇯🇵", scale = 0),
  )

  fun getCurrency(code: String): CurrencyInfo {
    return supportedCurrencies.find { it.code == code } ?: supportedCurrencies.first()
  }

  fun formatMoney(minorUnits: Long, currencyCode: String, isVisible: Boolean = true): String =
    MoneyEngine.formatMinor(minorUnits, currencyCode, isVisible)

  // Demo People directory
  val demoPeople = mutableStateListOf(
    PersonItem(id = "p1", name = "Rahat Khan", phone = "+880 1711-234567", email = "rahat.k@example.com"),
    PersonItem(id = "p2", name = "Sadia Ahmed", phone = "+880 1819-876543", email = "sadia.a@example.com"),
    PersonItem(id = "p3", name = "Alex Rivera", phone = "+1 (555) 349-1102", email = "alex.rivera@example.com"),
    PersonItem(id = "p4", name = "Tanvir Hasan", phone = "+880 1912-345678", email = "tanvir.h@example.com"),
  )

  // Demo Loans
  val demoLoans = mutableStateListOf(
    LoanItem(
      id = "l1",
      personId = "p1",
      personName = "Rahat Khan",
      type = LoanType.LENT,
      principalMinorUnits = 1500000L, // 15,000 BDT
      repaidMinorUnits = 500000L, // 5,000 BDT
      currencyCode = "BDT",
      dateFormatted = "Oct 15, 2026",
      dueDateFormatted = "Nov 30, 2026",
      note = "Emergency laptop repair support",
    ),
    LoanItem(
      id = "l2",
      personId = "p2",
      personName = "Sadia Ahmed",
      type = LoanType.BORROWED,
      principalMinorUnits = 800000L, // 8,000 BDT
      repaidMinorUnits = 0L,
      currencyCode = "BDT",
      dateFormatted = "Oct 28, 2026",
      dueDateFormatted = "Dec 15, 2026",
      note = "Studio camera equipment advance",
    ),
    LoanItem(
      id = "l3",
      personId = "p3",
      personName = "Alex Rivera",
      type = LoanType.LENT,
      principalMinorUnits = 40000L, // 400.00 USD
      repaidMinorUnits = 15000L, // 150.00 USD
      currencyCode = "USD",
      dateFormatted = "Sep 10, 2026",
      dueDateFormatted = "Nov 15, 2026",
      note = "Conference travel ticket share",
    ),
  )

  // Pre-loaded realistic demo wallets across currencies
  val demoWallets = mutableStateListOf(
    // BDT
    WalletItem(
      id = "w1",
      name = "bKash Salary (বিকাশ)",
      category = "MFS",
      currencyCode = "BDT",
      balanceMinorUnits = 7500000L, // 75,000.00 BDT
      colorHex = 0xFFD81B60,
      iconName = "Smartphone",
    ),
    WalletItem(
      id = "w2",
      name = "City Bank Premium",
      category = "Bank",
      currencyCode = "BDT",
      balanceMinorUnits = 14000000L, // 140,000.00 BDT
      colorHex = 0xFF1976D2,
      iconName = "AccountBalance",
    ),
    WalletItem(
      id = "w3",
      name = "Daily Cash Wallet",
      category = "Cash",
      currencyCode = "BDT",
      balanceMinorUnits = 1250000L, // 12,500.00 BDT
      colorHex = 0xFF00897B,
      iconName = "Payments",
    ),
    // USD
    WalletItem(
      id = "w4",
      name = "Stripe Client Payout",
      category = "Vault",
      currencyCode = "USD",
      balanceMinorUnits = 185000L, // 1,850.00 USD
      colorHex = 0xFF6366F1,
      iconName = "AccountBalanceWallet",
    ),
    WalletItem(
      id = "w5",
      name = "Wise Digital Card",
      category = "Card",
      currencyCode = "USD",
      balanceMinorUnits = 42000L, // 420.00 USD
      colorHex = 0xFF0284C7,
      iconName = "CreditCard",
    ),
    // EUR
    WalletItem(
      id = "w6",
      name = "Revolut Euro Vault",
      category = "Vault",
      currencyCode = "EUR",
      balanceMinorUnits = 95000L, // 950.00 EUR
      colorHex = 0xFF8B5CF6,
      iconName = "Savings",
    ),
    // GBP
    WalletItem(
      id = "w7",
      name = "Barclays UK Account",
      category = "Bank",
      currencyCode = "GBP",
      balanceMinorUnits = 68000L, // 680.00 GBP
      colorHex = 0xFF0D9488,
      iconName = "AccountBalance",
    ),
    // INR
    WalletItem(
      id = "w8",
      name = "HDFC Remittance",
      category = "Bank",
      currencyCode = "INR",
      balanceMinorUnits = 4500000L, // 45,000.00 INR
      colorHex = 0xFFE65100,
      iconName = "AccountBalance",
    ),
    // SAR
    WalletItem(
      id = "w9",
      name = "Al Rajhi Riyal Vault",
      category = "Bank",
      currencyCode = "SAR",
      balanceMinorUnits = 320000L, // 3,200.00 SAR
      colorHex = 0xFF2E7D32,
      iconName = "AccountBalance",
    ),
    // AED
    WalletItem(
      id = "w10",
      name = "Emirates NBD",
      category = "Bank",
      currencyCode = "AED",
      balanceMinorUnits = 250000L, // 2,500.00 AED
      colorHex = 0xFFC2185B,
      iconName = "AccountBalance",
    ),
    // JPY
    WalletItem(
      id = "w11",
      name = "Tokyo Yen Travel Cash",
      category = "Cash",
      currencyCode = "JPY",
      balanceMinorUnits = 120000L, // 120,000 JPY (0 decimals)
      colorHex = 0xFFC62828,
      iconName = "Payments",
    ),
    // KWD
    WalletItem(
      id = "w12",
      name = "National Bank of Kuwait",
      category = "Bank",
      currencyCode = "KWD",
      balanceMinorUnits = 850250L, // 850.250 KWD (3 decimals)
      colorHex = 0xFF1565C0,
      iconName = "AccountBalance",
    ),
    // SGD
    WalletItem(
      id = "w13",
      name = "DBS Singapore Vault",
      category = "Vault",
      currencyCode = "SGD",
      balanceMinorUnits = 145000L, // 1,450.00 SGD
      colorHex = 0xFFAD1457,
      iconName = "Savings",
    ),
  )

  // Pre-loaded realistic demo transactions
  val demoTransactions = mutableStateListOf(
    TransactionItem(
      id = "tx1",
      title = "Freelance Client Payout",
      category = "Work & Client",
      type = TransactionType.INCOME,
      amountMinorUnits = 4500000L, // 45,000.00 BDT
      currencyCode = "BDT",
      dateFormatted = "Today, 02:15 PM",
      walletName = "City Bank Premium",
      note = "Mobile UI/UX architecture contract milestone",
    ),
    TransactionItem(
      id = "tx2",
      title = "Grocery & Organic Market",
      category = "Food & Dining",
      type = TransactionType.EXPENSE,
      amountMinorUnits = 320000L, // 3,200.00 BDT
      currencyCode = "BDT",
      dateFormatted = "Today, 11:30 AM",
      walletName = "bKash Salary (বিকাশ)",
      note = "Weekly groceries and fruit basket",
    ),
    TransactionItem(
      id = "tx3",
      title = "Loan to Rahat Khan",
      category = "People & Loans",
      type = TransactionType.PEOPLE,
      amountMinorUnits = 1500000L, // 15,000.00 BDT
      currencyCode = "BDT",
      dateFormatted = "Oct 15, 03:00 PM",
      walletName = "City Bank Premium",
      personName = "Rahat Khan",
      note = "Emergency laptop repair support",
    ),
    TransactionItem(
      id = "tx4",
      title = "Transfer to Daily Cash",
      category = "Transfer",
      type = TransactionType.TRANSFER,
      amountMinorUnits = 500000L, // 5,000.00 BDT
      currencyCode = "BDT",
      dateFormatted = "Yesterday, 01:20 PM",
      walletName = "bKash Salary (বিকাশ)",
      destWalletName = "Daily Cash Wallet",
      note = "Cash reserve withdrawal",
    ),
    TransactionItem(
      id = "tx5",
      title = "App Store Developer Payout",
      category = "Software Royalty",
      type = TransactionType.INCOME,
      amountMinorUnits = 65000L, // 650.00 USD
      currencyCode = "USD",
      dateFormatted = "Nov 1, 06:45 PM",
      walletName = "Stripe Client Payout",
      note = "Monthly international subscription earnings",
    ),
    TransactionItem(
      id = "tx6",
      title = "Cloud Infrastructure Hosting",
      category = "Tech & Tools",
      type = TransactionType.EXPENSE,
      amountMinorUnits = 4800L, // 48.00 USD
      currencyCode = "USD",
      dateFormatted = "Oct 31, 10:10 AM",
      walletName = "Wise Digital Card",
      note = "Serverless build container runtime",
    ),
    TransactionItem(
      id = "tx7",
      title = "European Design Workshop",
      category = "Education",
      type = TransactionType.EXPENSE,
      amountMinorUnits = 12000L, // 120.00 EUR
      currencyCode = "EUR",
      dateFormatted = "Oct 29, 03:00 PM",
      walletName = "Revolut Euro Vault",
      note = "Spatial interaction masterclass ticket",
    ),
  )

  // Demo budgets
  val demoBudgets = listOf(
    BudgetItem(
      id = "b1",
      category = "Food & Dining",
      spentMinorUnits = 1840000L, // 18,400 BDT
      limitMinorUnits = 2500000L, // 25,000 BDT
      currencyCode = "BDT",
      iconName = "Restaurant",
    ),
    BudgetItem(
      id = "b2",
      category = "Housing & Bills",
      spentMinorUnits = 2200000L,
      limitMinorUnits = 3000000L,
      currencyCode = "BDT",
      iconName = "Home",
    ),
    BudgetItem(
      id = "b3",
      category = "Tech & Tools",
      spentMinorUnits = 12000L, // 120 USD
      limitMinorUnits = 20000L, // 200 USD
      currencyCode = "USD",
      iconName = "Laptop",
    ),
  )

  // Demo savings goals
  val demoSavingsGoals = listOf(
    SavingsGoalItem(
      id = "g1",
      name = "MacBook Pro M4 Max",
      savedMinorUnits = 18000000L, // 180,000 BDT
      targetMinorUnits = 32000000L, // 320,000 BDT
      currencyCode = "BDT",
      iconName = "Computer",
    ),
    SavingsGoalItem(
      id = "g2",
      name = "Emergency Freedom Fund",
      savedMinorUnits = 240000L, // 2,400 USD
      targetMinorUnits = 500000L, // 5,000 USD
      currencyCode = "USD",
      iconName = "Shield",
    ),
  )
}
