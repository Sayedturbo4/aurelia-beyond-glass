package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataProvider
import com.example.data.MoneyEngine
import com.example.data.WalletItem
import com.example.data.local.WalletEntity
import com.example.ui.viewmodel.FinanceOverviewViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AureliaBadge
import com.example.ui.components.AureliaChip
import com.example.ui.components.AureliaGlassButton
import com.example.ui.components.AureliaGlassCard
import com.example.ui.components.AureliaPagerIndicator
import com.example.ui.components.GlassStyle
import com.example.ui.theme.AureliaThemeTokens
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletsScreen(
  isBalanceVisible: Boolean,
  modifier: Modifier = Modifier,
  financeViewModel: FinanceOverviewViewModel = viewModel(),
) {
  val colors = AureliaThemeTokens.colors
  val currencies = DemoDataProvider.supportedCurrencies
  val domainWallets by financeViewModel.domainWallets.collectAsState()
  val archivedWalletRows by financeViewModel.archivedWallets.collectAsState()
  val persistedWallets = domainWallets.map { wallet ->
    WalletItem(wallet.id, wallet.name, wallet.category, wallet.currencyCode, wallet.balanceMinorUnits, wallet.colorHex, wallet.iconName)
  }
  val pagerState = rememberPagerState(initialPage = 0, pageCount = { currencies.size })
  val scope = rememberCoroutineScope()

  val activeCurrency = currencies[pagerState.currentPage]
  val walletsForCurrency = persistedWallets.filter { it.currencyCode == activeCurrency.code }
  val currencyAggregate = walletsForCurrency.fold(0L) { total, wallet -> Math.addExact(total, wallet.balanceMinorUnits) }

  var isCreateWalletSheetOpen by remember { mutableStateOf(false) }
  var selectedWalletDetails by remember { mutableStateOf<WalletItem?>(null) }
  var showArchiveConfirmation by remember { mutableStateOf(false) }
  var walletActionError by remember { mutableStateOf<String?>(null) }
  val createSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val detailsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Header
    item {
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "Wallet Collection",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
          )
          Text(
            text = "Multi-currency segregated vaults",
            fontSize = 12.sp,
            color = colors.textSecondary,
          )
        }
        AureliaGlassButton(
          text = "+ New Wallet",
          onClick = { isCreateWalletSheetOpen = true },
          icon = Icons.Default.Add,
          isPrimary = true,
        )
      }
    }

    // 2. SWIPEABLE CURRENCY CAROUSEL (HorizontalPager)
    item {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Swipe Currency Carousel",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary,
          )

          // Accessible chevron buttons
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = {
                if (pagerState.currentPage > 0) {
                  scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) }
                }
              },
              enabled = pagerState.currentPage > 0,
              modifier = Modifier.size(28.dp),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Previous Currency",
                tint = if (pagerState.currentPage > 0) colors.textPrimary else colors.textSecondary.copy(alpha = 0.3f),
                modifier = Modifier.size(16.dp),
              )
            }
            Spacer(modifier = Modifier.width(4.dp))
            IconButton(
              onClick = {
                if (pagerState.currentPage < currencies.size - 1) {
                  scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                }
              },
              enabled = pagerState.currentPage < currencies.size - 1,
              modifier = Modifier.size(28.dp),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Next Currency",
                tint = if (pagerState.currentPage < currencies.size - 1) colors.textPrimary else colors.textSecondary.copy(alpha = 0.3f),
                modifier = Modifier.size(16.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        HorizontalPager(
          state = pagerState,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("wallets_currency_pager"),
        ) { pageIndex ->
          val curr = currencies[pageIndex]
          val wList = persistedWallets.filter { it.currencyCode == curr.code }
          val sum = wList.fold(0L) { total, wallet -> Math.addExact(total, wallet.balanceMinorUnits) }

          AureliaGlassCard(
            modifier = Modifier.fillMaxWidth(),
            glassStyle = GlassStyle.AURORA,
            shape = RoundedCornerShape(24.dp),
          ) {
            Column(modifier = Modifier.padding(20.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "${curr.flagEmoji} ${curr.code}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(text = "• ${curr.name}", fontSize = 12.sp, color = colors.textSecondary)
                }
                AureliaBadge(text = "${curr.scale} Decimals", color = colors.auroraLavender)
              }

              Spacer(modifier = Modifier.height(14.dp))

              Text(
                text = DemoDataProvider.formatMoney(sum, curr.code, isBalanceVisible),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
              )

              Spacer(modifier = Modifier.height(4.dp))

              Text(
                text = "${wList.size} segregated wallets in ${curr.code}",
                fontSize = 12.sp,
                color = colors.textSecondary,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Pager Indicator
        AureliaPagerIndicator(
          pageCount = currencies.size,
          currentPage = pagerState.currentPage,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }

    // 3. Quick Jump Pills
    item {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(currencies.indices.toList()) { index ->
          val curr = currencies[index]
          val isSelected = index == pagerState.currentPage
          AureliaGlassCard(
            modifier = Modifier.clickable {
              scope.launch { pagerState.animateScrollToPage(index) }
            },
            glassStyle = if (isSelected) GlassStyle.CRYSTAL else GlassStyle.SMOKE,
            shape = RoundedCornerShape(12.dp),
            borderWidth = if (isSelected) 1.5.dp else 1.dp,
          ) {
            Box(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = "${curr.flagEmoji} ${curr.code}",
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) colors.textPrimary else colors.textSecondary,
              )
            }
          }
        }
      }
    }

    // 4. Wallets List for Selected Currency
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "${activeCurrency.code} Wallets (${walletsForCurrency.size})",
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.textPrimary,
        )
        Text(
          text = "+ New ${activeCurrency.code}",
          fontSize = 12.sp,
          color = colors.auroraLavender,
          fontWeight = FontWeight.Medium,
          modifier = Modifier.clickable { isCreateWalletSheetOpen = true },
        )
      }
    }

    if (walletsForCurrency.isEmpty()) {
      item {
        AureliaGlassCard(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(20.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(
              text = "No wallets created in ${activeCurrency.code}",
              fontSize = 15.sp,
              fontWeight = FontWeight.SemiBold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Create your first ${activeCurrency.code} cash, bank or card wallet now.",
              fontSize = 13.sp,
              color = colors.textSecondary,
            )
            Spacer(modifier = Modifier.height(14.dp))
            AureliaGlassButton(
              text = "Add ${activeCurrency.code} Wallet",
              onClick = { isCreateWalletSheetOpen = true },
              isPrimary = true,
            )
          }
        }
      }
    } else {
      items(walletsForCurrency, key = { it.id }) { wallet ->
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(20.dp),
          onClick = { selectedWalletDetails = wallet },
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(46.dp)
                  .clip(CircleShape)
                  .background(Color(wallet.colorHex).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = when (wallet.category) {
                    "MFS" -> Icons.Default.Smartphone
                    "Bank" -> Icons.Default.AccountBalance
                    "Cash" -> Icons.Default.Payments
                    "Card" -> Icons.Default.CreditCard
                    else -> Icons.Default.Savings
                  },
                  contentDescription = null,
                  tint = Color(wallet.colorHex),
                  modifier = Modifier.size(24.dp),
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column {
                Text(
                  text = wallet.name,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = colors.textPrimary,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  AureliaBadge(text = wallet.category, color = colors.auroraLavender)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "Active Vault",
                    fontSize = 11.sp,
                    color = colors.textSecondary,
                  )
                }
              }
            }

            Text(
              text = DemoDataProvider.formatMoney(wallet.balanceMinorUnits, wallet.currencyCode, isBalanceVisible),
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = colors.textPrimary,
            )
          }
        }
      }
    }

    if (archivedWalletRows.isNotEmpty()) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Archived wallets", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
          Text("Restore an archived zero-balance wallet when you need it again.", fontSize = 12.sp, color = colors.textSecondary)
        }
      }
      items(archivedWalletRows, key = { "archived-${it.id}" }) { archived ->
        AureliaGlassCard(modifier = Modifier.fillMaxWidth(), glassStyle = GlassStyle.PEARL, shape = RoundedCornerShape(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(archived.name, color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
              Text("${archived.currencyCode} · Archived", color = colors.textSecondary, fontSize = 12.sp)
            }
            TextButton(onClick = {
              financeViewModel.restoreWallet(archived.id, System.currentTimeMillis()) { result ->
                if (result.isFailure) walletActionError = result.exceptionOrNull()?.message ?: "Could not restore wallet"
              }
            }) { Text("Restore") }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(84.dp))
    }
  }

  // Create Wallet Sheet
  if (isCreateWalletSheetOpen) {
    var newWalletName by remember { mutableStateOf("") }
    var newWalletCategory by remember { mutableStateOf("MFS") }
    var newWalletCurrency by remember { mutableStateOf(activeCurrency.code) }
    var newWalletBalanceInput by remember { mutableStateOf("") }
    var createError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
      onDismissRequest = { isCreateWalletSheetOpen = false },
      sheetState = createSheetState,
      containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
      shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 24.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Create New Wallet",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
          )
          IconButton(onClick = { isCreateWalletSheetOpen = false }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = colors.textSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Name
        OutlinedTextField(
          value = newWalletName,
          onValueChange = {
            newWalletName = it
            createError = null
          },
          label = { Text("Wallet Name (e.g. Nagad Primary, Bank Vault)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.60f else 0.85f),
            unfocusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.45f else 0.70f),
            focusedBorderColor = colors.auroraLavender,
            unfocusedBorderColor = colors.borderFrosted.copy(alpha = 0.50f),
            focusedTextColor = colors.textPrimary,
            unfocusedTextColor = colors.textPrimary,
          ),
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Currency Picker
        Text(text = "Currency", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(currencies) { curr ->
            AureliaChip(
              text = "${curr.flagEmoji} ${curr.code}",
              isSelected = newWalletCurrency == curr.code,
              onClick = { newWalletCurrency = curr.code },
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Category Picker
        Text(text = "Wallet Type", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          val types = listOf("MFS", "Bank", "Cash", "Card", "Vault")
          items(types) { t ->
            AureliaChip(
              text = t,
              isSelected = newWalletCategory == t,
              onClick = { newWalletCategory = t },
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Opening Balance
        OutlinedTextField(
          value = newWalletBalanceInput,
          onValueChange = { newWalletBalanceInput = it.filter { c -> c.isDigit() || c == '.' } },
          label = { Text("Opening Balance (Optional)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.60f else 0.85f),
            unfocusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.45f else 0.70f),
            focusedBorderColor = colors.auroraLavender,
            unfocusedBorderColor = colors.borderFrosted.copy(alpha = 0.50f),
            focusedTextColor = colors.textPrimary,
            unfocusedTextColor = colors.textPrimary,
          ),
        )

        if (createError != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = createError!!, color = colors.financialExpense, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        AureliaGlassButton(
          text = "Save Wallet",
          onClick = {
            if (newWalletName.isBlank()) {
              createError = "Please enter a valid wallet name"
              return@AureliaGlassButton
            }
            val minor = try {
              if (newWalletBalanceInput.isBlank()) 0L
              else MoneyEngine.parseMajorToMinor(newWalletBalanceInput, newWalletCurrency)
            } catch (error: IllegalArgumentException) {
              createError = error.message ?: "Enter a valid opening balance"
              return@AureliaGlassButton
            } catch (error: ArithmeticException) {
              createError = "Opening balance is outside the supported range"
              return@AureliaGlassButton
            }

            val newW = WalletItem(
              id = "w_${UUID.randomUUID().toString().take(6)}",
              name = newWalletName,
              category = newWalletCategory,
              currencyCode = newWalletCurrency,
              balanceMinorUnits = minor,
              colorHex = 0xFF6366F1,
              iconName = "AccountBalanceWallet",
            )
            financeViewModel.createWallet(
              WalletEntity(
                id = newW.id, name = newW.name, category = newW.category,
                currencyCode = newW.currencyCode, balanceMinorUnits = newW.balanceMinorUnits,
                colorHex = newW.colorHex, iconName = newW.iconName,
                createdAtMillis = System.currentTimeMillis(), updatedAtMillis = System.currentTimeMillis(),
              ),
            ) { result ->
              if (result.isSuccess) {
                isCreateWalletSheetOpen = false
                createError = null
              } else {
                createError = result.exceptionOrNull()?.message ?: "Could not save wallet"
              }
            }
          },
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  // Wallet Details Sheet
  if (selectedWalletDetails != null) {
    val wallet = selectedWalletDetails!!
    ModalBottomSheet(
      onDismissRequest = { selectedWalletDetails = null },
      sheetState = detailsSheetState,
      containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
      shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 24.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(text = wallet.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
          IconButton(onClick = { selectedWalletDetails = null }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = colors.textSecondary)
          }
        }
        Spacer(modifier = Modifier.height(14.dp))
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.AURORA,
          shape = RoundedCornerShape(22.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            AureliaBadge(text = "${wallet.category} VAULT", color = colors.auroraLavender)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = DemoDataProvider.formatMoney(wallet.balanceMinorUnits, wallet.currencyCode, isBalanceVisible),
              fontSize = 30.sp,
              fontWeight = FontWeight.Bold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Currency: ${wallet.currencyCode}", fontSize = 13.sp, color = colors.textSecondary)
          }
        }
        if (walletActionError != null) {
          Text(
            text = walletActionError.orEmpty(),
            color = colors.financialExpense,
            fontSize = 12.sp,
          )
          Spacer(modifier = Modifier.height(8.dp))
        }
        AureliaGlassButton(
          text = "Archive empty wallet",
          isPrimary = false,
          onClick = { walletActionError = null; showArchiveConfirmation = true },
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(10.dp))
        AureliaGlassButton(
          text = "Close Vault Details",
          isPrimary = false,
          onClick = { selectedWalletDetails = null },
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  if (showArchiveConfirmation && selectedWalletDetails != null) {
    val walletToArchive = selectedWalletDetails!!
    AlertDialog(
      onDismissRequest = { showArchiveConfirmation = false },
      title = { Text("Archive ${walletToArchive.name}?") },
      text = {
        Text("Only a zero-balance wallet can be archived. Its historical transactions will remain available.")
      },
      confirmButton = {
        TextButton(
          onClick = {
            financeViewModel.archiveWallet(walletToArchive.id, System.currentTimeMillis()) { result ->
              if (result.isSuccess) {
                showArchiveConfirmation = false
                selectedWalletDetails = null
                walletActionError = null
              } else {
                walletActionError = result.exceptionOrNull()?.message ?: "Could not archive wallet"
                showArchiveConfirmation = false
              }
            }
          },
        ) { Text("Archive") }
      },
      dismissButton = {
        TextButton(onClick = { showArchiveConfirmation = false }) { Text("Cancel") }
      },
    )
  }
}
