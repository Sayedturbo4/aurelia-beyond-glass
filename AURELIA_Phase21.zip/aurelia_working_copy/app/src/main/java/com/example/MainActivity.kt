package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.data.TransactionType
import com.example.ui.components.AureliaBottomNavBar
import com.example.ui.components.AureliaNavDestination
import com.example.ui.screens.ActivityScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MoreScreen
import com.example.ui.screens.PeopleScreen
import com.example.ui.screens.PlanningScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.QuickAddSheet
import com.example.ui.screens.WalletsScreen
import com.example.ui.viewmodel.FinanceOverviewViewModel
import com.example.ui.theme.AureliaSpatialBackground
import com.example.ui.theme.AureliaTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      AureliaAppRoot()
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AureliaAppRoot() {
  var isDarkTheme by remember { mutableStateOf(false) }
  var isBalanceVisible by remember { mutableStateOf(true) }
  var currentDestination by remember { mutableStateOf(AureliaNavDestination.HOME) }
  var previousDestination by remember { mutableStateOf(AureliaNavDestination.HOME) }
  var isQuickAddOpen by remember { mutableStateOf(false) }
  var quickAddInitialType by remember { mutableStateOf(TransactionType.EXPENSE) }

  val financeViewModel: FinanceOverviewViewModel = viewModel()
  val dashboardWallets by financeViewModel.domainWallets.collectAsState()
  val dashboardTransactions by financeViewModel.domainTransactions.collectAsState()
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  // Back handling: if on People, return to previous; otherwise if not Home, return to Home
  if (currentDestination != AureliaNavDestination.HOME) {
    BackHandler {
      currentDestination = if (currentDestination == AureliaNavDestination.PEOPLE || currentDestination == AureliaNavDestination.PLANNING || currentDestination == AureliaNavDestination.REPORTS) {
        previousDestination
      } else {
        AureliaNavDestination.HOME
      }
    }
  }

  AureliaTheme(darkTheme = isDarkTheme) {
    AureliaSpatialBackground {
      Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent, // Let spatial background shine through
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
          AureliaBottomNavBar(
            currentDestination = currentDestination,
            onNavigate = { destination ->
              if (destination == AureliaNavDestination.ADD) {
                quickAddInitialType = TransactionType.EXPENSE
                isQuickAddOpen = true
              } else {
                previousDestination = currentDestination
                currentDestination = destination
              }
            },
          )
        },
      ) { innerPadding ->
        Box(
          modifier = Modifier.fillMaxSize(),
        ) {
          AnimatedContent(
            targetState = currentDestination,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "nav_screen_transition",
          ) { destination ->
            when (destination) {
              AureliaNavDestination.HOME -> {
                HomeScreen(
                  isBalanceVisible = isBalanceVisible,
                  onToggleBalanceVisibility = { isBalanceVisible = !isBalanceVisible },
                  isDarkTheme = isDarkTheme,
                  onToggleTheme = { isDarkTheme = !isDarkTheme },
                  onOpenQuickAdd = { type ->
                    quickAddInitialType = type
                    isQuickAddOpen = true
                  },
                  onViewAllWallets = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.WALLETS
                  },
                  onViewAllActivity = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.ACTIVITY
                  },
                  onNavigateToPeople = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.PEOPLE
                  },
                  wallets = dashboardWallets,
                  transactions = dashboardTransactions,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.ACTIVITY -> {
                ActivityScreen(
                  isBalanceVisible = isBalanceVisible,
                  viewModel = financeViewModel,
                  onOpenQuickAdd = { type ->
                    quickAddInitialType = type
                    isQuickAddOpen = true
                  },
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.WALLETS -> {
                WalletsScreen(
                  isBalanceVisible = isBalanceVisible,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.MORE -> {
                MoreScreen(
                  isDarkTheme = isDarkTheme,
                  onToggleTheme = { isDarkTheme = !isDarkTheme },
                  onNavigateToPeople = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.PEOPLE
                  },
                  onNavigateToPlanning = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.PLANNING
                  },
                  onNavigateToReports = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.REPORTS
                  },
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.PEOPLE -> {
                PeopleScreen(
                  viewModel = financeViewModel,
                  isBalanceVisible = isBalanceVisible,
                  onNavigateBack = {
                    currentDestination = previousDestination
                  },
                  onOpenQuickAddWithPeople = {
                    quickAddInitialType = TransactionType.PEOPLE
                    isQuickAddOpen = true
                  },
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.PLANNING -> {
                PlanningScreen(
                  viewModel = financeViewModel,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.REPORTS -> {
                ReportsScreen(
                  viewModel = financeViewModel,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.ADD -> {
                // Handled by modal bottom sheet
              }
            }
          }

          // Quick Add Modal Bottom Sheet
          if (isQuickAddOpen) {
            QuickAddSheet(
              sheetState = sheetState,
              initialType = quickAddInitialType,
              onDismiss = { isQuickAddOpen = false },
              onSuccess = { msg ->
                scope.launch {
                  snackbarHostState.showSnackbar(msg)
                }
              },
              viewModel = financeViewModel,
            )
          }
        }
      }
    }
  }
}
