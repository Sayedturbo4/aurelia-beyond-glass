package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AureliaDatabase
import com.example.data.local.BudgetEntity
import com.example.data.local.FinanceLocalRepository
import com.example.data.local.LoanEntity
import com.example.data.local.PersonEntity
import com.example.data.local.SavingsGoalEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.WalletEntity
import com.example.domain.mapper.summarizeByCurrency
import com.example.domain.mapper.toDomain
import com.example.domain.model.CurrencyWalletSummary
import com.example.domain.model.FinanceTransaction
import com.example.domain.model.Loan
import com.example.domain.model.Person
import com.example.domain.model.Wallet
import com.example.domain.report.FinanceReport
import com.example.domain.report.FinanceReportCalculator
import com.example.domain.report.ReportDateRange
import com.example.domain.report.ReportTransaction
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Lifecycle-aware read model for local finance data. Screens can collect these flows safely. */
class FinanceOverviewViewModel(application: Application) : AndroidViewModel(application) {
  private val repository = FinanceLocalRepository(AureliaDatabase.getInstance(application))

  init {
    viewModelScope.launch {
      // Seed only a brand-new empty database; the repository records a durable one-time marker.
      repository.seedDemoDataIfNeeded(System.currentTimeMillis())
    }
  }

  val people: StateFlow<List<PersonEntity>> = repository.observePeople()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val wallets: StateFlow<List<WalletEntity>> = repository.observeWallets()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val loans: StateFlow<List<LoanEntity>> = repository.observeLoans()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val latestTransactions: StateFlow<List<TransactionEntity>> = repository.observeLatestTransactions()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  /** Complete local ledger for period-based calculations; not truncated to the recent-activity limit. */
  val allTransactions: StateFlow<List<TransactionEntity>> = repository.observeAllTransactions()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val budgets: StateFlow<List<BudgetEntity>> = repository.observeBudgets()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val savingsGoals: StateFlow<List<SavingsGoalEntity>> = repository.observeSavingsGoals()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  /** Current-month report projection. It is currency-separated and excludes transfers/loan entries. */
  val currentMonthReport: StateFlow<FinanceReport> = combine(allTransactions, wallets) { transactionRows, walletRows ->
    val range = FinanceReportCalculator.currentMonthRange(System.currentTimeMillis())
    val reportRows = transactionRows.map { row ->
      ReportTransaction(
        id = row.id,
        type = row.type,
        amountMinorUnits = row.amountMinorUnits,
        currencyCode = row.currencyCode,
        categoryId = row.categoryId,
        walletId = row.walletId,
        occurredAtMillis = row.occurredAtMillis,
      )
    }
    FinanceReportCalculator.calculate(reportRows, walletRows.associate { it.id to it.name }, range)
  }.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5_000),
    FinanceReportCalculator.calculate(
      emptyList(), emptyMap(),
      FinanceReportCalculator.currentMonthRange(System.currentTimeMillis()),
    ),
  )

  /** Reusable report calculation for a caller-selected half-open date interval. */
  fun calculateReport(range: ReportDateRange): FinanceReport {
    val walletNames = wallets.value.associate { it.id to it.name }
    val rows = allTransactions.value.map { row ->
      ReportTransaction(
        id = row.id,
        type = row.type,
        amountMinorUnits = row.amountMinorUnits,
        currencyCode = row.currencyCode,
        categoryId = row.categoryId,
        walletId = row.walletId,
        occurredAtMillis = row.occurredAtMillis,
      )
    }
    return FinanceReportCalculator.calculate(rows, walletNames, range)
  }

  // UI-facing domain projections. Compose screens can consume these without depending on Room.
  val domainPeople: StateFlow<List<Person>> = people
    .map { rows -> rows.map { it.toDomain() } }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val domainWallets: StateFlow<List<Wallet>> = wallets
    .map { rows -> rows.map { it.toDomain() } }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val walletSummariesByCurrency: StateFlow<List<CurrencyWalletSummary>> = domainWallets
    .map { rows -> rows.summarizeByCurrency() }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val domainLoans: StateFlow<List<Loan>> = combine(loans, people) { loanRows, personRows ->
    val namesById = personRows.associate { it.id to it.name }
    loanRows.map { row -> row.toDomain(namesById[row.personId] ?: "Unknown person") }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val domainTransactions: StateFlow<List<FinanceTransaction>> = latestTransactions
    .map { rows -> rows.map { it.toDomain() } }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  /** Exposes a small safe coroutine boundary for UI actions; errors are returned to the caller. */
  fun createBudget(budget: BudgetEntity, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch { onResult(execute { repository.createBudget(budget) }) }
  }

  fun updateBudget(budget: BudgetEntity, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch { onResult(execute { repository.updateBudget(budget) }) }
  }

  fun deleteBudget(budgetId: String, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch { onResult(execute { repository.deleteBudget(budgetId) }) }
  }

  fun createSavingsGoal(goal: SavingsGoalEntity, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch { onResult(execute { repository.createSavingsGoal(goal) }) }
  }

  fun updateSavingsGoal(goal: SavingsGoalEntity, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch { onResult(execute { repository.updateSavingsGoal(goal) }) }
  }

  fun deleteSavingsGoal(goalId: String, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch { onResult(execute { repository.deleteSavingsGoal(goalId) }) }
  }

  fun createPerson(person: PersonEntity, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch {
      val result = execute { repository.createPerson(person) }
      onResult(result)
    }
  }

  fun createWallet(wallet: WalletEntity, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch {
      val result = execute { repository.createWallet(wallet) }
      onResult(result)
    }
  }

  fun postCashTransaction(transaction: TransactionEntity, nowMillis: Long, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch {
      val result = execute { repository.postCashTransaction(transaction, nowMillis) }
      onResult(result)
    }
  }

  fun postWalletTransfer(transaction: TransactionEntity, nowMillis: Long, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch {
      val result = execute { repository.postWalletTransfer(transaction, nowMillis) }
      onResult(result)
    }
  }

  fun createLoan(loan: LoanEntity, walletId: String, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch {
      val result = execute { repository.createLoan(loan, walletId) }
      onResult(result)
    }
  }

  fun createPersonAndLoan(person: PersonEntity, loan: LoanEntity, walletId: String, onResult: (Result<Unit>) -> Unit = {}) {
    viewModelScope.launch {
      val result = execute { repository.createPersonAndLoan(person, loan, walletId) }
      onResult(result)
    }
  }

  fun recordLoanRepayment(
    loanId: String,
    amountMinorUnits: Long,
    walletId: String,
    occurredAtMillis: Long,
    transactionId: String,
    nowMillis: Long,
    onResult: (Result<Unit>) -> Unit = {},
  ) {
    viewModelScope.launch {
      val result = execute {
        repository.recordLoanRepayment(
          loanId, amountMinorUnits, walletId, occurredAtMillis, transactionId, nowMillis,
        )
      }
      onResult(result)
    }
  }

  private suspend fun execute(block: suspend () -> Unit): Result<Unit> = try {
    block()
    Result.success(Unit)
  } catch (cancelled: kotlinx.coroutines.CancellationException) {
    throw cancelled
  } catch (error: Throwable) {
    Result.failure(error)
  }
}
