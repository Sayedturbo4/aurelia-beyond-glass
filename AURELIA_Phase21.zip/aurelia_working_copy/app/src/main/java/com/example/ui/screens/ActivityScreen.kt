package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataProvider
import com.example.data.TransactionItem
import com.example.data.TransactionType
import com.example.ui.components.AureliaBadge
import com.example.ui.components.AureliaChip
import com.example.ui.components.AureliaGlassButton
import com.example.ui.components.AureliaGlassCard
import com.example.ui.components.GlassStyle
import com.example.ui.theme.AureliaThemeTokens
import com.example.ui.viewmodel.FinanceOverviewViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityScreen(
  isBalanceVisible: Boolean,
  onOpenQuickAdd: (TransactionType) -> Unit,
  viewModel: FinanceOverviewViewModel,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  var searchQuery by remember { mutableStateOf("") }
  var selectedFilter by remember { mutableStateOf("All") }
  var selectedTransaction by remember { mutableStateOf<TransactionItem?>(null) }
  val detailSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()

  // Activity is now read from the persistent Room ledger, not the mutable demo fixture.
  val domainTransactions by viewModel.domainTransactions.collectAsState()
  val domainWallets by viewModel.domainWallets.collectAsState()
  val domainPeople by viewModel.domainPeople.collectAsState()
  val walletNames = remember(domainWallets) { domainWallets.associate { it.id to it.name } }
  val peopleNames = remember(domainPeople) { domainPeople.associate { it.id to it.name } }
  val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
  val ledgerTransactions = remember(domainTransactions, walletNames, peopleNames) {
    domainTransactions.map { row ->
      TransactionItem(
        id = row.id,
        title = row.title,
        category = row.categoryId,
        type = when (row.type.name) {
          "INCOME" -> TransactionType.INCOME
          "EXPENSE" -> TransactionType.EXPENSE
          "TRANSFER" -> TransactionType.TRANSFER
          else -> TransactionType.PEOPLE
        },
        amountMinorUnits = row.amountMinorUnits,
        currencyCode = row.currencyCode,
        dateFormatted = dateFormatter.format(Date(row.occurredAtMillis)),
        walletName = walletNames[row.walletId] ?: "Archived wallet",
        destWalletName = row.destinationWalletId?.let { walletNames[it] },
        personName = row.personId?.let { peopleNames[it] },
        note = row.note,
      )
    }
  }
  val filteredTransactions = ledgerTransactions.filter { tx ->
    val matchesSearch = tx.title.contains(searchQuery, ignoreCase = true) ||
      tx.category.contains(searchQuery, ignoreCase = true) ||
      tx.walletName.contains(searchQuery, ignoreCase = true) ||
      tx.note.contains(searchQuery, ignoreCase = true)
    val matchesType = when (selectedFilter) {
      "Income" -> tx.type == TransactionType.INCOME
      "Expense" -> tx.type == TransactionType.EXPENSE
      "Transfer" -> tx.type == TransactionType.TRANSFER
      else -> true
    }
    matchesSearch && matchesType
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // 1. Header
    item {
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "Activity & Ledger",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
          )
          Text(
            text = "Immutable transaction records",
            fontSize = 12.sp,
            color = colors.textSecondary,
          )
        }
        AureliaBadge(text = "Local Ledger", color = colors.auroraLavender)
      }
    }

    // 2. Search Text Field
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search transactions, notes, wallets...", color = colors.textSecondary.copy(alpha = 0.6f)) },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = colors.textSecondary,
          )
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = colors.textSecondary)
            }
          }
        },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("search_transactions_input"),
        shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.60f else 0.85f),
          unfocusedContainerColor = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.45f else 0.70f),
          focusedBorderColor = colors.auroraLavender,
          unfocusedBorderColor = colors.borderFrosted.copy(alpha = 0.50f),
          focusedTextColor = colors.textPrimary,
          unfocusedTextColor = colors.textPrimary,
        ),
      )
    }

    // 3. Filter Chips
    item {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val filterOptions = listOf("All", "Income", "Expense", "Transfer")
        items(filterOptions) { filter ->
          AureliaChip(
            text = filter,
            isSelected = selectedFilter == filter,
            onClick = { selectedFilter = filter },
          )
        }
      }
    }

    // 4. Ledger Summary Card
    item {
      // The summary labels are BDT, so never aggregate USD/EUR/etc. into these totals.
      val totalIncome = filteredTransactions
        .filter { it.type == TransactionType.INCOME && it.currencyCode == "BDT" }
        .fold(0L) { total, item -> Math.addExact(total, item.amountMinorUnits) }
      val totalExpense = filteredTransactions
        .filter { it.type == TransactionType.EXPENSE && it.currencyCode == "BDT" }
        .fold(0L) { total, item -> Math.addExact(total, item.amountMinorUnits) }

      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.PEARL,
        shape = RoundedCornerShape(20.dp),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceAround,
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "Total Inflow", fontSize = 12.sp, color = colors.textSecondary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "+${DemoDataProvider.formatMoney(totalIncome, "BDT", isBalanceVisible)}",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = colors.financialIncome,
            )
          }
          Box(
            modifier = Modifier
              .width(1.dp)
              .height(36.dp)
              .background(colors.borderFrosted.copy(alpha = 0.3f)),
          )
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "Total Outflow", fontSize = 12.sp, color = colors.textSecondary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "-${DemoDataProvider.formatMoney(totalExpense, "BDT", isBalanceVisible)}",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = colors.financialExpense,
            )
          }
        }
      }
    }

    // 5. Transactions List
    if (filteredTransactions.isEmpty()) {
      item {
        AureliaGlassCard(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(20.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(
              text = "No matching transactions found",
              fontSize = 15.sp,
              fontWeight = FontWeight.SemiBold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Try adjusting your search query or filter tags.",
              fontSize = 13.sp,
              color = colors.textSecondary,
            )
          }
        }
      }
    } else {
      items(filteredTransactions, key = { it.id }) { tx ->
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.SMOKE,
          shape = RoundedCornerShape(18.dp),
          onClick = {
            selectedTransaction = tx
          },
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(
                    when (tx.type) {
                      TransactionType.INCOME -> colors.financialIncome.copy(alpha = 0.2f)
                      TransactionType.EXPENSE -> colors.financialExpense.copy(alpha = 0.2f)
                      TransactionType.TRANSFER -> colors.auroraLavender.copy(alpha = 0.2f)
                      TransactionType.PEOPLE -> colors.auroraBlue.copy(alpha = 0.2f)
                    },
                  ),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = when (tx.type) {
                    TransactionType.INCOME -> Icons.Default.ArrowDownward
                    TransactionType.EXPENSE -> Icons.Default.ArrowUpward
                    TransactionType.TRANSFER -> Icons.Default.SyncAlt
                    TransactionType.PEOPLE -> Icons.Default.People
                  },
                  contentDescription = null,
                  tint = when (tx.type) {
                    TransactionType.INCOME -> colors.financialIncome
                    TransactionType.EXPENSE -> colors.financialExpense
                    TransactionType.TRANSFER -> colors.auroraLavender
                    TransactionType.PEOPLE -> colors.auroraBlue
                  },
                  modifier = Modifier.size(20.dp),
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = tx.title,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = colors.textPrimary,
                )
                Text(
                  text = "${tx.category} • ${tx.walletName}",
                  fontSize = 12.sp,
                  color = colors.textSecondary,
                )
                Text(
                  text = tx.dateFormatted,
                  fontSize = 11.sp,
                  color = colors.textSecondary.copy(alpha = 0.7f),
                )
              }
            }

            val prefix = when (tx.type) {
              TransactionType.INCOME -> "+"
              TransactionType.EXPENSE -> "-"
              TransactionType.TRANSFER -> "⇄ "
              TransactionType.PEOPLE -> "👥 "
            }
            val amountColor = when (tx.type) {
              TransactionType.INCOME -> colors.financialIncome
              TransactionType.EXPENSE -> colors.financialExpense
              TransactionType.TRANSFER -> colors.textPrimary
              TransactionType.PEOPLE -> colors.auroraBlue
            }
            Text(
              text = "$prefix${DemoDataProvider.formatMoney(tx.amountMinorUnits, tx.currencyCode, isBalanceVisible)}",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = amountColor,
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(84.dp))
    }
  }

  // Detailed Transaction Sheet
  if (selectedTransaction != null) {
    val tx = selectedTransaction!!
    ModalBottomSheet(
      onDismissRequest = { selectedTransaction = null },
      sheetState = detailSheetState,
      containerColor = if (colors.isDark) Color(0xFF161B26) else Color(0xFFF8F9FC),
      shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 24.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Transaction Details",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
          )
          IconButton(onClick = { selectedTransaction = null }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = colors.textSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Big Amount in card
        AureliaGlassCard(
          modifier = Modifier.fillMaxWidth(),
          glassStyle = GlassStyle.AURORA,
          shape = RoundedCornerShape(22.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            AureliaBadge(
              text = when (tx.type) {
                TransactionType.INCOME -> "INCOME RECEIPT"
                TransactionType.EXPENSE -> "EXPENSE OUTFLOW"
                TransactionType.TRANSFER -> "WALLET TRANSFER"
                TransactionType.PEOPLE -> "PEOPLE & LOANS"
              },
              color = when (tx.type) {
                TransactionType.INCOME -> colors.financialIncome
                TransactionType.EXPENSE -> colors.financialExpense
                TransactionType.TRANSFER -> colors.auroraLavender
                TransactionType.PEOPLE -> colors.auroraBlue
              },
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = DemoDataProvider.formatMoney(tx.amountMinorUnits, tx.currencyCode, isBalanceVisible),
              fontSize = 32.sp,
              fontWeight = FontWeight.Bold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = tx.title,
              fontSize = 15.sp,
              color = colors.textSecondary,
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        DetailRow(label = "Category", value = tx.category)
        DetailRow(label = "Wallet", value = tx.walletName)
        if (tx.destWalletName != null) {
          DetailRow(label = "Destination Wallet", value = tx.destWalletName)
        }
        DetailRow(label = "Date & Time", value = tx.dateFormatted)
        if (tx.note.isNotBlank()) {
          DetailRow(label = "Memo / Note", value = tx.note)
        }
        DetailRow(label = "Status", value = "Saved on this device")

        Spacer(modifier = Modifier.height(22.dp))

        // Financial history is immutable here; reversal must be a compensating ledger entry.
        AureliaGlassButton(
          text = "Reversal — Coming Soon",
          isPrimary = false,
          onClick = { /* Intentionally non-destructive until reversal accounting is implemented. */ },
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }
}

@Composable
private fun DetailRow(label: String, value: String) {
  val colors = AureliaThemeTokens.colors
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 7.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(text = label, fontSize = 13.sp, color = colors.textSecondary)
    Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
  }
}
