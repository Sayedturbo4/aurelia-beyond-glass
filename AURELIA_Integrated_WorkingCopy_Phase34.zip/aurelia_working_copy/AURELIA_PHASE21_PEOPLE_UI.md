# AURELIA Phase 21 — People Edit & Archive UI

## Implemented
- Added an Edit Person action to the person detail sheet.
- Added editable name, phone and email fields.
- Name is required; phone and email remain optional.
- Save routes through `FinanceOverviewViewModel.updatePerson`, preserving the repository's validation and immutable creation timestamp policy.
- Added an explicit archive confirmation explaining that history remains and unsettled loans block archiving.
- Archive routes through `FinanceOverviewViewModel.archivePerson`; repository transaction guards remain authoritative.
- Success closes the detail sheet; failures surface an inline message rather than silently dismissing.

## Safety
- No direct SQL or DAO writes from Compose.
- No hard-delete path introduced.
- Outstanding-loan checks remain inside the repository transaction, not just UI state.
- Existing Room schema unchanged; no migration required by this phase.

## Verification
- Existing Phase 20 lifecycle static checks: 8/8 passed.
- Source review confirms both UI actions call ViewModel APIs.
- ZIP integrity verified after packaging.
- Full Android Gradle/Compose compilation and physical-device interaction testing have NOT been run in this environment. Treat this as source-integrated, not build-verified.

## Remaining People work
- Archived people browser and restore workflow are still pending.
- Person-level transaction ledger and complete repayment event history still need implementation.
