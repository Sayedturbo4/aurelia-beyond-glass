# AURELIA Phase 26 — Categories Management

## Implemented
- Added persistent Room `CategoryEntity` with stable string IDs, EXPENSE/INCOME type, icon/color metadata, system/custom distinction, and archive state.
- Added `CategoryDao` for active, archived, lookup, reference-count and mutation operations.
- Added Room migration 4 → 5. It creates the categories table and seeds standard categories using legacy-compatible IDs such as `Food & Dining`, `Transport`, and `Shopping`, preserving existing transaction category IDs.
- Added repository create/update/archive/restore operations with validation and transaction protection. System categories cannot be edited or archived; custom categories are archived rather than hard-deleted so historical references remain stable.
- Exposed category StateFlows and mutation actions through `FinanceOverviewViewModel`.
- Added Categories screen reachable from More, supporting Expense/Income filters, create, edit, archive, archived list and restore.

## Verification
- Phase 26 targeted source checks: 10/10 passed.
- Phase 25 budget regression checks: 8/8 passed.
- ZIP integrity: checked after packaging.
- Full Android Gradle/Compose/KSP compilation: NOT run in this environment. The working copy has no `gradlew`, no `gradle-wrapper.jar`, and no system Gradle executable. Do not treat static checks as an Android build.

## Known follow-up
- Quick Add still contains a legacy in-memory category list; it is not yet dynamically driven by the new Room category flows. The persisted category management foundation and standalone management screen are implemented, but end-to-end category selection integration in Quick Add remains a follow-up item for final QA.
- Category deletion is intentionally not provided; archive/restore protects ledger references.
