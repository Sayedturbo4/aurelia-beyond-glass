# AURELIA Phase 29 — Security Foundation

## Implemented
- Added AndroidX Biometric dependency (stable 1.1.0).
- Added biometric/device-credential capability detection. Capability is not treated as authentication.
- Added pure app-lock timeout policy with bounded timeout and fail-closed handling for invalid negative durations.
- Added secure-window screenshot protection utility using `FLAG_SECURE`.
- Added unit tests for timeout and restart policy.
- Existing `allowBackup=false` and restricted FileProvider policy retained.

## Not yet complete
- The current More screen's biometric toggle remains a UI-only local state and is NOT wired to an authentication gate.
- No keystore-backed preference persistence or biometric prompt lifecycle integration yet.
- Screenshot protection is a utility and is not globally enabled; must be integrated selectively with lifecycle/UI in a later phase.
- No Android compilation or device test was run in this environment.

## Verification
- Static checks verify dependency catalog entries, security utility APIs, test coverage, manifest backup policy, and no new INTERNET permission.
