package com.example.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppSecurityPolicyTest {
  @Test fun disabledLockNeverLocks() {
    assertFalse(AppSecurityPolicy.shouldLock(false, 600_000L))
  }
  @Test fun locksAtConfiguredTimeout() {
    assertTrue(AppSecurityPolicy.shouldLock(true, 60_000L))
    assertFalse(AppSecurityPolicy.shouldLock(true, 59_999L))
  }
  @Test fun negativeBackgroundDurationFailsClosed() {
    assertTrue(AppSecurityPolicy.shouldLock(true, -1L))
  }
  @Test fun timeoutIsClampedToSafeMaximum() {
    assertTrue(AppSecurityPolicy.shouldLock(true, 900_000L, Long.MAX_VALUE))
  }
  @Test fun processRestartRequiresReauthenticationWhenEnabled() {
    assertTrue(AppSecurityPolicy.shouldRequireReauthenticationAfterProcessRestart(true))
    assertFalse(AppSecurityPolicy.shouldRequireReauthenticationAfterProcessRestart(false))
  }
}
