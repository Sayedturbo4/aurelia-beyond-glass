# AURELIA — Google AI Studio Continuation Brief (Phase 4.6 → 4.7)

Use this brief in the original Google AI Studio AURELIA project. The original project must remain the source-of-truth checkpoint. Continue from the last successful Phase 4.6 state; the prior Phase 4.7 attempt did not execute and must not be assumed applied.

## Non-negotiable constraints

- Do not create a new unrelated project or replace the existing project.
- Preserve existing working functionality and project identity.
- Native Android Kotlin + Jetpack Compose; not WebView.
- Offline-first. Do not add Supabase, Firebase Auth, cloud sync, network access, real-time messaging, or online billing in this phase.
- Keep AURELIA separate from Project 2 and all older PWA work.
- Preserve exact financial rules: integer minor units, exact arithmetic, no cross-currency aggregation, same-currency transfers only until FX is separately designed, interest-free loans, no loan overpayment, savings goals do not mutate wallet balances.
- Do not claim a build or device test succeeded unless actually run and verified.

## Requested continuation

Before editing, inspect the entire existing project and summarize current screens, state, dependencies, and known limitations. Then apply the Phase 4.7 continuation to the existing project, preserving all previous Phase 4.6 work. Do not remove features to simplify the UI.

The next work should establish a coherent Pearl Light + Midnight Glass design system and improve usability: compact hierarchy, accessible touch targets, reusable inputs/pickers/sheets, keyboard-aware forms, clearer empty/loading/error states, and consistent navigation. The current product direction is premium liquid-glass-inspired UI, but do not claim true backdrop blur unless a supported implementation is present and verified on device. Do not replace the entire app with a static mockup.

After implementation, report exact files changed, features preserved, tests actually run, tests not run, build outcome, and remaining blockers. Do not fabricate results.

## Source-of-truth warning

Changes made in ChatGPT's separate working copy do not automatically synchronize to this AI Studio project. Apply only reviewed patches or the approved implementation prompt to AI Studio. Never assume GitHub is the AI Studio project state.
