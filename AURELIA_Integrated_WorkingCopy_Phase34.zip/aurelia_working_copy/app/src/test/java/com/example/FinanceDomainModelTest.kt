package com.example

import com.example.domain.mapper.summarizeByCurrency
import com.example.domain.model.Loan
import com.example.domain.model.LoanDirection
import com.example.domain.model.Wallet
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FinanceDomainModelTest {
  private fun wallet(id: String, currency: String, balance: Long) = Wallet(
    id = id, name = id, category = "Cash", currencyCode = currency,
    balanceMinorUnits = balance, colorHex = 0L, iconName = "wallet", isArchived = false,
  )

  @Test fun walletTotalsRemainSeparatedByCurrency() {
    val summaries = listOf(wallet("a", "BDT", 1000), wallet("b", "BDT", 2500), wallet("c", "USD", 500))
      .summarizeByCurrency()
    assertEquals(listOf("BDT", "USD"), summaries.map { it.currencyCode })
    assertEquals(3500L, summaries.first().totalBalanceMinorUnits)
    assertEquals(500L, summaries.last().totalBalanceMinorUnits)
  }

  @Test(expected = ArithmeticException::class)
  fun walletSummaryRejectsLongOverflow() {
    listOf(wallet("a", "BDT", Long.MAX_VALUE), wallet("b", "BDT", 1L)).summarizeByCurrency()
  }

  @Test fun loanOutstandingAndClosureAreExplicit() {
    val openLoan = Loan("l1", "p1", "Person", LoanDirection.LENT, 1000, 400, "BDT", 1L, null, "", false)
    val closedLoan = Loan("l2", "p1", "Person", LoanDirection.LENT, 1000, 1000, "BDT", 1L, null, "", false)
    assertEquals(600L, openLoan.outstandingMinorUnits)
    assertFalse(openLoan.isClosed)
    assertTrue(closedLoan.isClosed)
  }

  @Test(expected = IllegalArgumentException::class)
  fun loanRejectsOverpayment() {
    Loan("l1", "p1", "Person", LoanDirection.LENT, 1000, 1001, "BDT", 1L, null, "", false)
  }
}
