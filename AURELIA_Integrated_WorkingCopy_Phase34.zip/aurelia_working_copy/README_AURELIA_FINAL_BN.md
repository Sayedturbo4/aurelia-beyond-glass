# AURELIA — Redesign Working Copy (Phase 7)

এইটি আলাদা Android Kotlin + Jetpack Compose working copy। মূল Google AI Studio Phase 4.6 project অক্ষত থাকবে।

## Build

প্রজেক্টে `gradle-wrapper.properties` আছে, কিন্তু `gradlew` এবং `gradle-wrapper.jar` নেই। তাই Android Studio/CI-তে compatible Gradle 9.3.1 ও Android SDK 36 দিয়ে build environment প্রস্তুত করতে হবে। এরপর:

```bash
gradle --no-daemon clean :app:testDebugUnitTest :app:assembleDebug
```

## সতর্কতা

এই snapshot-এর পূর্ণ Android build ও real-device test এখনো সম্পন্ন হয়নি। এটি release-ready নয়। Debug keystore কখনো production release signing-এ ব্যবহার করবে না।

আরও বিস্তারিত: `AURELIA_FINAL_HANDOFF_STATUS_BN.md`, `AURELIA_COMPLETION_ROADMAP.md`, `AURELIA_BUILD_AUDIT.md`.
