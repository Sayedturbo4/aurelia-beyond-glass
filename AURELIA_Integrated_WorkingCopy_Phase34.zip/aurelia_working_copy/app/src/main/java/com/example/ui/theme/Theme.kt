package com.example.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Immutable
data class AureliaGlassColors(
  val bgCanvas: Color,
  val surfaceGlass: Color,
  val surfaceElevated: Color,
  val surfaceCrystal: Color,
  val borderFrosted: Color,
  val borderSpecular: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val textTertiary: Color,
  val auroraBlue: Color,
  val auroraLavender: Color,
  val auroraRose: Color,
  val auroraMint: Color,
  val financialIncome: Color,
  val financialExpense: Color,
  val isDark: Boolean,
)

val LocalAureliaColors = staticCompositionLocalOf {
  AureliaGlassColors(
    bgCanvas = PearlBgCanvas,
    surfaceGlass = PearlSurface,
    surfaceElevated = PearlSurfaceCloud,
    surfaceCrystal = PearlSurfaceCrystal,
    borderFrosted = PearlBorderSilver,
    borderSpecular = PearlBorderSpecular,
    textPrimary = PearlTextPrimary,
    textSecondary = PearlTextSecondary,
    textTertiary = PearlTextTertiary,
    auroraBlue = AuroraBlueLight,
    auroraLavender = AuroraLavenderLight,
    auroraRose = AuroraRoseLight,
    auroraMint = AuroraMintLight,
    financialIncome = FinancialIncomeLight,
    financialExpense = FinancialExpenseLight,
    isDark = false,
  )
}

private val AureliaLightColorScheme = lightColorScheme(
  primary = AuroraLavenderLight,
  onPrimary = PearlTextPrimary,
  secondary = AuroraBlueLight,
  onSecondary = PearlTextPrimary,
  tertiary = AuroraMintLight,
  background = PearlBgCanvas,
  surface = PearlSurface,
  onBackground = PearlTextPrimary,
  onSurface = PearlTextPrimary,
  surfaceVariant = PearlSurfaceCloud,
  onSurfaceVariant = PearlTextSecondary,
  outline = PearlBorderSilver,
)

private val AureliaDarkColorScheme = darkColorScheme(
  primary = AuroraLavenderDark,
  onPrimary = MidnightTextPrimary,
  secondary = AuroraBlueDark,
  onSecondary = MidnightTextPrimary,
  tertiary = AuroraMintDark,
  background = MidnightBgCanvas,
  surface = MidnightSurface,
  onBackground = MidnightTextPrimary,
  onSurface = MidnightTextPrimary,
  surfaceVariant = MidnightSurfaceElevated,
  onSurfaceVariant = MidnightTextSecondary,
  outline = MidnightBorderFrosted,
)

@Composable
fun AureliaTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val glassColors = if (darkTheme) {
    AureliaGlassColors(
      bgCanvas = MidnightBgCanvas,
      surfaceGlass = MidnightSurface,
      surfaceElevated = MidnightSurfaceElevated,
      surfaceCrystal = Color(0xFF1E2838),
      borderFrosted = MidnightBorderFrosted,
      borderSpecular = MidnightBorderSpecular,
      textPrimary = MidnightTextPrimary,
      textSecondary = MidnightTextSecondary,
      textTertiary = MidnightTextTertiary,
      auroraBlue = AuroraBlueDark,
      auroraLavender = AuroraLavenderDark,
      auroraRose = AuroraRoseDark,
      auroraMint = AuroraMintDark,
      financialIncome = FinancialIncomeDark,
      financialExpense = FinancialExpenseDark,
      isDark = true,
    )
  } else {
    AureliaGlassColors(
      bgCanvas = PearlBgCanvas,
      surfaceGlass = PearlSurface,
      surfaceElevated = PearlSurfaceCloud,
      surfaceCrystal = PearlSurfaceCrystal,
      borderFrosted = PearlBorderSilver,
      borderSpecular = PearlBorderSpecular,
      textPrimary = PearlTextPrimary,
      textSecondary = PearlTextSecondary,
      textTertiary = PearlTextTertiary,
      auroraBlue = AuroraBlueLight,
      auroraLavender = AuroraLavenderLight,
      auroraRose = AuroraRoseLight,
      auroraMint = AuroraMintLight,
      financialIncome = FinancialIncomeLight,
      financialExpense = FinancialExpenseLight,
      isDark = false,
    )
  }

  val colorScheme = if (darkTheme) AureliaDarkColorScheme else AureliaLightColorScheme

  CompositionLocalProvider(LocalAureliaColors provides glassColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = Typography,
      content = content,
    )
  }
}

object AureliaThemeTokens {
  val colors: AureliaGlassColors
    @Composable
    get() = LocalAureliaColors.current
}

/**
 * Spatial Glass Canvas Background
 * Renders subtle floating Aurora glow orbs in the background canvas,
 * allowing translucent glass surfaces to exhibit real optical refraction, depth,
 * and delicate color warmth, without blurring foreground text!
 */
@Composable
fun AureliaSpatialBackground(
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit,
) {
  val colors = AureliaThemeTokens.colors
  val isDark = colors.isDark

  Box(
    modifier = modifier
      .fillMaxSize()
      .drawBehind {
        // Base canvas background fill
        drawRect(colors.bgCanvas)

        if (isDark) {
          // Midnight Glass Ambient Atmosphere: Subtle glowing nebula orbs
          // Top-right Aurora Lavender glow
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFF2C1E45).copy(alpha = 0.55f), Color.Transparent),
              center = Offset(size.width * 0.88f, size.height * 0.10f),
              radius = size.width * 0.70f,
            ),
            radius = size.width * 0.70f,
            center = Offset(size.width * 0.88f, size.height * 0.10f),
          )
          // Top-left Aurora Blue glow
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFF162540).copy(alpha = 0.60f), Color.Transparent),
              center = Offset(size.width * 0.12f, size.height * 0.22f),
              radius = size.width * 0.65f,
            ),
            radius = size.width * 0.65f,
            center = Offset(size.width * 0.12f, size.height * 0.22f),
          )
          // Middle-right Aurora Rose glow
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFF381A2D).copy(alpha = 0.45f), Color.Transparent),
              center = Offset(size.width * 0.92f, size.height * 0.54f),
              radius = size.width * 0.50f,
            ),
            radius = size.width * 0.50f,
            center = Offset(size.width * 0.92f, size.height * 0.54f),
          )
          // Bottom-left Aurora Mint glow
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFF0F3028).copy(alpha = 0.45f), Color.Transparent),
              center = Offset(size.width * 0.15f, size.height * 0.82f),
              radius = size.width * 0.60f,
            ),
            radius = size.width * 0.60f,
            center = Offset(size.width * 0.15f, size.height * 0.82f),
          )
        } else {
          // Pearl Light Ambient Atmosphere: Soft luminous opalescent orbs
          // Top-right Aurora Lavender orb
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFFE8DEF8).copy(alpha = 0.65f), Color.Transparent),
              center = Offset(size.width * 0.88f, size.height * 0.08f),
              radius = size.width * 0.72f,
            ),
            radius = size.width * 0.72f,
            center = Offset(size.width * 0.88f, size.height * 0.08f),
          )
          // Top-left Aurora Blue orb
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFFDCE8FC).copy(alpha = 0.70f), Color.Transparent),
              center = Offset(size.width * 0.10f, size.height * 0.22f),
              radius = size.width * 0.65f,
            ),
            radius = size.width * 0.65f,
            center = Offset(size.width * 0.10f, size.height * 0.22f),
          )
          // Middle-right Aurora Rose orb
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFFFBE6F0).copy(alpha = 0.55f), Color.Transparent),
              center = Offset(size.width * 0.95f, size.height * 0.52f),
              radius = size.width * 0.55f,
            ),
            radius = size.width * 0.55f,
            center = Offset(size.width * 0.95f, size.height * 0.52f),
          )
          // Bottom-left Aurora Mint orb
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFFDEF4EC).copy(alpha = 0.60f), Color.Transparent),
              center = Offset(size.width * 0.15f, size.height * 0.80f),
              radius = size.width * 0.60f,
            ),
            radius = size.width * 0.60f,
            center = Offset(size.width * 0.15f, size.height * 0.80f),
          )
        }
      },
  ) {
    content()
  }
}
