from pathlib import Path
root = Path(__file__).parent
base = root / 'app/src/main/java/com/example'
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

dao = (base/'data/local/FinanceDao.kt').read_text()
repo = (base/'data/local/FinanceLocalRepository.kt').read_text()
vm = (base/'ui/viewmodel/FinanceOverviewViewModel.kt').read_text()
check('DAO wallet restore query is state-guarded', 'isArchived = 1' in dao and 'restoreById' in dao)
check('DAO person archive query is state-guarded', 'isArchived = 0' in dao and 'archiveById' in dao)
check('Person update validates and preserves creation timestamp', 'suspend fun updatePerson' in repo and 'createdAtMillis = existing.createdAtMillis' in repo)
check('Person archive blocks unsettled loans atomically', 'database.withTransaction' in repo and 'countOpenForPerson(personId) == 0' in repo)
check('Wallet restore requires archived zero-balance wallet', 'wallet.isArchived' in repo and 'wallet.balanceMinorUnits == 0L' in repo)
check('Savings contribution uses exact addition', 'MoneyEngine.addExact(goal.savedMinorUnits, amountMinorUnits)' in repo)
check('Savings contribution is tracking-only', 'Tracking-only contribution' in repo)
check('ViewModel exposes all lifecycle APIs', all(x in vm for x in ['fun restoreWallet(', 'fun updatePerson(', 'fun archivePerson(', 'fun contributeToSavingsGoal(']))
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' ' + name)
print(f'{sum(ok for _, ok in checks)}/{len(checks)} checks passed')
if not all(ok for _, ok in checks):
    raise SystemExit(1)
