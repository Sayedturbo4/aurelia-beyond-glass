# AURELIA — Development Progress Report

**Latest checkpoint:** Phase 21 — GitHub Actions Cloud Debug Build Configuration  
**Date:** 2026-11-03  
**Project:** AURELIA — Beyond Glass  
**Working copy:** Separate from the original Google AI Studio project

## Phase 21 — Build Configuration Prepared

### Added

1. `.github/workflows/android-debug.yml`
   - Runs on pushes and pull requests to `main` / `master`, and supports manual `workflow_dispatch`.
   - Uses Ubuntu GitHub-hosted runner and Temurin JDK 21.
   - Installs Android SDK platform 36, build-tools 36.0.0 and platform-tools.
   - Downloads the project's configured Gradle 9.3.1 distribution directly because the source ZIP has no Gradle wrapper scripts/JAR.
   - Runs `clean`, `:app:testDebugUnitTest`, and `:app:assembleDebug`.
   - Uploads the Debug APK and test report as workflow artifacts.
   - Creates a temporary conventional debug keystore if the ignored local file is not present.
2. `AURELIA_CLOUD_BUILD_GUIDE_BN.md` with Android-phone-only GitHub setup and artifact retrieval instructions.
3. Updated `.gitignore` to keep local secrets, signing keys, build outputs, and Google Services config out of source control.
4. README cloud-build entry.

### Static checks performed in this environment

- Project XML files parsed successfully.
- Gradle version catalog TOML parsed successfully.
- GitHub Actions workflow YAML parsed successfully with the available YAML parser.
- Pure Kotlin compilation passed for the core financial/domain/report/CSV source set:
  - `MoneyEngine.kt`
  - `LoanAccountingPolicy.kt`
  - `FinanceModels.kt`
  - `BudgetProgress.kt`
  - `FinanceReports.kt`
  - `FinanceCsvExporter.kt`

### Not yet verified

- The GitHub Actions workflow has not been run because the repository is not connected or uploaded from this chat.
- Full AGP/Kotlin/Compose/Room/KSP compilation is not yet verified.
- Unit tests, APK assembly, installation and real-device behaviour remain pending.
- The Android SDK package set may need adjustment if the requested compileSdk 36 minor API level 1 is not provided by the runner's installed platform package; use the actual CI error before changing project compileSdk.
- The workflow builds Debug only. Release signing and Play Store AAB are deliberately out of scope until a separate release-key and signing-secret setup is agreed.

## What the user needs to do next

1. Create a **private** GitHub repository, for example `aurelia-beyond-glass`.
2. Extract this ZIP on the Android phone.
3. Upload the extracted project contents to the repository root, including the hidden `.github/workflows/android-debug.yml` directory.
4. Do not upload `.env`, `google-services.json` if it later contains project configuration, or any production signing key/password.
5. Open the repository's **Actions** tab and manually run `AURELIA Android Debug Build`.
6. If the build fails, share the first complete Gradle error block or upload the build log. Fix the real compiler error before continuing feature work.
7. If successful, download the `aurelia-debug-apk-*` artifact from the workflow run.

## Integrity boundaries

- No changes were made to the original AI Studio project.
- No online backend, authentication, cloud sync, or realtime messaging was enabled.
- No production signing key or secret was added.
- This phase prepares the CI pipeline; it does not claim a successful APK build.
