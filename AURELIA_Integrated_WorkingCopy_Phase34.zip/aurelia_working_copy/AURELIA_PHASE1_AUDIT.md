# AURELIA Phase 1 — Baseline Source & UX Audit

**Source archive:** `AURELIA_Phase21.zip`  
**Archive integrity:** extracted successfully; 124 entries.  
**Application source:** 8,330 Kotlin lines across main sources (as counted in the extracted archive).  
**Scope:** static source review and supplied screen recording. No source implementation changes have been made in this audit step.

## Verified project structure

- Single Android application module (`app`).
- Kotlin + Jetpack Compose UI.
- Room database with People, Wallets, Loans, Transactions, Budgets, Savings Goals and App Metadata entities.
- Repository and ViewModel layers exist.
- Money engine, loan accounting policy, reports, CSV/PDF export code and unit tests exist.
- Main screens: Home, Activity, Wallets, More, People, Planning, Reports, Quick Add.
- No KMP/iOS module in this archive.

## Critical findings

| ID | Severity | Finding | Required action |
|---|---|---|---|
| UX-01 | P0 | Quick Add is one conditional multi-purpose form with many fields and horizontal selection rails. | Split into short contextual flows; stable IDs; keyboard-aware sheet. |
| UX-02 | P0 | First-run demo seed imports fake people, wallets and loans into a fresh DB. | Replace with explicit optional sample mode and onboarding; no silent fake financial data. |
| UX-03 | P0 | Quick Add falls back to demo wallets if Room wallet list is empty. | Remove production fallback; block submission until a real wallet exists and guide Create Wallet. |
| UX-04 | P1 | More screen duplicates Budgets/Reports under active and future roadmap sections. | One authoritative feature availability map; remove contradictory duplication. |
| UX-05 | P1 | People & Loans screen is dense and summary uses BDT-only aggregate values. | Group totals by currency; separate person detail, loan lifecycle and repayment history. |
| UX-06 | P1 | Theme surfaces use gradients, alpha fills, border and sheen but no actual backdrop blur. | Add supported backdrop blur/fallback only after device/API and performance review. |
| UX-07 | P1 | Font family is default; requested Plus Jakarta Sans/Hind Siliguri are not assigned. | Bundle fonts and implement locale-aware font family + tabular amount typography. |
| UX-08 | P1 | Manual navigation state in MainActivity has limited previous-destination behavior. | Introduce predictable navigation state/back stack without changing product IA. |
| UX-09 | P1 | Activity DAO lacks transaction update/delete APIs in inspected DAO. | Define safe edit/delete/undo/audit policy and repository operations. |
| UX-10 | P1 | Loan repayment is associated with a loan only in a free-text transaction note. | Add structured repayment entity or loanId relation with Room migration. |
| UX-11 | P1 | No audit-log entity/table in current Room schema. | Add append-only audit model and migration. |
| UX-12 | P1 | Wallet DAO lacks full edit/archive API. | Define wallet edit/archive constraints and repository support. |
| UX-13 | P2 | Quick Add uses selected indices for wallet/person/loan selection. | Persist stable IDs and recover selection safely when lists change. |
| UX-14 | P2 | Reports UI is dense and empty state is generic. | Improve scope summary, empty guidance, trend and breakdown hierarchy. |
| UX-15 | P2 | Build includes Firebase/Retrofit/OkHttp dependencies despite offline-only current phase. | Dependency usage audit; remove only after build/reference verification. |

## Financial and data integrity notes

- Existing money engine documents integer minor-unit storage and exact arithmetic. Preserve it.
- Repository operations use Room `withTransaction` for cash posting, same-currency transfer, loan opening and repayment flows in the inspected source.
- Savings goal updates are tracking-only and do not mutate wallet balances; preserve this rule.
- Cross-currency transfers are explicitly rejected in the current repository. Do not silently expand them.
- Loan repayment transaction records do not have a structured loan foreign key; free-text note matching is fragile.
- Room schema is version 2 with migration 1→2. New schema work requires explicit migration and migration tests; no destructive migration.
- Demo data is imported only if the DB is empty and marker absent, but this still creates fictional financial records on first launch. That is not acceptable as the default user-facing experience.

## Visual review notes from screen recording

- The overall result appears as a set of tinted cards with gradients and borders, not a coherent layered glass material system.
- More page has repeated feature groupings and mixed active/future availability.
- Reports screen presents many controls before meaningful data and needs clearer hierarchy.
- People & Loans screen has a high-density balance summary and contact list.
- A black transition frame is visible once; it requires reproduction before attributing it to app code.
- The video cannot prove persistence, accounting correctness, or whether every tap target works. Those require a scripted device test.

## Tooling / verification status

- `kotlinc` is present in the working environment; Java 21 is present.
- No system `gradle` executable was found during this inspection.
- The Phase 21 archive includes `gradle-wrapper.properties` but does not include `gradlew`, `gradlew.bat` or `gradle-wrapper.jar` (confirmed from the ZIP inventory in the earlier archive audit).
- No Android SDK is configured in this working environment.
- Therefore no full Android build, Compose compilation, Room/KSP generation or physical-device test is claimed here.

## Phase 1 outcome

- Exact baseline extracted to a separate working copy.
- Master redesign specification created.
- Evidence-based UX and source audit created.
- No change made to the original Google AI Studio project or user's GitHub repository.
- No app source file changed yet; implementation begins in Phase 2 (Design System Foundation) after the baseline is documented.
