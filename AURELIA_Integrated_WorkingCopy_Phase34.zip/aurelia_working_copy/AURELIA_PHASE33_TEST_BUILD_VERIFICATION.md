# AURELIA Phase 33 — Automated Testing & Android Build Verification

## Delivered
- Added an offline structural preflight script covering the Android module, key finance/security/export test suites, and required CI steps.
- GitHub Actions now runs source preflight, Kotlin debug compilation, the complete `testDebugUnitTest` task, and debug APK assembly.
- CI publishes the APK plus a SHA-256 checksum and build metadata; unit-test HTML reports remain available as a separate artifact.
- Existing project unit tests are retained; no feature modules or test files were removed.

## Local verification in this workspace
- `python3 AURELIA_PHASE33_CHECKS.py`: 16/16 passed.
- Gradle/Android build was **not run locally**: this workspace has no Gradle executable, no `gradlew` script/JAR, and no configured Android SDK.
- The workflow is the authoritative environment for Kotlin compilation, JUnit execution, and APK assembly. A successful YAML/source preflight is not a substitute for a successful CI build.

## Important build caveat
The repository currently contains `gradle-wrapper.properties` but does not contain the Gradle wrapper launcher or wrapper JAR. CI installs Gradle directly, so the GitHub Actions workflow does not depend on the wrapper. Local Android Studio/AI Studio builds may still need a generated wrapper or installed Gradle distribution.

## Device verification still required
Install the final CI APK on a physical Android device and verify onboarding persistence, theme and balance-visibility persistence, Room database creation/migrations, transaction/transfer/loan flows, backup/restore, biometric availability, screenshots/secure-window behavior, and both light/dark rendering. Do not treat this phase as device-tested.
