# AURELIA Phase 7 — Wallet Management Safety & Lifecycle

## Implemented in this phase
- Added a repository-level `archiveWallet` operation executed inside a Room transaction.
- Wallet archival is allowed only when the wallet exists, is active, and has an exact zero balance.
- Archival preserves wallet and transaction rows; historical records are not deleted.
- Added DAO soft-archive update and ViewModel action boundary.
- Added an explicit confirmation dialog in Wallet Details and visible failure feedback.

## Safety decisions
- Non-zero wallets cannot be archived. The user must first reconcile/transfer the remaining balance.
- No wallet hard-delete operation was introduced.
- Existing wallet currency and historical transaction amounts are not rewritten.

## Verification
- Source-level checks: passed (DAO method, transactional guard, zero-balance rule, ViewModel boundary, confirmation UI, no hard delete).
- ZIP integrity: checked after packaging.
- Android Gradle compilation, Room/KSP compilation, Compose compilation, JUnit execution, and device rendering: NOT RUN in this environment. Do not treat this phase as build-verified.

## Known remaining wallet work
- Wallet edit flow is not yet implemented.
- Wallet detail transaction history and per-wallet income/expense aggregates need implementation.
- Archived wallet browsing/unarchive workflow needs implementation and policy review.
- The current Wallet screen still contains a currency pager; redesign to a compact searchable currency filter remains pending.
