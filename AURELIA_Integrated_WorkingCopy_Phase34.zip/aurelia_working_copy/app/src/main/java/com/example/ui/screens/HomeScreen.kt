package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PeopleAlt
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataProvider
import com.example.data.TransactionType
import com.example.domain.model.FinanceTransaction
import com.example.domain.model.FinanceTransactionType
import com.example.domain.model.Loan
import com.example.domain.model.Wallet
import com.example.ui.components.AureliaGlassSurface
import com.example.ui.components.AureliaSectionHeader
import com.example.ui.components.AureliaSurfaceTone
import com.example.ui.design.AureliaRadii
import com.example.ui.design.AureliaSpacing
import com.example.ui.design.AureliaTouch
import com.example.ui.theme.AureliaThemeTokens
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Home dashboard redesign. Currency totals are always isolated by currency; no FX conversion
 * or cross-currency aggregation is performed here. Recent transaction values are shown as
 * individual ledger entries, not treated as a complete-period income/expense summary.
 */
@Composable
fun HomeScreen(
  isBalanceVisible: Boolean,
  onToggleBalanceVisibility: () -> Unit,
  isDarkTheme: Boolean,
  onToggleTheme: () -> Unit,
  onOpenQuickAdd: (TransactionType) -> Unit,
  onViewAllWallets: () -> Unit,
  onViewAllActivity: () -> Unit,
  onNavigateToPeople: () -> Unit,
  onNavigateToPlanning: () -> Unit,
  wallets: List<Wallet>,
  transactions: List<FinanceTransaction>,
  loans: List<Loan>,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  val activeWallets = remember(wallets) { wallets.filterNot { it.isArchived } }
  val availableCurrencies = remember(activeWallets) {
    activeWallets.map { it.currencyCode }.distinct().sorted().let { codes ->
      if (codes.contains("BDT")) listOf("BDT") + codes.filterNot { it == "BDT" } else codes
    }
  }
  var selectedCurrency by rememberSaveable { mutableStateOf("BDT") }
  var currencyMenuExpanded by remember { mutableStateOf(false) }
  val effectiveCurrency = when {
    availableCurrencies.isEmpty() -> "BDT"
    selectedCurrency in availableCurrencies -> selectedCurrency
    else -> availableCurrencies.first()
  }
  val currencyWallets = remember(activeWallets, effectiveCurrency) {
    activeWallets.filter { it.currencyCode == effectiveCurrency }
  }
  val currencyTotal = remember(currencyWallets) {
    currencyWallets.fold(0L) { total, wallet -> Math.addExact(total, wallet.balanceMinorUnits) }
  }
  val currencyTransactions = remember(transactions, effectiveCurrency) {
    transactions.filter { it.currencyCode == effectiveCurrency }.take(4)
  }

  LazyColumn(
    modifier = modifier.fillMaxSize().padding(horizontal = AureliaSpacing.lg),
    contentPadding = androidx.compose.foundation.layout.PaddingValues(
      top = AureliaSpacing.md,
      bottom = 112.dp,
    ),
    verticalArrangement = Arrangement.spacedBy(AureliaSpacing.xl),
  ) {
    item(key = "home_header") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("AURELIA", color = colors.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
          Text("Your overview", color = colors.textPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
          Text("A clearer view of your money", color = colors.textSecondary, fontSize = 13.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onToggleBalanceVisibility,
            modifier = Modifier.size(AureliaTouch.iconTarget).testTag("toggle_balance_privacy"),
          ) {
            Icon(
              imageVector = if (isBalanceVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
              contentDescription = if (isBalanceVisible) "Hide balances" else "Show balances",
              tint = colors.textSecondary,
            )
          }
          IconButton(
            onClick = onToggleTheme,
            modifier = Modifier.size(AureliaTouch.iconTarget).testTag("toggle_app_theme"),
          ) {
            Icon(
              imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
              contentDescription = "Toggle appearance",
              tint = colors.auroraLavender,
            )
          }
        }
      }
    }

    item(key = "balance_overview") {
      AureliaGlassSurface(
        modifier = Modifier.fillMaxWidth().testTag("home_balance_overview"),
        shape = AureliaRadii.hero,
        tone = AureliaSurfaceTone.Accent,
        contentPadding = AureliaSpacing.xl,
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(AureliaSpacing.lg)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Text("TOTAL BALANCE", color = colors.textSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
              Text("Across one currency", color = colors.textSecondary, fontSize = 12.sp)
            }
            Box {
              Surface(
                onClick = { currencyMenuExpanded = true },
                shape = AureliaRadii.pill,
                color = colors.surfaceElevated.copy(alpha = 0.72f),
                contentColor = colors.textPrimary,
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Text(effectiveCurrency, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Icon(Icons.Default.ArrowForward, contentDescription = "Choose currency", modifier = Modifier.size(13.dp))
                }
              }
              DropdownMenu(expanded = currencyMenuExpanded, onDismissRequest = { currencyMenuExpanded = false }) {
                availableCurrencies.forEach { code ->
                  DropdownMenuItem(
                    text = { Text(code, fontWeight = if (code == effectiveCurrency) FontWeight.Bold else FontWeight.Normal) },
                    onClick = { selectedCurrency = code; currencyMenuExpanded = false },
                  )
                }
              }
            }
          }

          AnimatedContent(
            targetState = currencyTotal,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "home_balance_change",
          ) { amount ->
            Text(
              text = DemoDataProvider.formatMoney(amount, effectiveCurrency, isBalanceVisible),
              color = colors.textPrimary,
              fontSize = 32.sp,
              lineHeight = 38.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = (-0.7).sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = colors.auroraBlue, modifier = Modifier.size(16.dp))
            Text(
              text = "${currencyWallets.size} active ${if (currencyWallets.size == 1) "wallet" else "wallets"}",
              color = colors.textSecondary,
              fontSize = 12.sp,
            )
            Text("·", color = colors.textSecondary)
            Text("${activeWallets.size} total", color = colors.textSecondary, fontSize = 12.sp)
          }

          Row(horizontalArrangement = Arrangement.spacedBy(AureliaSpacing.sm), modifier = Modifier.fillMaxWidth()) {
            HomeQuickAction(
              label = "Income", icon = Icons.Default.ArrowDownward,
              tint = colors.financialIncome,
              modifier = Modifier.weight(1f),
              onClick = { onOpenQuickAdd(TransactionType.INCOME) },
            )
            HomeQuickAction(
              label = "Expense", icon = Icons.Default.ArrowUpward,
              tint = colors.financialExpense,
              modifier = Modifier.weight(1f),
              onClick = { onOpenQuickAdd(TransactionType.EXPENSE) },
            )
            HomeQuickAction(
              label = "Transfer", icon = Icons.Default.SwapHoriz,
              tint = colors.auroraLavender,
              modifier = Modifier.weight(1f),
              onClick = { onOpenQuickAdd(TransactionType.TRANSFER) },
            )
          }
        }
      }
    }

    item(key = "wallets_section_header") {
      AureliaSectionHeader(
        title = "Your wallets",
        supportingText = if (currencyWallets.isEmpty()) "Keep your accounts organised" else "$effectiveCurrency · ${currencyWallets.size} active",
        actionLabel = "See all",
        onAction = onViewAllWallets,
      )
    }

    if (currencyWallets.isEmpty()) {
      item(key = "wallets_empty") {
        AureliaGlassSurface(modifier = Modifier.fillMaxWidth(), tone = AureliaSurfaceTone.Subtle) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("No $effectiveCurrency wallets yet", color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
            Text("Add a wallet to start tracking money in this currency.", color = colors.textSecondary, fontSize = 13.sp)
            Text("Open Wallets →", color = colors.auroraLavender, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onViewAllWallets).padding(top = 4.dp))
          }
        }
      }
    } else {
      items(currencyWallets.take(2), key = { "wallet_${it.id}" }) { wallet ->
        AureliaGlassSurface(
          modifier = Modifier.fillMaxWidth().clickable(onClick = onViewAllWallets),
          tone = AureliaSurfaceTone.Subtle,
          shape = AureliaRadii.compact,
          contentPadding = AureliaSpacing.md,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(wallet.colorHex).copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center,
              ) {
                Text(wallet.category.take(1).uppercase(), color = Color(wallet.colorHex), fontWeight = FontWeight.Bold)
              }
              Spacer(Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(wallet.name, color = colors.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(wallet.category, color = colors.textSecondary, fontSize = 12.sp)
              }
            }
            Text(
              DemoDataProvider.formatMoney(wallet.balanceMinorUnits, wallet.currencyCode, isBalanceVisible),
              color = colors.textPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
            )
          }
        }
      }
      if (currencyWallets.size > 2) {
        item(key = "wallets_more") {
          Text("+ ${currencyWallets.size - 2} more wallets", color = colors.auroraLavender, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onViewAllWallets).padding(vertical = 2.dp))
        }
      }
    }

    item(key = "people_shortcut") {
      AureliaGlassSurface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onNavigateToPeople),
        tone = AureliaSurfaceTone.Accent,
        shape = AureliaRadii.compact,
        contentPadding = AureliaSpacing.lg,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Box(modifier = Modifier.size(42.dp).clip(CircleShape).background(colors.auroraLavender.copy(alpha = 0.20f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PeopleAlt, contentDescription = null, tint = colors.auroraLavender)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("People & loans", color = colors.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Track money lent, borrowed and repaid", color = colors.textSecondary, fontSize = 12.sp)
          }
          Icon(Icons.Default.ArrowForward, contentDescription = "Open people and loans", tint = colors.textSecondary)
        }
      }
    }

    item(key = "planning_summary") {
      val outstandingLoans = remember(loans, effectiveCurrency) {
        loans.filter { !it.isArchived && !it.isClosed && it.currencyCode == effectiveCurrency }
      }
      val lentMinor = remember(outstandingLoans) {
        outstandingLoans.filter { it.direction == com.example.domain.model.LoanDirection.LENT }
          .fold(0L) { total, loan -> Math.addExact(total, loan.outstandingMinorUnits) }
      }
      val borrowedMinor = remember(outstandingLoans) {
        outstandingLoans.filter { it.direction == com.example.domain.model.LoanDirection.BORROWED }
          .fold(0L) { total, loan -> Math.addExact(total, loan.outstandingMinorUnits) }
      }
      AureliaSectionHeader(
        title = "Financial planning",
        supportingText = "Loans and money goals",
        actionLabel = "Open",
        onAction = onNavigateToPlanning,
      )
      AureliaGlassSurface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onNavigateToPlanning),
        tone = AureliaSurfaceTone.Subtle,
        shape = AureliaRadii.compact,
        contentPadding = AureliaSpacing.lg,
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Outstanding loans", color = colors.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("${outstandingLoans.size} active", color = colors.textSecondary, fontSize = 11.sp)
          }
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
              Text("To receive", color = colors.textSecondary, fontSize = 11.sp)
              Text(DemoDataProvider.formatMoney(lentMinor, effectiveCurrency, isBalanceVisible), color = colors.financialIncome, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Column(modifier = Modifier.weight(1f)) {
              Text("To repay", color = colors.textSecondary, fontSize = 11.sp)
              Text(DemoDataProvider.formatMoney(borrowedMinor, effectiveCurrency, isBalanceVisible), color = colors.financialExpense, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
          }
        }
      }
    }

    item(key = "recent_header") {
      AureliaSectionHeader(
        title = "Recent activity",
        supportingText = "Your latest recorded transactions",
        actionLabel = "View all",
        onAction = onViewAllActivity,
      )
    }

    if (currencyTransactions.isEmpty()) {
      item(key = "activity_empty") {
        AureliaGlassSurface(modifier = Modifier.fillMaxWidth(), tone = AureliaSurfaceTone.Subtle) {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Nothing here yet", color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
            Text("Transactions in $effectiveCurrency will appear here when you add them.", color = colors.textSecondary, fontSize = 13.sp)
          }
        }
      }
    } else {
      items(currencyTransactions, key = { "tx_${it.id}" }) { tx ->
        RecentTransactionRow(
          transaction = tx,
          wallet = wallets.firstOrNull { it.id == tx.walletId },
          isBalanceVisible = isBalanceVisible,
        )
      }
    }
  }
}

@Composable
private fun HomeQuickAction(
  label: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  tint: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  val colors = AureliaThemeTokens.colors
  Surface(
    onClick = onClick,
    modifier = modifier.height(58.dp).testTag("home_action_${label.lowercase()}"),
    shape = RoundedCornerShape(17.dp),
    color = colors.surfaceElevated.copy(alpha = 0.68f),
    contentColor = colors.textPrimary,
    tonalElevation = 0.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(vertical = 7.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
      Spacer(Modifier.height(3.dp))
      Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
  }
}

@Composable
private fun RecentTransactionRow(
  transaction: FinanceTransaction,
  wallet: Wallet?,
  isBalanceVisible: Boolean,
) {
  val colors = AureliaThemeTokens.colors
  val (icon, tint, prefix) = when (transaction.type) {
    FinanceTransactionType.INCOME -> Triple(Icons.Default.ArrowDownward, colors.financialIncome, "+")
    FinanceTransactionType.EXPENSE -> Triple(Icons.Default.ArrowUpward, colors.financialExpense, "−")
    FinanceTransactionType.TRANSFER -> Triple(Icons.Default.SwapHoriz, colors.auroraLavender, "⇄ ")
    FinanceTransactionType.PEOPLE, FinanceTransactionType.UNKNOWN -> Triple(Icons.Default.PeopleAlt, colors.auroraBlue, "")
  }
  AureliaGlassSurface(
    modifier = Modifier.fillMaxWidth(),
    tone = AureliaSurfaceTone.Subtle,
    shape = AureliaRadii.compact,
    contentPadding = AureliaSpacing.md,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
      Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(tint.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
          Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(transaction.title, color = colors.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
          val date = remember(transaction.occurredAtMillis) {
            SimpleDateFormat("dd MMM · hh:mm a", Locale.getDefault()).format(Date(transaction.occurredAtMillis))
          }
          Text(
            text = "${transaction.categoryId.replace('_', ' ')} · ${wallet?.name ?: "Wallet"} · $date",
            color = colors.textSecondary,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
      Spacer(Modifier.width(8.dp))
      Text(
        text = "$prefix${DemoDataProvider.formatMoney(transaction.amountMinorUnits, transaction.currencyCode, isBalanceVisible)}",
        color = tint,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
      )
    }
  }
}
