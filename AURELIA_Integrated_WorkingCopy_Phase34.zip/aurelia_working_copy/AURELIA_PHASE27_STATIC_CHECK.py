from pathlib import Path
root = Path('app/src/main/java/com/example')
checks = {
    'report model carries void state': 'val isVoided: Boolean = false' in (root/'domain/report/FinanceReports.kt').read_text(),
    'calculator excludes voided rows': '!row.isVoided && (row.type == "INCOME" || row.type == "EXPENSE")' in (root/'domain/report/FinanceReports.kt').read_text(),
    'screen passes void state': 'isVoided = row.isVoided' in (root/'ui/screens/ReportsScreen.kt').read_text(),
    'csv manager excludes voided rows': '!row.isVoided && (row.type == "INCOME" || row.type == "EXPENSE")' in (root/'export/FinanceExportManager.kt').read_text(),
    'both csv entry points exclude voided rows': (root/'ui/screens/ReportsScreen.kt').read_text().count('!it.isVoided && it.occurredAtMillis') == 2,
    'viewmodel projections pass void state': (root/'ui/viewmodel/FinanceOverviewViewModel.kt').read_text().count('isVoided = row.isVoided') >= 2,
    'regression test added': 'voidedTransactionsAreExcludedFromEveryReportTotal' in Path('app/src/test/java/com/example/domain/report/FinanceReportCalculatorTest.kt').read_text(),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
print(f'{len(checks)}/{len(checks)} checks passed')
