package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** Local-first finance database. No network or cloud dependency is used here. */
@Database(
  entities = [
    PersonEntity::class,
    WalletEntity::class,
    LoanEntity::class,
    TransactionEntity::class,
    BudgetEntity::class,
    SavingsGoalEntity::class,
    AppMetadataEntity::class,
  ],
  version = 2,
  exportSchema = false,
)
abstract class AureliaDatabase : RoomDatabase() {
  abstract fun personDao(): PersonDao
  abstract fun walletDao(): WalletDao
  abstract fun loanDao(): LoanDao
  abstract fun transactionDao(): TransactionDao
  abstract fun budgetDao(): BudgetDao
  abstract fun savingsGoalDao(): SavingsGoalDao
  abstract fun appMetadataDao(): AppMetadataDao

  companion object {
    /** Adds metadata without touching existing finance records. */
    private val MIGRATION_1_2 = object : Migration(1, 2) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_metadata (`key` TEXT NOT NULL, `value` TEXT NOT NULL, updatedAtMillis INTEGER NOT NULL, PRIMARY KEY(`key`))")
      }
    }

    @Volatile private var INSTANCE: AureliaDatabase? = null

    fun getInstance(context: Context): AureliaDatabase =
      INSTANCE ?: synchronized(this) {
        INSTANCE ?: Room.databaseBuilder(
          context.applicationContext,
          AureliaDatabase::class.java,
          "aurelia_local.db",
        ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
      }
  }
}
