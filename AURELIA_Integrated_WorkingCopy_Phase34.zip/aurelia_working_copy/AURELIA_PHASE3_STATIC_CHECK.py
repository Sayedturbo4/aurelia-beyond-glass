from pathlib import Path
p = Path('app/src/main/java/com/example/ui/screens/HomeScreen.kt')
s = p.read_text()
checks = {
    'old currency pager removed': 'HorizontalPager' not in s and 'rememberPagerState' not in s,
    'old duplicate currency chips removed': 'Supported Currencies (13)' not in s,
    'hardcoded personal greeting removed': 'Good morning, Rahim' not in s,
    'balance privacy retained': 'toggle_balance_privacy' in s,
    'theme toggle retained': 'toggle_app_theme' in s,
    'income action wired': 'TransactionType.INCOME' in s,
    'expense action wired': 'TransactionType.EXPENSE' in s,
    'transfer action wired': 'TransactionType.TRANSFER' in s,
    'currency isolation retained': 'it.currencyCode == effectiveCurrency' in s,
    'loan outstanding summary present': 'loan.outstandingMinorUnits' in s,
    'planning navigation wired': 'onNavigateToPlanning' in s,
    'recent activity present': 'Recent activity' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
# Lightweight delimiter count (not a substitute for Kotlin compilation).
for token, opening, closing in [('brace', '{', '}'), ('paren', '(', ')')]:
    if s.count(opening) != s.count(closing):
        raise SystemExit(f'FAIL: unbalanced {token}: {s.count(opening)} {opening}, {s.count(closing)} {closing}')
print('PASS: lightweight delimiter count')
