# AURELIA Phase 23 — Transaction Lifecycle Safety

## Implemented
- Added `isVoided` to transaction persistence with Room migration 2→3; existing rows default to active.
- Transaction list queries now exclude voided rows while retaining them in the database.
- Added atomic edit support for INCOME/EXPENSE transactions. The old wallet effect is reversed and the new effect is applied inside one Room transaction; any validation failure rolls back both.
- Added atomic soft-void support for INCOME/EXPENSE and same-currency TRANSFER transactions. The original row remains stored and is hidden from active ledger queries.
- Transfer void restores source amount plus fee and debits the destination by the original transfer amount.
- Added ViewModel entry points for edit and void operations.
- PEOPLE/loan transactions and FX transfers are explicitly rejected by generic reversal APIs; they require loan-specific or FX-specific lifecycle handling rather than unsafe generic balance edits.

## Safety constraints
- Cash edit supports only INCOME/EXPENSE, validates positive amount, currency format, wallet currency, and available balance.
- Income reversal is rejected if the wallet no longer contains sufficient funds to undo it.
- Transfer reversal is rejected if the destination wallet has already spent the transferred funds.
- All wallet updates and transaction state changes execute inside a single Room transaction.

## Verification
- Existing Phase 20 static checks: 8/8 passed.
- Existing Phase 21 static checks: 8/8 passed.
- Existing Phase 3 static checks: 13/13 passed.
- ZIP integrity verified after packaging.
- Full Android/Room KSP/Compose compilation and on-device testing have NOT been run in this environment. The project still needs a cloud Android build and device QA.

## Not yet complete
- Activity UI actions for edit/void and confirmation screens are not yet wired to these new APIs.
- Dedicated loan repayment reversal and FX transfer reversal remain intentionally unsupported until their ledger/accounting rules are implemented and tested.
