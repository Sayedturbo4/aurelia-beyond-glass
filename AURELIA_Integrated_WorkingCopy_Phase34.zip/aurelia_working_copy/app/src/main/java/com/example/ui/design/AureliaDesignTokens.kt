package com.example.ui.design

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/** Central layout tokens. Keep screen-specific values out of composables. */
object AureliaSpacing {
    val xxs = 2.dp
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 20.dp
    val xxl = 24.dp
    val xxxl = 32.dp
    val screenHorizontal = 20.dp
    val sectionGap = 24.dp
    val compactSectionGap = 16.dp
    val listItemGap = 10.dp
    val inlineGap = 6.dp
    val contentMaxWidth = 640.dp
}

object AureliaRadii {
    val control = RoundedCornerShape(14.dp)
    val compact = RoundedCornerShape(18.dp)
    val card = RoundedCornerShape(24.dp)
    val hero = RoundedCornerShape(30.dp)
    val sheet = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    val pill = RoundedCornerShape(50)
    val input = RoundedCornerShape(16.dp)
    val bottomDock = RoundedCornerShape(28.dp)
}

object AureliaTouch {
    val minimumTarget = 48.dp
    val iconTarget = 48.dp
    val primaryButtonHeight = 54.dp
    val compactButtonHeight = 44.dp
    val minimumIconSize = 20.dp
}

object AureliaMotion {
    const val quickMillis = 140
    const val standardMillis = 220
    const val emphasisMillis = 320
    const val entranceMillis = 260
}
