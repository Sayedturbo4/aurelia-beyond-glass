package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
  @Query("SELECT * FROM people") suspend fun exportAll(): List<PersonEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<PersonEntity>): List<Long>
  @Query("SELECT * FROM people WHERE isArchived = 0 ORDER BY name COLLATE NOCASE ASC")
  fun observeAll(): Flow<List<PersonEntity>>

  @Query("SELECT * FROM people WHERE isArchived = 1 ORDER BY updatedAtMillis DESC")
  fun observeArchived(): Flow<List<PersonEntity>>

  @Query("UPDATE people SET isArchived = 0, updatedAtMillis = :updatedAt WHERE id = :id AND isArchived = 1")
  suspend fun restoreById(id: String, updatedAt: Long): Int

  @Query("SELECT * FROM people WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): PersonEntity?

  @Query("SELECT COUNT(*) FROM people")
  suspend fun countAll(): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(person: PersonEntity)

  @Update
  suspend fun update(person: PersonEntity)

  @Query("UPDATE people SET isArchived = 1, updatedAtMillis = :updatedAt WHERE id = :id AND isArchived = 0")
  suspend fun archiveById(id: String, updatedAt: Long): Int
}

@Dao
interface WalletDao {
  @Query("SELECT * FROM wallets") suspend fun exportAll(): List<WalletEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<WalletEntity>): List<Long>
  @Query("SELECT * FROM wallets WHERE isArchived = 0 ORDER BY name COLLATE NOCASE ASC")
  fun observeActive(): Flow<List<WalletEntity>>

  @Query("SELECT * FROM wallets WHERE isArchived = 1 ORDER BY updatedAtMillis DESC")
  fun observeArchived(): Flow<List<WalletEntity>>

  @Query("SELECT * FROM wallets WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): WalletEntity?

  @Query("SELECT COUNT(*) FROM wallets")
  suspend fun countAll(): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(wallet: WalletEntity)

  @Update
  suspend fun update(wallet: WalletEntity)

  @Query("UPDATE wallets SET balanceMinorUnits = :newBalance, updatedAtMillis = :updatedAt WHERE id = :walletId")
  suspend fun updateBalance(walletId: String, newBalance: Long, updatedAt: Long): Int

  @Query("UPDATE wallets SET isArchived = 1, updatedAtMillis = :updatedAt WHERE id = :walletId AND isArchived = 0")
  suspend fun archiveById(walletId: String, updatedAt: Long): Int

  @Query("UPDATE wallets SET isArchived = 0, updatedAtMillis = :updatedAt WHERE id = :walletId AND isArchived = 1")
  suspend fun restoreById(walletId: String, updatedAt: Long): Int
}

@Dao
interface LoanDao {
  @Query("SELECT * FROM loans") suspend fun exportAll(): List<LoanEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<LoanEntity>): List<Long>
  @Query("SELECT * FROM loans WHERE isArchived = 0 ORDER BY openedAtMillis DESC")
  fun observeActive(): Flow<List<LoanEntity>>

  @Query("SELECT * FROM loans WHERE personId = :personId AND isArchived = 0 ORDER BY openedAtMillis DESC")
  fun observeForPerson(personId: String): Flow<List<LoanEntity>>

  @Query("SELECT * FROM loans WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): LoanEntity?

  @Query("SELECT COUNT(*) FROM loans WHERE personId = :personId AND isArchived = 0 AND repaidMinorUnits < principalMinorUnits")
  suspend fun countOpenForPerson(personId: String): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(loan: LoanEntity)

  @Update
  suspend fun update(loan: LoanEntity)
}

@Dao
interface TransactionDao {
  @Query("SELECT * FROM transactions") suspend fun exportAll(): List<TransactionEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<TransactionEntity>): List<Long>
  @Query("SELECT * FROM transactions WHERE isVoided = 0 ORDER BY occurredAtMillis DESC LIMIT :limit")
  fun observeLatest(limit: Int = 100): Flow<List<TransactionEntity>>

  @Query("SELECT * FROM transactions WHERE isVoided = 0 ORDER BY occurredAtMillis DESC")
  fun observeAll(): Flow<List<TransactionEntity>>

  @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): TransactionEntity?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(transaction: TransactionEntity)

  @Update
  suspend fun update(transaction: TransactionEntity)

  @Query("UPDATE transactions SET isVoided = 1, updatedAtMillis = :updatedAt WHERE id = :id AND isVoided = 0")
  suspend fun markVoided(id: String, updatedAt: Long): Int

  @Query("SELECT * FROM transactions WHERE isVoided = 0 AND occurredAtMillis >= :fromMillis AND occurredAtMillis < :untilMillis ORDER BY occurredAtMillis DESC")
  fun observeBetween(fromMillis: Long, untilMillis: Long): Flow<List<TransactionEntity>>
}

@Dao
interface BudgetDao {
  @Query("SELECT * FROM budgets") suspend fun exportAll(): List<BudgetEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<BudgetEntity>): List<Long>
  @Query("SELECT * FROM budgets ORDER BY periodStartMillis DESC, categoryId ASC")
  fun observeAll(): Flow<List<BudgetEntity>>

  @Query("SELECT * FROM budgets WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): BudgetEntity?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(budget: BudgetEntity)

  @Update
  suspend fun update(budget: BudgetEntity)

  @Query("DELETE FROM budgets WHERE id = :id")
  suspend fun deleteById(id: String): Int
}

@Dao
interface SavingsGoalDao {
  @Query("SELECT * FROM savings_goals") suspend fun exportAll(): List<SavingsGoalEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<SavingsGoalEntity>): List<Long>
  @Query("SELECT * FROM savings_goals ORDER BY isCompleted ASC, updatedAtMillis DESC")
  fun observeAll(): Flow<List<SavingsGoalEntity>>

  @Query("SELECT * FROM savings_goals WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): SavingsGoalEntity?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(goal: SavingsGoalEntity)

  @Update
  suspend fun update(goal: SavingsGoalEntity)

  @Query("DELETE FROM savings_goals WHERE id = :id")
  suspend fun deleteById(id: String): Int
}


@Dao
interface SavingsContributionDao {
  @Query("SELECT * FROM savings_contributions") suspend fun exportAll(): List<SavingsContributionEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<SavingsContributionEntity>): List<Long>
  @Query("SELECT * FROM savings_contributions ORDER BY occurredAtMillis DESC")
  fun observeAll(): Flow<List<SavingsContributionEntity>>

  @Query("SELECT * FROM savings_contributions WHERE goalId = :goalId ORDER BY occurredAtMillis DESC")
  fun observeForGoal(goalId: String): Flow<List<SavingsContributionEntity>>

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(row: SavingsContributionEntity)

  @Query("DELETE FROM savings_contributions WHERE goalId = :goalId")
  suspend fun deleteForGoal(goalId: String): Int
}

@Dao
interface AppMetadataDao {
  @Query("SELECT * FROM app_metadata") suspend fun exportAll(): List<AppMetadataEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<AppMetadataEntity>): List<Long>
  @Query("SELECT value FROM app_metadata WHERE `key` = :key LIMIT 1")
  suspend fun getValue(key: String): String?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun put(metadata: AppMetadataEntity)
}


@Dao
interface CategoryDao {
  @Query("SELECT * FROM categories") suspend fun exportAll(): List<CategoryEntity>
  @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun importIgnore(rows: List<CategoryEntity>): List<Long>
  @Query("SELECT * FROM categories WHERE isArchived = 0 AND type = :type ORDER BY isSystem DESC, name COLLATE NOCASE ASC")
  fun observeActive(type: String): Flow<List<CategoryEntity>>

  @Query("SELECT * FROM categories WHERE isArchived = 1 ORDER BY updatedAtMillis DESC")
  fun observeArchived(): Flow<List<CategoryEntity>>

  @Query("SELECT * FROM categories WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): CategoryEntity?

  @Query("SELECT COUNT(*) FROM transactions WHERE categoryId = :categoryId AND isVoided = 0")
  suspend fun countActiveTransactionReferences(categoryId: String): Int

  @Query("SELECT COUNT(*) FROM budgets WHERE categoryId = :categoryId")
  suspend fun countBudgetReferences(categoryId: String): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(category: CategoryEntity)

  @Update
  suspend fun update(category: CategoryEntity)

  @Query("UPDATE categories SET isArchived = 1, updatedAtMillis = :updatedAt WHERE id = :id AND isArchived = 0")
  suspend fun archive(id: String, updatedAt: Long): Int

  @Query("UPDATE categories SET isArchived = 0, updatedAtMillis = :updatedAt WHERE id = :id AND isArchived = 1")
  suspend fun restore(id: String, updatedAt: Long): Int
}
