package com.example.domain.report

import java.util.Calendar
import java.util.TimeZone

/** Half-open report interval: fromInclusiveMillis <= timestamp < untilExclusiveMillis. */
data class ReportDateRange(
  val fromInclusiveMillis: Long,
  val untilExclusiveMillis: Long,
) {
  init {
    require(fromInclusiveMillis < untilExclusiveMillis) { "Report date range is invalid" }
  }
}

data class ReportTransaction(
  val id: String,
  val type: String,
  val amountMinorUnits: Long,
  val currencyCode: String,
  val categoryId: String,
  val walletId: String,
  val occurredAtMillis: Long,
  val isVoided: Boolean = false,
)

data class CurrencyReportSummary(
  val currencyCode: String,
  val incomeMinorUnits: Long,
  val expenseMinorUnits: Long,
  val netMinorUnits: Long,
  val incomeCount: Int,
  val expenseCount: Int,
)

data class CategoryExpenseSummary(
  val currencyCode: String,
  val categoryId: String,
  val expenseMinorUnits: Long,
  val transactionCount: Int,
)

data class WalletActivitySummary(
  val currencyCode: String,
  val walletId: String,
  val walletName: String,
  val incomeMinorUnits: Long,
  val expenseMinorUnits: Long,
  val netMinorUnits: Long,
)

data class FinanceReport(
  val range: ReportDateRange,
  val currencySummaries: List<CurrencyReportSummary>,
  val categoryExpenses: List<CategoryExpenseSummary>,
  val walletSummaries: List<WalletActivitySummary>,
  val includedTransactionCount: Int,
)

/** Pure report calculator. Transfers and PEOPLE/loan ledger entries are intentionally excluded. */
object FinanceReportCalculator {
  fun calculate(
    transactions: List<ReportTransaction>,
    walletNamesById: Map<String, String>,
    range: ReportDateRange,
  ): FinanceReport {
    val included = transactions.filter { row ->
      row.occurredAtMillis >= range.fromInclusiveMillis &&
        row.occurredAtMillis < range.untilExclusiveMillis &&
        !row.isVoided && (row.type == "INCOME" || row.type == "EXPENSE")
    }
    included.forEach { row ->
      require(row.amountMinorUnits > 0L) { "Report transactions must have positive amounts" }
      require(row.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid transaction currency" }
      require(row.id.isNotBlank() && row.walletId.isNotBlank()) { "Invalid transaction reference" }
    }

    val currencies = included.groupBy { it.currencyCode }.map { (currency, rows) ->
      var income = 0L
      var expense = 0L
      var incomeCount = 0
      var expenseCount = 0
      rows.forEach { row ->
        when (row.type) {
          "INCOME" -> {
            income = Math.addExact(income, row.amountMinorUnits)
            incomeCount = Math.addExact(incomeCount, 1)
          }
          "EXPENSE" -> {
            expense = Math.addExact(expense, row.amountMinorUnits)
            expenseCount = Math.addExact(expenseCount, 1)
          }
        }
      }
      CurrencyReportSummary(
        currencyCode = currency,
        incomeMinorUnits = income,
        expenseMinorUnits = expense,
        netMinorUnits = Math.subtractExact(income, expense),
        incomeCount = incomeCount,
        expenseCount = expenseCount,
      )
    }.sortedBy { it.currencyCode }

    val categories = included.asSequence()
      .filter { it.type == "EXPENSE" }
      .groupBy { it.currencyCode to it.categoryId }
      .map { (key, rows) ->
        CategoryExpenseSummary(
          currencyCode = key.first,
          categoryId = key.second,
          expenseMinorUnits = rows.fold(0L) { total, row -> Math.addExact(total, row.amountMinorUnits) },
          transactionCount = rows.size,
        )
      }
      .sortedWith(compareBy<CategoryExpenseSummary> { it.currencyCode }.thenByDescending { it.expenseMinorUnits })

    val walletSummaries = included.groupBy { it.currencyCode to it.walletId }
      .map { (key, rows) ->
        var income = 0L
        var expense = 0L
        rows.forEach { row ->
          when (row.type) {
            "INCOME" -> income = Math.addExact(income, row.amountMinorUnits)
            "EXPENSE" -> expense = Math.addExact(expense, row.amountMinorUnits)
          }
        }
        WalletActivitySummary(
          currencyCode = key.first,
          walletId = key.second,
          walletName = walletNamesById[key.second] ?: "Unknown wallet",
          incomeMinorUnits = income,
          expenseMinorUnits = expense,
          netMinorUnits = Math.subtractExact(income, expense),
        )
      }
      .sortedWith(compareBy<WalletActivitySummary> { it.currencyCode }.thenBy { it.walletName.lowercase() })

    return FinanceReport(
      range = range,
      currencySummaries = currencies,
      categoryExpenses = categories,
      walletSummaries = walletSummaries,
      includedTransactionCount = included.size,
    )
  }

  /** Returns the current local day in the supplied timezone, using a half-open interval. */
  fun currentDayRange(nowMillis: Long, timeZone: TimeZone = TimeZone.getDefault()): ReportDateRange {
    val start = Calendar.getInstance(timeZone).apply {
      timeInMillis = nowMillis
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    val end = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
    return ReportDateRange(start.timeInMillis, end.timeInMillis)
  }

  /** ISO-style week starting Monday, represented in the supplied local timezone. */
  fun currentWeekRange(nowMillis: Long, timeZone: TimeZone = TimeZone.getDefault()): ReportDateRange {
    val start = Calendar.getInstance(timeZone).apply {
      timeInMillis = nowMillis
      val daysSinceMonday = (get(Calendar.DAY_OF_WEEK) + 5) % 7
      add(Calendar.DAY_OF_MONTH, -daysSinceMonday)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    val end = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 7) }
    return ReportDateRange(start.timeInMillis, end.timeInMillis)
  }

  /** Returns the current calendar month in the supplied timezone, using a half-open interval. */
  fun currentMonthRange(nowMillis: Long, timeZone: TimeZone = TimeZone.getDefault()): ReportDateRange {
    val start = Calendar.getInstance(timeZone).apply {
      timeInMillis = nowMillis
      set(Calendar.DAY_OF_MONTH, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    val end = (start.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
    return ReportDateRange(start.timeInMillis, end.timeInMillis)
  }

  /** Returns the current calendar year in the supplied timezone, using a half-open interval. */
  fun currentYearRange(nowMillis: Long, timeZone: TimeZone = TimeZone.getDefault()): ReportDateRange {
    val start = Calendar.getInstance(timeZone).apply {
      timeInMillis = nowMillis
      set(Calendar.MONTH, Calendar.JANUARY)
      set(Calendar.DAY_OF_MONTH, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    val end = (start.clone() as Calendar).apply { add(Calendar.YEAR, 1) }
    return ReportDateRange(start.timeInMillis, end.timeInMillis)
  }
}
