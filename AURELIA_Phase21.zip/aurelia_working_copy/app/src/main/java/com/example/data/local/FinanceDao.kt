package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
  @Query("SELECT * FROM people WHERE isArchived = 0 ORDER BY name COLLATE NOCASE ASC")
  fun observeAll(): Flow<List<PersonEntity>>

  @Query("SELECT * FROM people WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): PersonEntity?

  @Query("SELECT COUNT(*) FROM people")
  suspend fun countAll(): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(person: PersonEntity)

  @Update
  suspend fun update(person: PersonEntity)

  @Query("UPDATE people SET isArchived = 1, updatedAtMillis = :updatedAt WHERE id = :id")
  suspend fun archiveById(id: String, updatedAt: Long): Int
}

@Dao
interface WalletDao {
  @Query("SELECT * FROM wallets WHERE isArchived = 0 ORDER BY name COLLATE NOCASE ASC")
  fun observeActive(): Flow<List<WalletEntity>>

  @Query("SELECT * FROM wallets WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): WalletEntity?

  @Query("SELECT COUNT(*) FROM wallets")
  suspend fun countAll(): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(wallet: WalletEntity)

  @Update
  suspend fun update(wallet: WalletEntity)

  @Query("UPDATE wallets SET balanceMinorUnits = :newBalance, updatedAtMillis = :updatedAt WHERE id = :walletId")
  suspend fun updateBalance(walletId: String, newBalance: Long, updatedAt: Long): Int
}

@Dao
interface LoanDao {
  @Query("SELECT * FROM loans WHERE isArchived = 0 ORDER BY openedAtMillis DESC")
  fun observeActive(): Flow<List<LoanEntity>>

  @Query("SELECT * FROM loans WHERE personId = :personId AND isArchived = 0 ORDER BY openedAtMillis DESC")
  fun observeForPerson(personId: String): Flow<List<LoanEntity>>

  @Query("SELECT * FROM loans WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): LoanEntity?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(loan: LoanEntity)

  @Update
  suspend fun update(loan: LoanEntity)
}

@Dao
interface TransactionDao {
  @Query("SELECT * FROM transactions ORDER BY occurredAtMillis DESC LIMIT :limit")
  fun observeLatest(limit: Int = 100): Flow<List<TransactionEntity>>

  @Query("SELECT * FROM transactions ORDER BY occurredAtMillis DESC")
  fun observeAll(): Flow<List<TransactionEntity>>

  @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): TransactionEntity?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(transaction: TransactionEntity)

  @Query("SELECT * FROM transactions WHERE occurredAtMillis >= :fromMillis AND occurredAtMillis < :untilMillis ORDER BY occurredAtMillis DESC")
  fun observeBetween(fromMillis: Long, untilMillis: Long): Flow<List<TransactionEntity>>
}

@Dao
interface BudgetDao {
  @Query("SELECT * FROM budgets ORDER BY periodStartMillis DESC, categoryId ASC")
  fun observeAll(): Flow<List<BudgetEntity>>

  @Query("SELECT * FROM budgets WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): BudgetEntity?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(budget: BudgetEntity)

  @Update
  suspend fun update(budget: BudgetEntity)

  @Query("DELETE FROM budgets WHERE id = :id")
  suspend fun deleteById(id: String): Int
}

@Dao
interface SavingsGoalDao {
  @Query("SELECT * FROM savings_goals ORDER BY isCompleted ASC, updatedAtMillis DESC")
  fun observeAll(): Flow<List<SavingsGoalEntity>>

  @Query("SELECT * FROM savings_goals WHERE id = :id LIMIT 1")
  suspend fun findById(id: String): SavingsGoalEntity?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insert(goal: SavingsGoalEntity)

  @Update
  suspend fun update(goal: SavingsGoalEntity)

  @Query("DELETE FROM savings_goals WHERE id = :id")
  suspend fun deleteById(id: String): Int
}


@Dao
interface AppMetadataDao {
  @Query("SELECT value FROM app_metadata WHERE `key` = :key LIMIT 1")
  suspend fun getValue(key: String): String?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun put(metadata: AppMetadataEntity)
}
