package com.example.data

/** Pure accounting rule for opening a zero-interest peer-to-peer loan. */
object LoanAccountingPolicy {
    fun walletBalanceAfterOpening(
        walletBalanceMinorUnits: Long,
        principalMinorUnits: Long,
        loanType: String,
    ): Long {
        MoneyEngine.validatePositive(principalMinorUnits)
        return when (loanType) {
            "LENT" -> {
                require(walletBalanceMinorUnits >= principalMinorUnits) {
                    "Insufficient wallet balance to lend this amount"
                }
                MoneyEngine.subtractExact(walletBalanceMinorUnits, principalMinorUnits)
            }
            "BORROWED" -> MoneyEngine.addExact(walletBalanceMinorUnits, principalMinorUnits)
            else -> throw IllegalArgumentException("Unsupported loan type")
        }
    }
}
