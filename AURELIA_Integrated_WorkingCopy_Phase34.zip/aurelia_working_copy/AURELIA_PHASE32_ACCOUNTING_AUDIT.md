# AURELIA Phase 32 — Financial Accounting & Database Audit

## Scope
Reviewed the exact Phase 31 working copy: integer minor-unit money engine, wallet posting/reversal, same-currency transfers, loan opening/repayment, savings tracking, Room entities/DAOs, schema version and migrations 1→5.

## Changes applied
1. Cash income/expense posting and editing now require a non-empty category ID.
2. Cash posting/editing rejects transfer-only fee and FX snapshot metadata, preventing a cash ledger row from carrying a second transaction model's fields.
3. Editing a cash transaction into an archived wallet is rejected.
4. A newly opened loan must start with zero repayments. Opening posts the full principal to the wallet and creates the opening ledger row; accepting a pre-populated repaid amount would otherwise make the loan outstanding amount disagree with the opening cash effect. Repayments must be recorded through the atomic repayment operation.
5. Transfer posting now requires a non-empty category ID.

## Verified invariants in source
- Monetary storage is `Long` minor units; parsing/formatting/arithmetic avoid Float/Double.
- Exact arithmetic uses overflow-checked operations; transfer calculations use `BigInteger` for formatting and `Math.addExact/subtractExact` for balance mutations.
- Currency scale rules: JPY 0, KWD 3, default 2.
- Cash posting, transfer posting, transaction void/edit, loan opening and loan repayment use `RoomDatabase.withTransaction` for atomic wallet/ledger updates.
- Cross-currency transfers are explicitly rejected; no implicit FX conversion.
- Transfer fees debit the source wallet; transfer reversal restores amount plus fee and is guarded against unsafe FX reversal or already-spent destination funds.
- Savings contributions are tracking-only and do not change wallet balances.
- Voided transactions are excluded from normal transaction observation queries.
- Room schema is version 5 with explicit migrations 1→2, 2→3, 3→4 and 4→5.

## Remaining risks / not yet verified
- Room entities do not declare SQL `CHECK` constraints. Repository validation is the primary guard; direct DAO/import paths must remain restricted and validated.
- No migration execution against real version-1/2/3/4 database fixtures was run in this environment.
- No property-based or instrumented SQLite concurrency tests were run.
- Loan reversal/void lifecycle remains intentionally unsupported; PEOPLE rows are rejected by the cash/transfer void operation.
- FX transfers remain unsupported by design.
- Android Gradle compilation and device testing were not run: this working environment does not have a verified Android SDK/Gradle wrapper setup.

## Result
Phase 32 source audit and targeted guard fixes are complete. This is a source-level accounting audit, not a certified accounting review or a successful Android build claim.
