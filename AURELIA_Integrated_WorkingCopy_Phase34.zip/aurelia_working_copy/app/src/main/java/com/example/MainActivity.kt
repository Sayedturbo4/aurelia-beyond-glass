package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.data.TransactionType
import com.example.data.backup.FinanceBackupManager
import com.example.data.local.AureliaDatabase
import com.example.ui.components.AureliaBottomNavBar
import com.example.ui.components.AureliaNavDestination
import com.example.ui.screens.ActivityScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.MoreScreen
import com.example.ui.screens.PeopleScreen
import com.example.ui.screens.PlanningScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.QuickAddSheet
import com.example.ui.screens.WalletsScreen
import com.example.ui.viewmodel.FinanceOverviewViewModel
import com.example.ui.theme.AureliaSpatialBackground
import com.example.ui.theme.AureliaTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      AureliaAppRoot()
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AureliaAppRoot() {
  val context = LocalContext.current
  val appPreferences = remember(context) { context.getSharedPreferences("aurelia_user_preferences", android.content.Context.MODE_PRIVATE) }
  var isDarkTheme by remember { mutableStateOf(appPreferences.getBoolean("dark_theme", false)) }
  var isBalanceVisible by remember { mutableStateOf(appPreferences.getBoolean("balance_visible", true)) }
  var hasCompletedOnboarding by remember { mutableStateOf(appPreferences.getBoolean("onboarding_completed", false)) }
  LaunchedEffect(isDarkTheme) { appPreferences.edit().putBoolean("dark_theme", isDarkTheme).apply() }
  LaunchedEffect(isBalanceVisible) { appPreferences.edit().putBoolean("balance_visible", isBalanceVisible).apply() }
  var currentDestination by remember { mutableStateOf(AureliaNavDestination.HOME) }
  var previousDestination by remember { mutableStateOf(AureliaNavDestination.HOME) }
  var isQuickAddOpen by remember { mutableStateOf(false) }
  var quickAddInitialType by remember { mutableStateOf(TransactionType.EXPENSE) }

  val financeViewModel: FinanceOverviewViewModel = viewModel()
  val dashboardWallets by financeViewModel.domainWallets.collectAsState()
  val dashboardTransactions by financeViewModel.domainTransactions.collectAsState()
  val dashboardLoans by financeViewModel.domainLoans.collectAsState()
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  val backupManager = remember(context) { FinanceBackupManager(AureliaDatabase.getInstance(context)) }
  var pendingBackupJson by remember { mutableStateOf<String?>(null) }
  var backupDialogMessage by remember { mutableStateOf<String?>(null) }
  val exportBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
    if (uri != null) {
      scope.launch {
        runCatching {
          val json = backupManager.exportJson()
          context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            ?: error("Unable to open the selected backup destination")
        }.onSuccess { snackbarHostState.showSnackbar("AURELIA backup exported successfully") }
          .onFailure { snackbarHostState.showSnackbar("Backup export failed: ${it.message ?: "Unknown error"}") }
      }
    }
  }
  val importBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
    if (uri != null) {
      runCatching {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
          ?: error("Unable to read selected backup")
        require(bytes.size <= 25 * 1024 * 1024) { "Backup file exceeds the 25 MiB safety limit" }
        bytes.toString(Charsets.UTF_8)
      }.onSuccess { json ->
        runCatching { backupManager.preview(json) }
          .onSuccess { preview -> pendingBackupJson = json; backupDialogMessage = "Backup preview\nPeople: ${preview.people}\nWallets: ${preview.wallets}\nLoans: ${preview.loans}\nTransactions: ${preview.transactions}\nBudgets: ${preview.budgets}\nSavings goals: ${preview.savingsGoals}\nContributions: ${preview.savingsContributions}\nCategories: ${preview.categories}\n\nContinue with safe merge? Existing records will not be overwritten." }
          .onFailure { backupDialogMessage = "Backup validation failed: ${it.message ?: "Invalid backup"}" }
      }.onFailure { backupDialogMessage = "Unable to read backup: ${it.message ?: "Unknown error"}" }
    }
  }

  // Back handling: if on People, return to previous; otherwise if not Home, return to Home
  if (currentDestination != AureliaNavDestination.HOME) {
    BackHandler {
      currentDestination = if (currentDestination == AureliaNavDestination.PEOPLE || currentDestination == AureliaNavDestination.PLANNING || currentDestination == AureliaNavDestination.REPORTS || currentDestination == AureliaNavDestination.CATEGORIES) {
        previousDestination
      } else {
        AureliaNavDestination.HOME
      }
    }
  }

  AureliaTheme(darkTheme = isDarkTheme) {
    if (!hasCompletedOnboarding) {
      OnboardingScreen(
        isDarkTheme = isDarkTheme,
        onToggleTheme = { isDarkTheme = !isDarkTheme },
        onComplete = {
          appPreferences.edit().putBoolean("onboarding_completed", true).apply()
          hasCompletedOnboarding = true
        },
      )
    } else {
      AureliaSpatialBackground {
        Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent, // Let spatial background shine through
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
          AureliaBottomNavBar(
            currentDestination = currentDestination,
            onNavigate = { destination ->
              if (destination == AureliaNavDestination.ADD) {
                quickAddInitialType = TransactionType.EXPENSE
                isQuickAddOpen = true
              } else {
                previousDestination = currentDestination
                currentDestination = destination
              }
            },
          )
        },
      ) { innerPadding ->
        Box(
          modifier = Modifier.fillMaxSize(),
        ) {
          AnimatedContent(
            targetState = currentDestination,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "nav_screen_transition",
          ) { destination ->
            when (destination) {
              AureliaNavDestination.HOME -> {
                HomeScreen(
                  isBalanceVisible = isBalanceVisible,
                  onToggleBalanceVisibility = { isBalanceVisible = !isBalanceVisible },
                  isDarkTheme = isDarkTheme,
                  onToggleTheme = { isDarkTheme = !isDarkTheme },
                  onOpenQuickAdd = { type ->
                    quickAddInitialType = type
                    isQuickAddOpen = true
                  },
                  onViewAllWallets = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.WALLETS
                  },
                  onViewAllActivity = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.ACTIVITY
                  },
                  onNavigateToPeople = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.PEOPLE
                  },
                  onNavigateToPlanning = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.PLANNING
                  },
                  wallets = dashboardWallets,
                  transactions = dashboardTransactions,
                  loans = dashboardLoans,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.ACTIVITY -> {
                ActivityScreen(
                  isBalanceVisible = isBalanceVisible,
                  viewModel = financeViewModel,
                  onOpenQuickAdd = { type ->
                    quickAddInitialType = type
                    isQuickAddOpen = true
                  },
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.WALLETS -> {
                WalletsScreen(
                  isBalanceVisible = isBalanceVisible,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.MORE -> {
                MoreScreen(
                  isDarkTheme = isDarkTheme,
                  onToggleTheme = { isDarkTheme = !isDarkTheme },
                  onNavigateToPeople = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.PEOPLE
                  },
                  onNavigateToPlanning = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.PLANNING
                  },
                  onNavigateToReports = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.REPORTS
                  },
                  onNavigateToCategories = {
                    previousDestination = currentDestination
                    currentDestination = AureliaNavDestination.CATEGORIES
                  },
                  onExportBackup = { exportBackupLauncher.launch("aurelia-backup-${System.currentTimeMillis()}.json") },
                  onImportBackup = { importBackupLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) },
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.PEOPLE -> {
                PeopleScreen(
                  viewModel = financeViewModel,
                  isBalanceVisible = isBalanceVisible,
                  onNavigateBack = {
                    currentDestination = previousDestination
                  },
                  onOpenQuickAddWithPeople = {
                    quickAddInitialType = TransactionType.PEOPLE
                    isQuickAddOpen = true
                  },
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.PLANNING -> {
                PlanningScreen(
                  viewModel = financeViewModel,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.REPORTS -> {
                ReportsScreen(
                  viewModel = financeViewModel,
                  modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
                )
              }

              AureliaNavDestination.CATEGORIES -> {
                CategoriesScreen(viewModel = financeViewModel, modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding()))
              }

              AureliaNavDestination.ADD -> {
                // Handled by modal bottom sheet
              }
            }
          }

          if (backupDialogMessage != null) {
            AlertDialog(
              onDismissRequest = { backupDialogMessage = null; pendingBackupJson = null },
              title = { Text(if (pendingBackupJson != null) "Review Backup" else "Backup Information") },
              text = { Text(backupDialogMessage.orEmpty()) },
              confirmButton = {
                if (pendingBackupJson != null) TextButton(onClick = {
                  val json = pendingBackupJson
                  pendingBackupJson = null
                  backupDialogMessage = null
                  if (json != null) scope.launch {
                    runCatching { backupManager.restoreMerge(json) }
                      .onSuccess { result -> snackbarHostState.showSnackbar("Restore complete. Added: ${result.inserted.values.sum()}, skipped existing: ${result.skippedDuplicates.values.sum()}") }
                      .onFailure { snackbarHostState.showSnackbar("Restore failed: ${it.message ?: "Unknown error"}") }
                  }
                }) { Text("Merge Restore") }
              },
              dismissButton = { TextButton(onClick = { backupDialogMessage = null; pendingBackupJson = null }) { Text("Cancel") } },
            )
          }

          // Quick Add Modal Bottom Sheet
          if (isQuickAddOpen) {
            QuickAddSheet(
              sheetState = sheetState,
              initialType = quickAddInitialType,
              onDismiss = { isQuickAddOpen = false },
              onSuccess = { msg ->
                scope.launch {
                  snackbarHostState.showSnackbar(msg)
                }
              },
              viewModel = financeViewModel,
            )
          }
        }
      }
    }
      }
    }
  }
}
