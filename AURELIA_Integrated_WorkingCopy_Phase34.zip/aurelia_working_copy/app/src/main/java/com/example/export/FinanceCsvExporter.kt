package com.example.export

/** Pure CSV encoder with spreadsheet-formula injection mitigation. */
object FinanceCsvExporter {
  fun encode(rows: List<List<String>>): String = rows.joinToString(separator = "\r\n") { row ->
    row.joinToString(",") { value -> escapeCell(value) }
  } + "\r\n"

  fun escapeCell(raw: String): String {
    val normalized = raw.replace("\u0000", "")
    val firstMeaningful = normalized.dropWhile { it == ' ' || it == '\t' || it == '\r' || it == '\n' }.firstOrNull()
    val safe = if (firstMeaningful in setOf('=', '+', '-', '@')) "'$normalized" else normalized
    return "\"${safe.replace("\"", "\"\"")}\""
  }
}
