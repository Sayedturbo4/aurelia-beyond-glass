package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AureliaThemeTokens

private data class OnboardingPage(
  val icon: ImageVector,
  val title: String,
  val description: String,
)

@Composable
fun OnboardingScreen(
  isDarkTheme: Boolean,
  onToggleTheme: () -> Unit,
  onComplete: () -> Unit,
) {
  val pages = remember {
    listOf(
      OnboardingPage(
        Icons.Rounded.AutoAwesome,
        "Welcome to AURELIA",
        "A calmer, clearer place to understand and manage your personal finances.",
      ),
      OnboardingPage(
        Icons.Rounded.AccountBalanceWallet,
        "Your money, organized",
        "Track wallets, income, expenses, transfers, budgets, savings and interest-free loans in one place.",
      ),
      OnboardingPage(
        Icons.Rounded.Security,
        "Private by design",
        "Your financial records stay on this device. Export a backup only when you choose to.",
      ),
    )
  }
  var pageIndex by remember { mutableIntStateOf(0) }
  val colors = AureliaThemeTokens.colors
  val page = pages[pageIndex]

  Box(
    modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 20.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(onClick = onToggleTheme) {
          Text(if (isDarkTheme) "Midnight Glass" else "Pearl Light")
        }
      }
      Spacer(Modifier.height(24.dp))
      Surface(
        modifier = Modifier.size(116.dp),
        shape = RoundedCornerShape(36.dp),
        color = colors.surfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.borderFrosted),
        shadowElevation = 12.dp,
      ) {
        Box(contentAlignment = Alignment.Center) {
          AnimatedContent(
            targetState = page.icon,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "onboarding_icon",
          ) { icon ->
            Icon(icon, contentDescription = null, tint = colors.auroraLavender, modifier = Modifier.size(54.dp))
          }
        }
      }
      Spacer(Modifier.height(36.dp))
      AnimatedContent(
        targetState = page,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "onboarding_content",
      ) { current ->
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            current.title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            color = colors.textPrimary,
          )
          Spacer(Modifier.height(14.dp))
          Text(
            current.description,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = colors.textSecondary,
          )
        }
      }
      Spacer(Modifier.height(32.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        pages.indices.forEach { index ->
          Surface(
            modifier = Modifier.size(if (index == pageIndex) 22.dp else 8.dp, 8.dp),
            shape = RoundedCornerShape(50),
            color = if (index == pageIndex) colors.auroraLavender else colors.borderFrosted,
          ) {}
        }
      }
      Spacer(Modifier.height(36.dp))
      Button(onClick = { if (pageIndex == pages.lastIndex) onComplete() else pageIndex++ }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
        Text(if (pageIndex == pages.lastIndex) "Get started" else "Continue")
      }
      if (pageIndex > 0) {
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { pageIndex-- }, modifier = Modifier.fillMaxWidth()) { Text("Back") }
      } else {
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onComplete) { Text("Skip introduction") }
      }
    }
  }
}
