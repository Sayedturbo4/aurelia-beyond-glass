# AURELIA Phase 30 — Onboarding & Global UX

## Implemented
- Added a first-run, three-step Compose onboarding experience: product introduction, financial feature overview, and local-data/privacy explanation.
- Added Skip, Back, Continue, and Get started actions.
- Added an onboarding-completed preference so the introduction is shown once and does not appear on every launch.
- Persisted Pearl Light / Midnight Glass selection across process restarts.
- Persisted balance-visibility preference across process restarts.
- Kept the existing finance screens, repositories, database, and backup flows in place.

## Files changed
- `app/src/main/java/com/example/MainActivity.kt`
- `app/src/main/java/com/example/ui/screens/OnboardingScreen.kt` (new)

## Verification
- Source-level checks: import/reference checks, onboarding gate and completion persistence, theme and balance preference persistence, navigation content retained, and ZIP integrity.
- Full Android/Compose compilation and runtime/device testing were not run in this environment because Gradle/Android SDK build execution is unavailable here.

## Notes
- Preferences use Android SharedPreferences; no new network or cloud dependency was added.
- Onboarding text describes the current offline/local-first product direction. It does not claim that biometric app-lock is fully integrated; that remains a separate pending task.
