# AURELIA Phase 6 — Quick Add Flow Refinement

## Scope
This phase makes targeted usability and state-safety improvements to the existing Room-backed Quick Add flow. It does not claim a full visual redesign or full Android build verification.

## Changes
- Reset the selected loan index when the user changes the selected person. This prevents a stale index from silently selecting a different person's loan when the new person's open-loan list has a different ordering/length.
- Changed the generic single-line “Note / Purpose / Due Date” field into an explicitly optional, multiline note field.
- Limited notes to 500 characters at input time to keep local records bounded and avoid unbounded free-text entry.
- Kept Room-backed writes and existing MoneyEngine positive-amount parsing/validation.
- Kept same-currency-only wallet transfers and repayment currency/outstanding checks.

## Preserved
- Existing transaction, wallet, people, loan and repository APIs.
- Existing database schema and financial engine.
- AI Studio original project is not modified by this working-copy change.

## Verification
- Source inspection confirms selected-person changes reset loan selection.
- Source inspection confirms note input is optional, multiline and capped at 500 characters.
- ZIP integrity checked after packaging.
- Full Android compilation, unit-test execution and device interaction testing are NOT claimed; this environment does not currently provide a verified Android SDK/Gradle build for this copy.

## Remaining Quick Add work
- Split the current mixed form into contextual flows/screens while preserving all existing features.
- Add explicit review/confirmation step for high-impact operations.
- Add date picker and dedicated due-date field for loans (not free text).
- Add automated UI tests for switching people, switching wallets/currencies, duplicate taps, keyboard resize, and repayment boundary conditions.
