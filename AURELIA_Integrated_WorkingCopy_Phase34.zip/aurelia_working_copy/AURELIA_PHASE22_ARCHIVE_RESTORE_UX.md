# AURELIA Phase 22 — Archive & Restore UX

## Scope
This phase continues from the Phase 21 integrated working copy. It adds observable archived-record lists and user-facing restore actions for People and Wallets.

## Changes
- Added Room DAO query for archived people.
- Added Room DAO query for archived wallets.
- Added Person restore DAO operation.
- Exposed archived people and wallets through FinanceLocalRepository.
- Added restorePerson action to FinanceOverviewViewModel.
- Added Archived people section to PeopleScreen with Restore action.
- Added Archived wallets section to WalletsScreen with Restore action.
- Removed a duplicate, weaker archivePerson implementation at the end of FinanceLocalRepository; the validated transaction-guarded implementation remains authoritative.

## Safety
- Restore changes only the archived flag and updated timestamp.
- Wallet restore retains the existing repository guard requiring archived wallet balance to remain zero.
- Person restore retains historical loans and does not rewrite ledger records.
- Existing archive restrictions remain in place: a person with open loans cannot be archived; a wallet with a non-zero balance cannot be archived.

## Verification
- 9/9 targeted source-level checks passed.
- ZIP integrity is checked after packaging.
- Full Android/Compose/KSP compilation was not run because this environment has no installed Gradle executable and the project has no Gradle wrapper.
- Physical device testing remains pending.

## Next
Continue with transaction lifecycle safety (inspect existing edit/delete/reversal capabilities before adding UI), then Savings/Budget workflows, Reports, Backup/Restore, Security, and final Android build/device QA.
