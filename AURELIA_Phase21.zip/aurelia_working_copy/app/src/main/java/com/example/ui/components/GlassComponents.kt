package com.example.ui.components


import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.zIndex
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AureliaThemeTokens

enum class GlassStyle {
  PEARL,    // Luminous pearl glass (Balance Hero, primary balance containers)
  CRYSTAL,  // High-translucency crystal glass (Floating bottom nav, highlight cards)
  SMOKE,    // Subdued translucent smoke glass (List items, transaction rows, secondary cards)
  AURORA,   // Iridescent gradient borders (Key metrics, active highlight cards)
  FROST,    // Soft diffuse frosted glass (Inputs, search bars, filter containers, form fields)
  LIQUID,   // Fluid dynamic sheen with tactile spring feedback (Interactive primary action surfaces)
}

@Composable
fun AureliaGlassCard(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(26.dp),
  glassStyle: GlassStyle = GlassStyle.PEARL,
  borderWidth: Dp = 1.2.dp,
  onClick: (() -> Unit)? = null,
  content: @Composable () -> Unit,
) {
  val colors = AureliaThemeTokens.colors
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (isPressed && onClick != null) 0.98f else 1f,
    animationSpec = spring(dampingRatio = 0.8f, stiffness = 400f),
    label = "glassCardScale",
  )

  // Configure true Crystal Liquid Glass: crystal translucency + specular top edge refraction
  val (baseColor, borderBrush, specularSheen) = when (glassStyle) {
    GlassStyle.PEARL -> {
      val bg = if (colors.isDark) Color(0xFF16202E).copy(alpha = 0.82f) else Color(0xFFFFFFFF).copy(alpha = 0.88f)
      val border = Brush.verticalGradient(
        colors = listOf(
          if (colors.isDark) Color.White.copy(alpha = 0.40f) else Color.White.copy(alpha = 0.95f),
          if (colors.isDark) Color(0xFF364356).copy(alpha = 0.25f) else Color(0xFFDCE2EA).copy(alpha = 0.45f),
        ),
      )
      val sheen = Brush.radialGradient(
        colors = listOf(
          colors.auroraLavender.copy(alpha = if (colors.isDark) 0.12f else 0.14f),
          Color.Transparent,
        ),
        radius = 800f,
      )
      Triple(bg, border, sheen)
    }

    GlassStyle.CRYSTAL -> {
      val bg = if (colors.isDark) Color(0xFF131C28).copy(alpha = 0.72f) else Color(0xFFFFFFFF).copy(alpha = 0.75f)
      val border = Brush.verticalGradient(
        colors = listOf(
          Color.White.copy(alpha = if (colors.isDark) 0.55f else 0.98f),
          colors.borderFrosted.copy(alpha = if (colors.isDark) 0.25f else 0.40f),
        ),
      )
      val sheen = Brush.radialGradient(
        colors = listOf(
          colors.auroraBlue.copy(alpha = if (colors.isDark) 0.14f else 0.16f),
          Color.Transparent,
        ),
        radius = 700f,
      )
      Triple(bg, border, sheen)
    }

    GlassStyle.SMOKE -> {
      val bg = if (colors.isDark) Color(0xFF101724).copy(alpha = 0.75f) else Color(0xFFEEF2F7).copy(alpha = 0.80f)
      val border = Brush.verticalGradient(
        colors = listOf(
          colors.borderFrosted.copy(alpha = if (colors.isDark) 0.35f else 0.50f),
          colors.borderFrosted.copy(alpha = 0.15f),
        ),
      )
      val sheen = Brush.linearGradient(
        colors = listOf(Color.Transparent, Color.Transparent),
      )
      Triple(bg, border, sheen)
    }

    GlassStyle.AURORA -> {
      val bg = if (colors.isDark) Color(0xFF17202F).copy(alpha = 0.84f) else Color(0xFFFFFFFF).copy(alpha = 0.90f)
      val border = Brush.linearGradient(
        colors = listOf(
          colors.auroraLavender.copy(alpha = 0.80f),
          colors.auroraBlue.copy(alpha = 0.60f),
          colors.auroraMint.copy(alpha = 0.45f),
        ),
      )
      val sheen = Brush.radialGradient(
        colors = listOf(
          colors.auroraLavender.copy(alpha = if (colors.isDark) 0.14f else 0.18f),
          Color.Transparent,
        ),
        radius = 850f,
      )
      Triple(bg, border, sheen)
    }

    GlassStyle.FROST -> {
      val bg = if (colors.isDark) Color(0xFF182230).copy(alpha = 0.85f) else Color(0xFFF4F7FB).copy(alpha = 0.82f)
      val border = Brush.verticalGradient(
        colors = listOf(
          colors.borderFrosted.copy(alpha = if (colors.isDark) 0.50f else 0.65f),
          colors.borderFrosted.copy(alpha = if (colors.isDark) 0.25f else 0.35f),
        ),
      )
      val sheen = Brush.radialGradient(
        colors = listOf(
          Color.White.copy(alpha = if (colors.isDark) 0.05f else 0.20f),
          Color.Transparent,
        ),
        radius = 600f,
      )
      Triple(bg, border, sheen)
    }

    GlassStyle.LIQUID -> {
      val bg = if (colors.isDark) Color(0xFF202A3B).copy(alpha = 0.88f) else Color(0xFFFFFFFF).copy(alpha = 0.92f)
      val border = Brush.linearGradient(
        colors = listOf(
          Color.White.copy(alpha = if (colors.isDark) 0.60f else 0.98f),
          colors.auroraLavender.copy(alpha = if (colors.isDark) 0.45f else 0.60f),
          colors.auroraBlue.copy(alpha = if (colors.isDark) 0.30f else 0.40f),
        ),
      )
      val sheen = Brush.radialGradient(
        colors = listOf(
          colors.auroraLavender.copy(alpha = if (colors.isDark) 0.18f else 0.22f),
          colors.auroraBlue.copy(alpha = if (colors.isDark) 0.08f else 0.10f),
          Color.Transparent,
        ),
        radius = 900f,
      )
      Triple(bg, border, sheen)
    }
  }

  Surface(
    modifier = modifier
      .scale(scale)
      .clip(shape)
      .then(
        if (onClick != null) {
          Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onClick,
          )
        } else Modifier,
      ),
    shape = shape,
    color = baseColor,
    border = BorderStroke(borderWidth, borderBrush),
    shadowElevation = if (colors.isDark) 4.dp else 5.dp,
  ) {
    Box(
      modifier = Modifier
        .background(specularSheen),
    ) {
      // Top specular light-catching bevel edge (gives crystalline glass refraction)
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(1.dp)
          .background(
            Brush.horizontalGradient(
              colors = listOf(
                Color.Transparent,
                Color.White.copy(alpha = if (colors.isDark) 0.35f else 0.80f),
                Color.Transparent,
              ),
            ),
          ),
      )
      content()
    }
  }
}

@Composable
fun AureliaGlassButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  isPrimary: Boolean = true,
  icon: ImageVector? = null,
  iconColor: Color? = null,
) {
  val colors = AureliaThemeTokens.colors
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (isPressed) 0.96f else 1f,
    animationSpec = spring(dampingRatio = 0.75f, stiffness = 500f),
    label = "buttonScale",
  )

  val bgBrush = if (isPrimary) {
    Brush.horizontalGradient(
      colors = listOf(
        colors.auroraLavender.copy(alpha = if (colors.isDark) 0.65f else 0.82f),
        colors.auroraBlue.copy(alpha = if (colors.isDark) 0.65f else 0.82f),
      ),
    )
  } else {
    Brush.horizontalGradient(
      colors = listOf(
        colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.60f else 0.75f),
        colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.60f else 0.75f),
      ),
    )
  }

  val borderStroke = if (isPrimary) {
    BorderStroke(1.2.dp, Color.White.copy(alpha = if (colors.isDark) 0.55f else 0.90f))
  } else {
    BorderStroke(1.dp, colors.borderFrosted.copy(alpha = 0.50f))
  }

  Surface(
    modifier = modifier
      .scale(scale)
      .defaultMinSize(minHeight = 48.dp)
      .clip(RoundedCornerShape(22.dp))
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick,
      ),
    shape = RoundedCornerShape(22.dp),
    color = Color.Transparent,
    border = borderStroke,
    shadowElevation = if (isPrimary) 4.dp else 2.dp,
  ) {
    Box(
      modifier = Modifier.background(bgBrush),
    ) {
      // Top specular highlight bevel line
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(1.dp)
          .background(
            Brush.horizontalGradient(
              colors = listOf(
                Color.Transparent,
                Color.White.copy(alpha = if (colors.isDark) 0.45f else 0.85f),
                Color.Transparent,
              ),
            ),
          ),
      )
      Box(
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
        ) {
          if (icon != null) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = iconColor ?: colors.textPrimary,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
          }
          Text(
            text = text,
            color = colors.textPrimary,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
          )
        }
      }
    }
  }
}

@Composable
fun AureliaChip(
  text: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  icon: ImageVector? = null,
) {
  val colors = AureliaThemeTokens.colors
  val bg = if (isSelected) {
    if (colors.isDark) colors.auroraLavender.copy(alpha = 0.42f) else colors.auroraLavender.copy(alpha = 0.48f)
  } else {
    colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.50f else 0.65f)
  }
  val borderColor = if (isSelected) colors.auroraLavender else colors.borderFrosted.copy(alpha = 0.50f)
  val textColor = if (isSelected) colors.textPrimary else colors.textSecondary

  Surface(
    modifier = modifier
      .defaultMinSize(minHeight = 38.dp)
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(14.dp),
    color = bg,
    border = BorderStroke(1.dp, borderColor),
    shadowElevation = if (isSelected) 3.dp else 1.dp,
  ) {
    Box(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
      contentAlignment = Alignment.Center,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
          text = text,
          color = textColor,
          fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
          fontSize = 13.sp,
        )
      }
    }
  }
}

@Composable
fun AureliaBadge(
  text: String,
  color: Color = AureliaThemeTokens.colors.auroraLavender,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .background(color.copy(alpha = 0.20f))
      .padding(horizontal = 8.dp, vertical = 3.dp),
  ) {
    Text(
      text = text,
      color = color,
      fontSize = 11.sp,
      fontWeight = FontWeight.SemiBold,
      letterSpacing = 0.2.sp,
    )
  }
}

// Indicator dots for Horizontal Pagers
@Composable
fun AureliaPagerIndicator(
  pageCount: Int,
  currentPage: Int,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.Center,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    repeat(pageCount) { index ->
      val isSelected = index == currentPage
      val width by animateFloatAsState(
        targetValue = if (isSelected) 24f else 8f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 300f),
        label = "pagerIndicatorWidth",
      )
      Box(
        modifier = Modifier
          .padding(horizontal = 3.dp)
          .height(6.dp)
          .width(width.dp)
          .clip(CircleShape)
          .background(
            if (isSelected) {
              colors.auroraLavender
            } else {
              colors.borderFrosted.copy(alpha = 0.45f)
            },
          ),
      )
    }
  }
}

enum class AureliaNavDestination {
  HOME,
  ACTIVITY,
  ADD,
  WALLETS,
  MORE,
  PEOPLE,
  PLANNING,
  REPORTS,
}

@Composable
fun AureliaBottomNavBar(
  currentDestination: AureliaNavDestination,
  onNavigate: (AureliaNavDestination) -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  val isDark = colors.isDark

  // Determine active slot index for the 4 selectable destinations (Slot 2 is Central Add)
  val activeSlotIndex = when (currentDestination) {
    AureliaNavDestination.HOME -> 0
    AureliaNavDestination.ACTIVITY -> 1
    AureliaNavDestination.WALLETS -> 3
    AureliaNavDestination.MORE, AureliaNavDestination.PEOPLE, AureliaNavDestination.PLANNING, AureliaNavDestination.REPORTS -> 4
    AureliaNavDestination.ADD -> 0 // ADD is a modal action, does not change the active nav tab
  }

  // Visual tokens for Dock Base (Apple Liquid Glass Dock)
  val dockBgBrush = if (isDark) {
    Brush.verticalGradient(
      colors = listOf(
        Color(0xFF141C2B).copy(alpha = 0.78f),
        Color(0xFF0F1622).copy(alpha = 0.82f),
      ),
    )
  } else {
    Brush.verticalGradient(
      colors = listOf(
        Color(0xFFFFFFFF).copy(alpha = 0.82f),
        Color(0xFFF3F6FA).copy(alpha = 0.72f),
      ),
    )
  }

  val dockBorderBrush = if (isDark) {
    Brush.verticalGradient(
      colors = listOf(
        Color.White.copy(alpha = 0.38f),
        Color(0xFF334358).copy(alpha = 0.20f),
      ),
    )
  } else {
    Brush.verticalGradient(
      colors = listOf(
        Color.White.copy(alpha = 0.95f),
        Color(0xFFCAD4E2).copy(alpha = 0.40f),
      ),
    )
  }

  // Visual tokens for Moving Liquid Glass Capsule (Selected Lens)
  val capsuleBgBrush = if (isDark) {
    Brush.verticalGradient(
      colors = listOf(
        Color(0xFF28364A).copy(alpha = 0.82f),
        Color(0xFF1B2433).copy(alpha = 0.72f),
      ),
    )
  } else {
    Brush.verticalGradient(
      colors = listOf(
        Color.White.copy(alpha = 0.94f),
        Color(0xFFE8EEF8).copy(alpha = 0.85f),
      ),
    )
  }

  val capsuleBorderBrush = if (isDark) {
    Brush.verticalGradient(
      colors = listOf(
        Color.White.copy(alpha = 0.65f),
        colors.auroraBlue.copy(alpha = 0.35f),
      ),
    )
  } else {
    Brush.verticalGradient(
      colors = listOf(
        Color.White,
        Color(0xFFB8C8DF).copy(alpha = 0.60f),
      ),
    )
  }

  val capsuleSheenBrush = if (isDark) {
    Brush.radialGradient(
      colors = listOf(
        colors.auroraLavender.copy(alpha = 0.22f),
        colors.auroraBlue.copy(alpha = 0.08f),
        Color.Transparent,
      ),
      radius = 350f,
    )
  } else {
    Brush.radialGradient(
      colors = listOf(
        colors.auroraLavender.copy(alpha = 0.18f),
        colors.auroraBlue.copy(alpha = 0.08f),
        Color.Transparent,
      ),
      radius = 350f,
    )
  }

  val capsuleSpecularColor = if (isDark) Color.White.copy(alpha = 0.80f) else Color.White.copy(alpha = 0.95f)

  Box(
    modifier = modifier
      .fillMaxWidth()
      .navigationBarsPadding()
      .padding(horizontal = 16.dp, vertical = 8.dp),
    contentAlignment = Alignment.Center,
  ) {
    // Dock Surface (Outer Floating Glass Shell)
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .height(70.dp),
      shape = RoundedCornerShape(35.dp),
      color = Color.Transparent,
      border = BorderStroke(1.2.dp, dockBorderBrush),
      shadowElevation = if (isDark) 8.dp else 7.dp,
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(dockBgBrush),
      ) {
        // Top specular light-catching bevel edge
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  Color.Transparent,
                  if (isDark) Color.White.copy(alpha = 0.40f) else Color.White.copy(alpha = 0.90f),
                  Color.Transparent,
                ),
              ),
            ),
        )

        // Fluid Liquid Glass Navigation Engine
        BoxWithConstraints(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp),
          contentAlignment = Alignment.CenterStart,
        ) {
          val totalWidth = maxWidth
          val slotWidth = totalWidth / 5

          // Target X for the center of the active tab
          val targetCenterX = slotWidth * (activeSlotIndex + 0.5f)

          // Spring-animated horizontal position
          val animatedCenterX by animateDpAsState(
            targetValue = targetCenterX,
            animationSpec = spring(
              dampingRatio = 0.76f, // Organic liquid settling
              stiffness = 380f,     // Rapid, responsive spring
            ),
            label = "waterDropletCenterX",
          )

          // Fluid water droplet stretch calculation
          val travelDelta = targetCenterX.value - animatedCenterX.value
          val travelDistance = kotlin.math.abs(travelDelta)
          val stretchFactor = (travelDistance / 90f).coerceIn(0f, 1f)
          val baseCapsuleWidth = (slotWidth * 0.86f).coerceIn(52.dp, 66.dp)
          // Keep the liquid lens inside its five-slot dock, including on narrow phones.
          val maxCapsuleWidth = slotWidth * 0.96f
          val availableStretch = (maxCapsuleWidth - baseCapsuleWidth).coerceAtLeast(0.dp)
          val stretchExtraWidth = (16.dp * stretchFactor).coerceAtMost(availableStretch)
          val capsuleWidth = (baseCapsuleWidth + stretchExtraWidth).coerceAtMost(totalWidth)
          val capsuleHeight = 52.dp - (3.dp * stretchFactor)

          // Directional elongation: droplet slightly pulls forward toward the target.
          val moveDirection = if (travelDelta >= 0f) 1f else -1f
          val dynamicCenterX = animatedCenterX + (stretchExtraWidth * (moveDirection * 0.20f))
          val requestedLeft = dynamicCenterX - (capsuleWidth / 2f)
          val capsuleLeft = requestedLeft.coerceIn(
            0.dp,
            (totalWidth - capsuleWidth).coerceAtLeast(0.dp),
          )

          // 1. THE SINGLE DYNAMIC LIQUID GLASS CAPSULE (Behind icons, zIndex = 1f)
          Box(
            modifier = Modifier
              .zIndex(1f)
              .offset(x = capsuleLeft, y = (70.dp - capsuleHeight) / 2)
              .width(capsuleWidth)
              .height(capsuleHeight)
              .clip(RoundedCornerShape(22.dp))
              .background(capsuleBgBrush)
              .border(
                width = 1.2.dp,
                brush = capsuleBorderBrush,
                shape = RoundedCornerShape(22.dp),
              ),
          ) {
            // Specular Top Refraction Meniscus Line (water droplet meniscus)
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(1.2.dp)
                .padding(horizontal = 8.dp)
                .background(
                  Brush.horizontalGradient(
                    colors = listOf(
                      Color.Transparent,
                      capsuleSpecularColor,
                      Color.Transparent,
                    ),
                  ),
                ),
            )

            // Radial opalescent sheen moving with the lens
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(capsuleSheenBrush),
            )
          }

          // 2. FOREGROUND NAVIGATION ITEMS & CENTRAL ADD (zIndex = 2f)
          Row(
            modifier = Modifier
              .zIndex(2f)
              .fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            // Tab 0: Home
            NavBarItem(
              label = "Home",
              icon = Icons.Outlined.Home,
              isSelected = activeSlotIndex == 0,
              onClick = { onNavigate(AureliaNavDestination.HOME) },
              testTag = "nav_home",
              modifier = Modifier.weight(1f),
            )

            // Tab 1: Activity
            NavBarItem(
              label = "Activity",
              icon = Icons.Outlined.BarChart,
              isSelected = activeSlotIndex == 1,
              onClick = { onNavigate(AureliaNavDestination.ACTIVITY) },
              testTag = "nav_activity",
              modifier = Modifier.weight(1f),
            )

            // Slot 2: Central Add Action (Floating Crystal Action, unselectable)
            Box(
              modifier = Modifier
                .weight(1f)
                .zIndex(3f),
              contentAlignment = Alignment.Center,
            ) {
              CentralAddActionButton(
                onClick = { onNavigate(AureliaNavDestination.ADD) },
                testTag = "nav_add_center",
              )
            }

            // Tab 3: Wallets
            NavBarItem(
              label = "Wallets",
              icon = Icons.Outlined.AccountBalanceWallet,
              isSelected = activeSlotIndex == 3,
              onClick = { onNavigate(AureliaNavDestination.WALLETS) },
              testTag = "nav_wallets",
              modifier = Modifier.weight(1f),
            )

            // Tab 4: More
            NavBarItem(
              label = "More",
              icon = Icons.Outlined.MoreHoriz,
              isSelected = activeSlotIndex == 4,
              onClick = { onNavigate(AureliaNavDestination.MORE) },
              testTag = "nav_more",
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CentralAddActionButton(
  onClick: () -> Unit,
  testTag: String,
) {
  val colors = AureliaThemeTokens.colors
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (isPressed) 0.90f else 1.0f,
    animationSpec = spring(dampingRatio = 0.75f, stiffness = 500f),
    label = "addBtnScale",
  )

  Box(
    modifier = Modifier
      .scale(scale)
      .size(48.dp)
      .clip(CircleShape)
      .background(
        Brush.linearGradient(
          colors = listOf(
            colors.auroraLavender,
            colors.auroraBlue,
          ),
        ),
      )
      .border(
        width = 1.2.dp,
        brush = Brush.verticalGradient(
          colors = listOf(
            Color.White.copy(alpha = 0.85f),
            Color.White.copy(alpha = 0.30f),
          ),
        ),
        shape = CircleShape,
      )
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick,
      )
      .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    // Top specular arc highlight
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(1.dp)
        .padding(horizontal = 6.dp)
        .align(Alignment.TopCenter)
        .background(
          Brush.horizontalGradient(
            colors = listOf(
              Color.Transparent,
              Color.White.copy(alpha = 0.80f),
              Color.Transparent,
            ),
          ),
        ),
    )
    Icon(
      imageVector = Icons.Default.Add,
      contentDescription = "Quick Add Transaction",
      tint = colors.textPrimary,
      modifier = Modifier.size(26.dp),
    )
  }
}

@Composable
private fun NavBarItem(
  label: String,
  icon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  val isDark = colors.isDark

  val targetContentColor = if (isSelected) {
    if (isDark) Color.White else colors.textPrimary
  } else {
    colors.textSecondary.copy(alpha = 0.65f)
  }

  val contentColor by animateColorAsState(
    targetValue = targetContentColor,
    animationSpec = spring(dampingRatio = 0.8f, stiffness = 400f),
    label = "navItemColor",
  )

  val iconScale by animateFloatAsState(
    targetValue = if (isSelected) 1.12f else 1.0f,
    animationSpec = spring(dampingRatio = 0.75f, stiffness = 450f),
    label = "navIconScale",
  )

  Column(
    modifier = modifier
      .defaultMinSize(minWidth = 52.dp, minHeight = 48.dp)
      .clip(RoundedCornerShape(16.dp))
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick,
      )
      .padding(vertical = 4.dp)
      .testTag(testTag),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = contentColor,
      modifier = Modifier
        .size(22.dp)
        .scale(iconScale),
    )
    Spacer(modifier = Modifier.height(3.dp))
    Text(
      text = label,
      color = contentColor,
      fontSize = 10.5.sp,
      fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
      textAlign = TextAlign.Center,
      maxLines = 1,
    )
  }
}
