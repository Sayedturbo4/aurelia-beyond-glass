# AURELIA Phase 27 — Reports & Analytics Integrity Update

## Changes
- Added `isVoided` to the report projection model (default `false` for source compatibility).
- Excluded voided transactions from report calculations, including currency totals, category expense breakdowns, wallet activity and PDF report inputs.
- Passed Room transaction void state through both ReportsScreen and FinanceOverviewViewModel report projections.
- Excluded voided transactions from CSV export selection in ReportsScreen and defensively in FinanceExportManager.
- Added a regression test proving a voided expense is excluded from report totals and category breakdowns.

## Verification
- Kotlin compiler: `FinanceReports.kt` compiled successfully.
- Executable smoke test: passed; active expense included and voided expense excluded.
- Targeted source checks: 7/7 passed.
- ZIP integrity: to be verified after packaging.

## Not verified
- Full Android/Compose/KSP Gradle build was not run. This working copy has no `gradlew` or `gradle-wrapper.jar`, and no system Gradle executable was available.
- No emulator or physical-device UI test was run.

## Financial reporting policy retained
- Income and expense only; transfers and people/loan ledger entries excluded.
- Different currencies remain separate.
- Date interval remains half-open: `fromInclusiveMillis <= timestamp < untilExclusiveMillis`.
