package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AureliaThemeTokens

/** Stable-key option model for searchable selectors. */
data class SearchPickerItem(
    val id: String,
    val title: String,
    val subtitle: String? = null,
)

/**
 * Compact, accessible picker for long option lists. It avoids horizontal chip scrolling,
 * uses stable IDs instead of list positions, and keeps the result list bounded on small screens.
 */
@Composable
fun SearchablePickerField(
    label: String,
    placeholder: String,
    selectedItem: SearchPickerItem?,
    items: List<SearchPickerItem>,
    onSelect: (SearchPickerItem) -> Unit,
    modifier: Modifier = Modifier,
    emptyMessage: String = "No matching items",
) {
    val colors = AureliaThemeTokens.colors
    var expanded by remember { mutableStateOf(false) }
    var query by remember(expanded) { mutableStateOf("") }
    val filtered = remember(items, query) { filterSearchPickerItems(items, query) }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        Surface(
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
            shape = RoundedCornerShape(15.dp),
            color = colors.surfaceElevated.copy(alpha = if (colors.isDark) 0.58f else 0.72f),
            border = BorderStroke(1.dp, colors.borderFrosted.copy(alpha = 0.55f)),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(selectedItem?.title ?: placeholder, color = if (selectedItem == null) colors.textSecondary else colors.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    if (!selectedItem?.subtitle.isNullOrBlank()) {
                        Text(selectedItem!!.subtitle!!, color = colors.textSecondary, fontSize = 11.sp)
                    }
                }
                Icon(Icons.Default.ExpandMore, contentDescription = if (expanded) "Collapse $label" else "Choose $label", tint = colors.textSecondary)
            }
        }
        if (expanded) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Search $label", color = colors.textSecondary.copy(alpha = 0.7f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.auroraLavender,
                    unfocusedBorderColor = colors.borderFrosted,
                    focusedTextColor = colors.textPrimary,
                    unfocusedTextColor = colors.textPrimary,
                ),
            )
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 224.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                if (filtered.isEmpty()) {
                    Text(emptyMessage, color = colors.textSecondary, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                } else {
                    filtered.forEach { item ->
                        val selected = item.id == selectedItem?.id
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable {
                                onSelect(item)
                                expanded = false
                                query = ""
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) colors.auroraLavender.copy(alpha = 0.14f) else Color.Transparent,
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, color = colors.textPrimary, fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
                                    if (!item.subtitle.isNullOrBlank()) Text(item.subtitle, color = colors.textSecondary, fontSize = 11.sp)
                                }
                                if (selected) Icon(Icons.Default.Check, contentDescription = "Selected", tint = colors.auroraLavender)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Pure filtering logic kept separate so search behavior can be unit tested. */
fun filterSearchPickerItems(items: List<SearchPickerItem>, query: String): List<SearchPickerItem> {
    val normalized = query.trim()
    if (normalized.isEmpty()) return items
    return items.filter { item ->
        item.title.contains(normalized, ignoreCase = true) ||
            item.subtitle?.contains(normalized, ignoreCase = true) == true
    }
}
