package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.design.AureliaRadii
import com.example.ui.design.AureliaSpacing
import com.example.ui.design.AureliaTouch
import com.example.ui.theme.AureliaThemeTokens

/**
 * A restrained translucent surface. This is layered alpha glass, not backdrop blur.
 * Backdrop sampling is intentionally not claimed; a device/API-tested blur renderer
 * will be introduced separately after performance validation.
 */
@Composable
fun AureliaGlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = AureliaRadii.card,
    tone: AureliaSurfaceTone = AureliaSurfaceTone.Standard,
    contentPadding: Dp = AureliaSpacing.lg,
    content: @Composable () -> Unit,
) {
    val colors = AureliaThemeTokens.colors
    val fill = when (tone) {
        AureliaSurfaceTone.Standard -> if (colors.isDark) Color(0xD91A2635) else Color(0xEAFBFCFF)
        AureliaSurfaceTone.Subtle -> if (colors.isDark) Color(0xA9162230) else Color(0xBFEFF3F8)
        AureliaSurfaceTone.Elevated -> if (colors.isDark) Color(0xE6223042) else Color(0xF7FFFFFF)
        AureliaSurfaceTone.Accent -> if (colors.isDark) Color(0xD9272B43) else Color(0xEAF3F0FF)
    }
    val border = Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = if (colors.isDark) 0.34f else 0.92f),
            colors.borderFrosted.copy(alpha = if (colors.isDark) 0.48f else 0.62f),
        ),
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(fill)
            .border(BorderStroke(1.dp, border), shape)
            .padding(contentPadding),
    ) { content() }
}

enum class AureliaSurfaceTone { Standard, Subtle, Elevated, Accent }

@Composable
fun AureliaSectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    supportingText: String? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                title,
                modifier = Modifier.semantics { heading() },
                style = MaterialTheme.typography.titleMedium,
                color = AureliaThemeTokens.colors.textPrimary,
            )
            if (supportingText != null) {
                Text(supportingText, style = MaterialTheme.typography.bodySmall, color = AureliaThemeTokens.colors.textSecondary)
            }
        }
        if (actionLabel != null && onAction != null) {
            Text(
                text = actionLabel,
                modifier = Modifier
                    .heightIn(min = AureliaTouch.minimumTarget)
                    .clip(AureliaRadii.control)
                    .clickable(role = Role.Button, onClick = onAction)
                    .padding(horizontal = AureliaSpacing.sm, vertical = AureliaSpacing.md),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
            )
        }
    }
}

@Composable
fun AureliaActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    primary: Boolean = true,
    leadingContent: (@Composable () -> Unit)? = null,
) {
    val colors = AureliaThemeTokens.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.985f else 1f,
        animationSpec = spring(dampingRatio = 0.82f, stiffness = 520f),
        label = "aureliaActionScale",
    )
    val shape = RoundedCornerShape(18.dp)
    val background = when {
        !enabled -> Brush.linearGradient(listOf(colors.surfaceElevated.copy(alpha = 0.55f), colors.surfaceElevated.copy(alpha = 0.55f)))
        primary -> Brush.linearGradient(listOf(colors.auroraLavender, colors.auroraBlue))
        else -> Brush.linearGradient(listOf(colors.surfaceElevated, colors.surfaceGlass))
    }
    val foreground = if (primary && enabled) Color(0xFF182033) else colors.textPrimary

    Box(
        modifier = modifier
            .scale(scale)
            .defaultMinSize(minHeight = AureliaTouch.primaryButtonHeight)
            .clip(shape)
            .background(background)
            .border(1.dp, colors.borderSpecular.copy(alpha = 0.55f), shape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = AureliaSpacing.xl, vertical = AureliaSpacing.md),
        contentAlignment = Alignment.Center,
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(AureliaSpacing.sm), verticalAlignment = Alignment.CenterVertically) {
            if (leadingContent != null) leadingContent()
            Text(text, color = foreground, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}


/** A quiet separator used between related rows inside a glass surface. */
@Composable
fun AureliaGlassDivider(
    modifier: Modifier = Modifier,
    inset: Dp = AureliaSpacing.sm,
) {
    val colors = AureliaThemeTokens.colors
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = inset)
            .height(1.dp)
            .background(colors.borderFrosted.copy(alpha = if (colors.isDark) 0.72f else 0.82f)),
    )
}

/** Consistent, useful empty state. Actions are optional and never required to dismiss it. */
@Composable
fun AureliaEmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    AureliaGlassSurface(
        modifier = modifier.fillMaxWidth(),
        tone = AureliaSurfaceTone.Subtle,
        contentPadding = AureliaSpacing.xxl,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(AureliaSpacing.sm),
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = AureliaThemeTokens.colors.textPrimary,
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = AureliaThemeTokens.colors.textSecondary,
            )
            if (actionLabel != null && onAction != null) {
                AureliaActionButton(
                    text = actionLabel,
                    onClick = onAction,
                    primary = false,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

/** Compact status label with a consistent touch-safe visual rhythm. */
@Composable
fun AureliaStatusPill(
    text: String,
    modifier: Modifier = Modifier,
    accent: Color = AureliaThemeTokens.colors.auroraBlue,
) {
    val colors = AureliaThemeTokens.colors
    Box(
        modifier = modifier
            .clip(AureliaRadii.pill)
            .background(accent.copy(alpha = if (colors.isDark) 0.18f else 0.14f))
            .border(1.dp, accent.copy(alpha = 0.35f), AureliaRadii.pill)
            .padding(horizontal = AureliaSpacing.md, vertical = AureliaSpacing.xs),
    ) {
        Text(
            text = text,
            color = colors.textPrimary,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
