from pathlib import Path
root = Path(__file__).parent
repo = (root/'app/src/main/java/com/example/data/local/FinanceLocalRepository.kt').read_text()
money = (root/'app/src/main/java/com/example/data/MoneyEngine.kt').read_text()
db = (root/'app/src/main/java/com/example/data/local/AureliaDatabase.kt').read_text()
dao = (root/'app/src/main/java/com/example/data/local/FinanceDao.kt').read_text()
checks = {
 'cash posting requires category': 'require(transaction.categoryId.isNotBlank())' in repo,
 'cash transfer metadata rejected': 'Cash transactions cannot contain transfer metadata' in repo,
 'archived wallet edit rejected': 'Archived wallets cannot receive edited transactions' in repo,
 'new loan starts unrepaid': 'A newly opened loan must start with zero repayments' in repo,
 'transfer category required': 'Transfer category is required' in repo,
 'exact overflow-safe arithmetic': 'Math.addExact' in money and 'Math.subtractExact' in money,
 'same-currency transfer enforced': 'Both wallets and transfer must use the same currency' in repo,
 'Room migration chain to v5': 'version = 5' in db and all(x in db for x in ['Migration(1, 2)', 'Migration(2, 3)', 'Migration(3, 4)', 'Migration(4, 5)']),
 'voided transactions excluded from active query': 'WHERE isVoided = 0 ORDER BY occurredAtMillis DESC' in dao,
 'atomic repository operations present': repo.count('database.withTransaction') >= 8,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' | ' + name)
print(f'RESULT: {sum(checks.values())}/{len(checks)} passed')
if not all(checks.values()): raise SystemExit(1)
