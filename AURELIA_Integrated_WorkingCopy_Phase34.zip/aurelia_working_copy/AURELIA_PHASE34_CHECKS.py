"""Offline release-preparation checks; does not replace Android build/device QA."""
from pathlib import Path

root = Path(__file__).parent
workflow_path = root / ".github/workflows/android-debug.yml"
workflow = workflow_path.read_text() if workflow_path.exists() else ""
readme = (root / "README.md").read_text() if (root / "README.md").exists() else ""
report = root / "AURELIA_PHASE34_FINAL_INTEGRATION_RELEASE_PREP_BN.md"
checks = {
    "Android app module exists": (root / "app/build.gradle.kts").is_file(),
    "GitHub Actions workflow exists": workflow_path.is_file(),
    "Workflow compiles Kotlin": ":app:compileDebugKotlin" in workflow,
    "Workflow runs unit tests": ":app:testDebugUnitTest" in workflow,
    "Workflow assembles debug APK": ":app:assembleDebug" in workflow,
    "Workflow uploads APK artifact": "actions/upload-artifact@v4" in workflow and "*.apk" in workflow,
    "Workflow creates SHA-256 checksum": "sha256sum" in workflow,
    "Workflow creates build metadata": "BUILD_INFO.txt" in workflow,
    "Phone-only artifact instructions documented": "Artifacts" in readme and "APK" in readme,
    "Debug-only / non-production warning documented": "debug apk" in readme.lower() and "production" in readme.lower(),
    "Secret-file ignore rules present": ".env" in (root / ".gitignore").read_text() and "google-services.json" in (root / ".gitignore").read_text(),
    "Phase 34 report exists": report.is_file(),
    "Original AI Studio separation documented": "does **not** automatically update" in readme,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {label}")
print(f"RESULT: {sum(checks.values())}/{len(checks)} passed")
if not all(checks.values()):
    raise SystemExit(1)
