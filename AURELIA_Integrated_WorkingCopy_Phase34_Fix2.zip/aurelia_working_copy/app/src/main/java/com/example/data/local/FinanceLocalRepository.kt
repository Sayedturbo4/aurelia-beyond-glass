package com.example.data.local

import androidx.room.withTransaction
import com.example.data.MoneyEngine
import com.example.data.LoanAccountingPolicy
import kotlinx.coroutines.flow.Flow
import com.example.data.DemoDataProvider

/** Thin local repository boundary. UI should depend on this API, not directly on Room DAOs. */
class FinanceLocalRepository(private val database: AureliaDatabase) {

  /** Imports prototype fixtures once on a fresh local database; never overwrites user data. */
  suspend fun seedDemoDataIfNeeded(nowMillis: Long) {
    database.withTransaction {
      val marker = database.appMetadataDao().getValue("demo_seed_v1")
      if (marker != null) return@withTransaction
      // Existing wallet rows are checked before importing prototype fixtures.
      if (database.walletDao().countAll() > 0 || database.personDao().countAll() > 0) {
        database.appMetadataDao().put(AppMetadataEntity("demo_seed_v1", "skipped_existing_data", nowMillis))
        return@withTransaction
      }

      DemoDataProvider.demoPeople.forEach { item ->
        database.personDao().insert(
          PersonEntity(item.id, item.name, item.phone, item.email, createdAtMillis = nowMillis, updatedAtMillis = nowMillis),
        )
      }
      DemoDataProvider.demoWallets.forEach { item ->
        database.walletDao().insert(
          WalletEntity(item.id, item.name, item.category, item.currencyCode, item.balanceMinorUnits, item.colorHex, item.iconName, createdAtMillis = nowMillis, updatedAtMillis = nowMillis),
        )
      }
      DemoDataProvider.demoLoans.forEach { item ->
        database.loanDao().insert(
          LoanEntity(item.id, item.personId, item.type.name, item.principalMinorUnits, item.repaidMinorUnits, item.currencyCode, nowMillis, note = item.note, createdAtMillis = nowMillis, updatedAtMillis = nowMillis),
        )
      }
      database.appMetadataDao().put(AppMetadataEntity("demo_seed_v1", "completed", nowMillis))
    }
  }


  fun observeCategories(type: String): Flow<List<CategoryEntity>> {
    require(type == "EXPENSE" || type == "INCOME") { "Category type must be EXPENSE or INCOME" }
    return database.categoryDao().observeActive(type)
  }

  fun observeArchivedCategories(): Flow<List<CategoryEntity>> = database.categoryDao().observeArchived()

  suspend fun createCategory(category: CategoryEntity) {
    validateCategory(category)
    require(!category.isSystem) { "User categories cannot be marked as system categories" }
    database.categoryDao().insert(category.copy(name = category.name.trim()))
  }

  suspend fun updateCategory(category: CategoryEntity, nowMillis: Long) {
    validateCategory(category)
    database.withTransaction {
      val existing = requireNotNull(database.categoryDao().findById(category.id)) { "Category not found" }
      require(!existing.isSystem) { "System categories cannot be edited" }
      require(!existing.isArchived) { "Archived categories cannot be edited" }
      database.categoryDao().update(category.copy(
        name = category.name.trim(), isSystem = false, isArchived = false,
        createdAtMillis = existing.createdAtMillis, updatedAtMillis = nowMillis,
      ))
    }
  }

  /** Archive keeps stable IDs referenced by historical transactions and budgets. */
  suspend fun archiveCategory(categoryId: String, nowMillis: Long) {
    require(categoryId.isNotBlank()) { "Category id is required" }
    database.withTransaction {
      val category = requireNotNull(database.categoryDao().findById(categoryId)) { "Category not found" }
      require(!category.isSystem) { "System categories cannot be archived" }
      require(!category.isArchived) { "Category is already archived" }
      check(database.categoryDao().archive(categoryId, nowMillis) == 1) { "Category archive failed" }
    }
  }

  suspend fun restoreCategory(categoryId: String, nowMillis: Long) {
    require(categoryId.isNotBlank()) { "Category id is required" }
    database.withTransaction {
      val category = requireNotNull(database.categoryDao().findById(categoryId)) { "Category not found" }
      require(category.isArchived) { "Category is not archived" }
      check(database.categoryDao().restore(categoryId, nowMillis) == 1) { "Category restore failed" }
    }
  }

  private fun validateCategory(category: CategoryEntity) {
    require(category.id.isNotBlank()) { "Category id is required" }
    require(category.name.isNotBlank() && category.name.trim().length <= 40) { "Category name must be 1–40 characters" }
    require(category.type == "EXPENSE" || category.type == "INCOME") { "Invalid category type" }
    require(category.iconName.isNotBlank()) { "Category icon is required" }
  }

  fun observeBudgets(): Flow<List<BudgetEntity>> = database.budgetDao().observeAll()

  /** Creates a category budget. Period is a half-open interval [start, end). */
  suspend fun createBudget(budget: BudgetEntity) {
    validateBudget(budget)
    database.budgetDao().insert(budget)
  }

  suspend fun updateBudget(budget: BudgetEntity) {
    validateBudget(budget)
    require(database.budgetDao().findById(budget.id) != null) { "Budget not found" }
    database.budgetDao().update(budget)
  }

  suspend fun deleteBudget(budgetId: String) {
    require(budgetId.isNotBlank()) { "Budget id is required" }
    check(database.budgetDao().deleteById(budgetId) == 1) { "Budget not found" }
  }

  private fun validateBudget(budget: BudgetEntity) {
    require(budget.id.isNotBlank()) { "Budget id is required" }
    require(budget.categoryId.isNotBlank()) { "Budget category is required" }
    MoneyEngine.validatePositive(budget.limitMinorUnits)
    require(budget.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
    require(budget.periodStartMillis < budget.periodEndMillis) { "Budget period is invalid" }
  }

  /** Savings goals are tracking records; editing progress never mutates wallet balances. */
  suspend fun createSavingsGoal(goal: SavingsGoalEntity) {
    validateSavingsGoal(goal)
    database.savingsGoalDao().insert(goal.copy(isCompleted = goal.savedMinorUnits >= goal.targetMinorUnits))
  }

  suspend fun updateSavingsGoal(goal: SavingsGoalEntity) {
    validateSavingsGoal(goal)
    require(database.savingsGoalDao().findById(goal.id) != null) { "Savings goal not found" }
    database.savingsGoalDao().update(goal.copy(isCompleted = goal.savedMinorUnits >= goal.targetMinorUnits))
  }

  /** Tracking-only contribution. It never changes a wallet; callers must not present it as a transfer. */
  suspend fun contributeToSavingsGoal(goalId: String, amountMinorUnits: Long, nowMillis: Long) {
    require(goalId.isNotBlank()) { "Savings goal id is required" }
    MoneyEngine.validatePositive(amountMinorUnits)
    database.withTransaction {
      val goal = requireNotNull(database.savingsGoalDao().findById(goalId)) { "Savings goal not found" }
      val updated = MoneyEngine.addExact(goal.savedMinorUnits, amountMinorUnits)
      database.savingsGoalDao().update(goal.copy(
        savedMinorUnits = updated,
        isCompleted = updated >= goal.targetMinorUnits,
        updatedAtMillis = nowMillis,
      ))
      database.savingsContributionDao().insert(
        SavingsContributionEntity(
          id = java.util.UUID.randomUUID().toString(),
          goalId = goalId,
          amountMinorUnits = amountMinorUnits,
          currencyCode = goal.currencyCode,
          occurredAtMillis = nowMillis,
        )
      )
    }
  }

  suspend fun deleteSavingsGoal(goalId: String) {
    require(goalId.isNotBlank()) { "Savings goal id is required" }
    database.withTransaction {
      require(database.savingsGoalDao().findById(goalId) != null) { "Savings goal not found" }
      database.savingsContributionDao().deleteForGoal(goalId)
      check(database.savingsGoalDao().deleteById(goalId) == 1) { "Savings goal not found" }
    }
  }

  private fun validateSavingsGoal(goal: SavingsGoalEntity) {
    require(goal.id.isNotBlank()) { "Savings goal id is required" }
    require(goal.name.isNotBlank()) { "Savings goal name is required" }
    MoneyEngine.validatePositive(goal.targetMinorUnits)
    require(goal.savedMinorUnits >= 0L) { "Saved amount cannot be negative" }
    require(goal.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
  }

  fun observePeople(): Flow<List<PersonEntity>> = database.personDao().observeAll()
  fun observeArchivedPeople(): Flow<List<PersonEntity>> = database.personDao().observeArchived()
  fun observeWallets(): Flow<List<WalletEntity>> = database.walletDao().observeActive()
  fun observeArchivedWallets(): Flow<List<WalletEntity>> = database.walletDao().observeArchived()
  fun observeLoans(): Flow<List<LoanEntity>> = database.loanDao().observeActive()
  fun observeLatestTransactions(limit: Int = 100): Flow<List<TransactionEntity>> =
    database.transactionDao().observeLatest(limit.coerceIn(1, 500))
  fun observeAllTransactions(): Flow<List<TransactionEntity>> = database.transactionDao().observeAll()
  fun observeSavingsGoals(): Flow<List<SavingsGoalEntity>> = database.savingsGoalDao().observeAll()
  fun observeSavingsContributions(): Flow<List<SavingsContributionEntity>> = database.savingsContributionDao().observeAll()

  suspend fun createPerson(person: PersonEntity) {
    require(person.id.isNotBlank()) { "Person id is required" }
    require(person.name.isNotBlank()) { "Person name is required" }
    database.personDao().insert(person.copy(name = person.name.trim()))
  }

  suspend fun updatePerson(person: PersonEntity, nowMillis: Long) {
    require(person.id.isNotBlank()) { "Person id is required" }
    require(person.name.isNotBlank()) { "Person name is required" }
    database.withTransaction {
      val existing = requireNotNull(database.personDao().findById(person.id)) { "Person not found" }
      require(!existing.isArchived) { "Archived person cannot be edited" }
      database.personDao().update(
        person.copy(
          name = person.name.trim(),
          createdAtMillis = existing.createdAtMillis,
          updatedAtMillis = nowMillis,
        ),
      )
      val updated = database.personDao().findById(person.id)
      check(updated?.name == person.name.trim()) {
        "Person update failed"
      }
    }
  }

  /** Keeps loan history intact and prevents hiding a person with unsettled loans. */
  suspend fun archivePerson(personId: String, nowMillis: Long) {
    require(personId.isNotBlank()) { "Person id is required" }
    database.withTransaction {
      val person = requireNotNull(database.personDao().findById(personId)) { "Person not found" }
      require(!person.isArchived) { "Person is already archived" }
      require(database.loanDao().countOpenForPerson(personId) == 0) {
        "Settle all outstanding loans before archiving this person"
      }
      check(database.personDao().archiveById(personId, nowMillis) == 1) { "Person archive failed" }
    }
  }

  /** Restores a previously archived person without changing linked historical records. */
  suspend fun restorePerson(personId: String, nowMillis: Long) {
    require(personId.isNotBlank()) { "Person id is required" }
    database.withTransaction {
      val person = requireNotNull(database.personDao().findById(personId)) { "Person not found" }
      require(person.isArchived) { "Person is not archived" }
      check(database.personDao().restoreById(personId, nowMillis) == 1) { "Person restore failed" }
    }
  }

  suspend fun createWallet(wallet: WalletEntity) {
    require(wallet.id.isNotBlank()) { "Wallet id is required" }
    require(wallet.name.isNotBlank()) { "Wallet name is required" }
    require(wallet.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
    database.walletDao().insert(wallet.copy(name = wallet.name.trim()))
  }

  /** Archives only an empty wallet. Historical transactions remain linked and readable. */
  suspend fun archiveWallet(walletId: String, nowMillis: Long) {
    require(walletId.isNotBlank()) { "Wallet id is required" }
    database.withTransaction {
      val wallet = requireNotNull(database.walletDao().findById(walletId)) { "Wallet not found" }
      require(!wallet.isArchived) { "Wallet is already archived" }
      require(wallet.balanceMinorUnits == 0L) {
        "Wallet balance must be zero before it can be archived. Transfer or reconcile the remaining balance first."
      }
      check(database.walletDao().archiveById(walletId, nowMillis) == 1) { "Wallet archive failed" }
    }
  }

  /** Restores an archived wallet without changing its reconciled zero balance or history. */
  suspend fun restoreWallet(walletId: String, nowMillis: Long) {
    require(walletId.isNotBlank()) { "Wallet id is required" }
    database.withTransaction {
      val wallet = requireNotNull(database.walletDao().findById(walletId)) { "Wallet not found" }
      require(wallet.isArchived) { "Wallet is not archived" }
      require(wallet.balanceMinorUnits == 0L) { "Archived wallet balance must remain zero" }
      check(database.walletDao().restoreById(walletId, nowMillis) == 1) { "Wallet restore failed" }
    }
  }

  /**
   * Edits a posted cash transaction atomically. Only INCOME/EXPENSE rows are editable here;
   * transfers and PEOPLE/loan ledger rows require their dedicated lifecycle operations.
   * The original effect is reversed in-memory inside the same DB transaction before the new
   * effect is applied, so a failed edit leaves both ledger and balances unchanged.
   */
  suspend fun editCashTransaction(updated: TransactionEntity, nowMillis: Long) {
    require(updated.id.isNotBlank()) { "Transaction id is required" }
    require(updated.title.isNotBlank()) { "Transaction title is required" }
    require(updated.type == "INCOME" || updated.type == "EXPENSE") { "Only income and expense can be edited here" }
    MoneyEngine.validatePositive(updated.amountMinorUnits)
    require(updated.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
    require(updated.destinationWalletId == null) { "Cash transaction cannot have a destination wallet" }
    require(updated.categoryId.isNotBlank()) { "Transaction category is required" }
    require(updated.transferFeeMinorUnits == 0L && updated.transferExchangeRateSnapshot == null) {
      "Cash transactions cannot contain transfer metadata"
    }

    database.withTransaction {
      val original = requireNotNull(database.transactionDao().findById(updated.id)) { "Transaction not found" }
      require(!original.isVoided) { "Voided transaction cannot be edited" }
      require(original.type == "INCOME" || original.type == "EXPENSE") {
        "Transfer and loan transactions cannot be edited through this operation"
      }
      val oldWallet = requireNotNull(database.walletDao().findById(original.walletId)) { "Original wallet not found" }
      val oldRestored = when (original.type) {
        "INCOME" -> MoneyEngine.subtractExact(oldWallet.balanceMinorUnits, original.amountMinorUnits).also {
          require(it >= 0L) { "Cannot reverse income: wallet funds have already been spent" }
        }
        "EXPENSE" -> MoneyEngine.addExact(oldWallet.balanceMinorUnits, original.amountMinorUnits)
        else -> error("Unsupported transaction type")
      }
      check(database.walletDao().updateBalance(oldWallet.id, oldRestored, nowMillis) == 1) { "Original wallet reversal failed" }

      val newWallet = requireNotNull(database.walletDao().findById(updated.walletId)) { "Selected wallet not found" }
      require(!newWallet.isArchived) { "Archived wallets cannot receive edited transactions" }
      require(newWallet.currencyCode == updated.currencyCode) { "Transaction and wallet currencies must match" }
      val newBalance = when (updated.type) {
        "INCOME" -> MoneyEngine.addExact(newWallet.balanceMinorUnits, updated.amountMinorUnits)
        "EXPENSE" -> {
          require(newWallet.balanceMinorUnits >= updated.amountMinorUnits) { "Insufficient wallet balance" }
          MoneyEngine.subtractExact(newWallet.balanceMinorUnits, updated.amountMinorUnits)
        }
        else -> error("Unsupported transaction type")
      }
      check(database.walletDao().updateBalance(newWallet.id, newBalance, nowMillis) == 1) { "Updated wallet balance failed" }
      database.transactionDao().update(updated.copy(
        createdAtMillis = original.createdAtMillis,
        updatedAtMillis = nowMillis,
        isVoided = false,
      ))
    }
  }

  /**
   * Soft-voids a cash or same-currency transfer transaction and reverses its wallet effects
   * atomically. The original row remains in the database for audit/recovery purposes.
   * PEOPLE/loan rows are deliberately rejected until loan-specific reversal is implemented.
   */
  suspend fun voidCashOrTransferTransaction(transactionId: String, nowMillis: Long) {
    require(transactionId.isNotBlank()) { "Transaction id is required" }
    database.withTransaction {
      val row = requireNotNull(database.transactionDao().findById(transactionId)) { "Transaction not found" }
      require(!row.isVoided) { "Transaction is already voided" }
      when (row.type) {
        "INCOME" -> {
          require(row.destinationWalletId == null) { "Invalid income transaction" }
          val wallet = requireNotNull(database.walletDao().findById(row.walletId)) { "Wallet not found" }
          val restored = MoneyEngine.subtractExact(wallet.balanceMinorUnits, row.amountMinorUnits)
          require(restored >= 0L) { "Cannot reverse income: wallet funds have already been spent" }
          check(database.walletDao().updateBalance(wallet.id, restored, nowMillis) == 1) { "Wallet reversal failed" }
        }
        "EXPENSE" -> {
          val wallet = requireNotNull(database.walletDao().findById(row.walletId)) { "Wallet not found" }
          val restored = MoneyEngine.addExact(wallet.balanceMinorUnits, row.amountMinorUnits)
          check(database.walletDao().updateBalance(wallet.id, restored, nowMillis) == 1) { "Wallet reversal failed" }
        }
        "TRANSFER" -> {
          val destinationId = requireNotNull(row.destinationWalletId) { "Destination wallet is missing" }
          val source = requireNotNull(database.walletDao().findById(row.walletId)) { "Source wallet not found" }
          val destination = requireNotNull(database.walletDao().findById(destinationId) ) { "Destination wallet not found" }
          require(source.currencyCode == row.currencyCode && destination.currencyCode == row.currencyCode) {
            "Transfer currency mismatch; manual reconciliation required"
          }
          require(row.transferExchangeRateSnapshot == null || row.transferExchangeRateSnapshot == "1") {
            "FX transfer reversal requires a dedicated reviewed operation"
          }
          val sourceRestored = MoneyEngine.addExact(
            source.balanceMinorUnits,
            MoneyEngine.addExact(row.amountMinorUnits, row.transferFeeMinorUnits),
          )
          require(destination.balanceMinorUnits >= row.amountMinorUnits) { "Destination funds have been spent; transfer cannot be reversed safely" }
          val destinationRestored = MoneyEngine.subtractExact(destination.balanceMinorUnits, row.amountMinorUnits)
          check(database.walletDao().updateBalance(source.id, sourceRestored, nowMillis) == 1) { "Source reversal failed" }
          check(database.walletDao().updateBalance(destination.id, destinationRestored, nowMillis) == 1) { "Destination reversal failed" }
        }
        else -> throw IllegalArgumentException("Loan and people transactions require loan-specific reversal")
      }
      check(database.transactionDao().markVoided(transactionId, nowMillis) == 1) { "Transaction void failed" }
    }
  }

  /** Posts income or expense and updates the wallet in one SQLite transaction. */
  suspend fun postCashTransaction(transaction: TransactionEntity, nowMillis: Long) {
    require(transaction.id.isNotBlank()) { "Transaction id is required" }
    require(transaction.title.isNotBlank()) { "Transaction title is required" }
    require(transaction.type == "INCOME" || transaction.type == "EXPENSE") {
      "Only income and expense are supported by this operation"
    }
    MoneyEngine.validatePositive(transaction.amountMinorUnits)
    require(transaction.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
    require(transaction.destinationWalletId == null) { "Cash transaction cannot have a destination wallet" }
    require(transaction.categoryId.isNotBlank()) { "Transaction category is required" }
    require(transaction.transferFeeMinorUnits == 0L && transaction.transferExchangeRateSnapshot == null) {
      "Cash transactions cannot contain transfer metadata"
    }

    database.withTransaction {
      val wallet = requireNotNull(database.walletDao().findById(transaction.walletId)) { "Wallet not found" }
      require(!wallet.isArchived) { "Wallet is archived" }
      require(wallet.currencyCode == transaction.currencyCode) { "Transaction and wallet currencies must match" }
      val updatedBalance = when (transaction.type) {
        "INCOME" -> MoneyEngine.addExact(wallet.balanceMinorUnits, transaction.amountMinorUnits)
        "EXPENSE" -> {
          require(wallet.balanceMinorUnits >= transaction.amountMinorUnits) { "Insufficient wallet balance" }
          MoneyEngine.subtractExact(wallet.balanceMinorUnits, transaction.amountMinorUnits)
        }
        else -> error("Unsupported transaction type")
      }
      check(database.walletDao().updateBalance(wallet.id, updatedBalance, nowMillis) == 1) {
        "Wallet balance update failed"
      }
      database.transactionDao().insert(transaction)
    }
  }


  /** Posts a same-currency wallet transfer atomically; fees are debited from the source wallet. */
  suspend fun postWalletTransfer(transaction: TransactionEntity, nowMillis: Long) {
    require(transaction.id.isNotBlank()) { "Transaction id is required" }
    require(transaction.title.isNotBlank()) { "Transaction title is required" }
    require(transaction.type == "TRANSFER") { "Transaction type must be TRANSFER" }
    MoneyEngine.validatePositive(transaction.amountMinorUnits)
    require(transaction.transferFeeMinorUnits >= 0L) { "Transfer fee cannot be negative" }
    require(transaction.categoryId.isNotBlank()) { "Transfer category is required" }
    require(transaction.destinationWalletId.isNullOrBlank().not()) { "Destination wallet is required" }
    require(transaction.destinationWalletId != transaction.walletId) { "Source and destination wallets must differ" }
    require(transaction.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
    require(transaction.transferExchangeRateSnapshot == null || transaction.transferExchangeRateSnapshot == "1") {
      "Cross-currency transfers require the separately reviewed FX operation"
    }

    database.withTransaction {
      val source = requireNotNull(database.walletDao().findById(transaction.walletId)) { "Source wallet not found" }
      val destination = requireNotNull(database.walletDao().findById(transaction.destinationWalletId!!)) {
        "Destination wallet not found"
      }
      require(!source.isArchived && !destination.isArchived) { "Archived wallets cannot be used" }
      require(source.currencyCode == transaction.currencyCode && destination.currencyCode == transaction.currencyCode) {
        "Both wallets and transfer must use the same currency"
      }
      val balances = MoneyEngine.calculateTransferBalances(
        sourceBalanceMinorUnits = source.balanceMinorUnits,
        destinationBalanceMinorUnits = destination.balanceMinorUnits,
        amountMinorUnits = transaction.amountMinorUnits,
        feeMinorUnits = transaction.transferFeeMinorUnits,
      )
      check(database.walletDao().updateBalance(source.id, balances.sourceBalanceMinorUnits, nowMillis) == 1) {
        "Source wallet update failed"
      }
      check(database.walletDao().updateBalance(destination.id, balances.destinationBalanceMinorUnits, nowMillis) == 1) {
        "Destination wallet update failed"
      }
      database.transactionDao().insert(transaction)
    }
  }

  /** Creates a new contact and its opening loan atomically; no orphan contact on failure. */
  suspend fun createPersonAndLoan(person: PersonEntity, loan: LoanEntity, walletId: String) {
    require(person.id.isNotBlank() && person.name.isNotBlank()) { "A valid person is required" }
    require(loan.personId == person.id) { "Loan must belong to the new person" }
    database.withTransaction {
      database.personDao().insert(person.copy(name = person.name.trim()))
      createLoanWithinTransaction(loan, walletId)
    }
  }

  suspend fun createLoan(loan: LoanEntity, walletId: String) {
    database.withTransaction { createLoanWithinTransaction(loan, walletId) }
  }

  private suspend fun createLoanWithinTransaction(loan: LoanEntity, walletId: String) {
    require(loan.id.isNotBlank()) { "Loan id is required" }
    require(loan.personId.isNotBlank()) { "A person must be selected" }
    require(loan.type == "LENT" || loan.type == "BORROWED") { "Unsupported loan type" }
    require(loan.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
    MoneyEngine.validatePositive(loan.principalMinorUnits)
    require(loan.repaidMinorUnits == 0L) {
      "A newly opened loan must start with zero repayments; record repayments separately"
    }
    require(walletId.isNotBlank()) { "A wallet must be selected" }
    require(database.personDao().findById(loan.personId)?.isArchived == false) {
        "Person does not exist or is archived"
      }
      val wallet = requireNotNull(database.walletDao().findById(walletId)) { "Wallet not found" }
      require(!wallet.isArchived) { "Wallet is archived" }
      require(wallet.currencyCode == loan.currencyCode) { "Wallet and loan currencies must match" }
      val updatedBalance = LoanAccountingPolicy.walletBalanceAfterOpening(
        walletBalanceMinorUnits = wallet.balanceMinorUnits,
        principalMinorUnits = loan.principalMinorUnits,
        loanType = loan.type,
      )
      check(database.walletDao().updateBalance(wallet.id, updatedBalance, loan.createdAtMillis) == 1) {
        "Wallet balance update failed"
      }
      database.loanDao().insert(loan)
      database.transactionDao().insert(
        TransactionEntity(
          id = "loan_open_${loan.id}",
          title = if (loan.type == "LENT") "Money lent" else "Money borrowed",
          categoryId = "loan_opening",
          type = "PEOPLE",
          amountMinorUnits = loan.principalMinorUnits,
          currencyCode = loan.currencyCode,
          walletId = wallet.id,
          personId = loan.personId,
          occurredAtMillis = loan.openedAtMillis,
          note = loan.note,
          createdAtMillis = loan.createdAtMillis,
          updatedAtMillis = loan.updatedAtMillis,
        ),
      )
  }
  /** Repayment update and its ledger transaction commit together or not at all. */
  suspend fun recordLoanRepayment(
    loanId: String,
    amountMinorUnits: Long,
    walletId: String,
    occurredAtMillis: Long,
    transactionId: String,
    nowMillis: Long,
  ) {
    MoneyEngine.validatePositive(amountMinorUnits)
    require(walletId.isNotBlank()) { "Wallet is required" }
    require(transactionId.isNotBlank()) { "Transaction id is required" }

    database.withTransaction {
      val loan = requireNotNull(database.loanDao().findById(loanId)) { "Loan not found" }
      require(!loan.isArchived) { "Loan is archived" }
      val outstanding = MoneyEngine.subtractExact(loan.principalMinorUnits, loan.repaidMinorUnits)
      MoneyEngine.validateRepayment(amountMinorUnits, outstanding)
      val newRepaid = MoneyEngine.addExact(loan.repaidMinorUnits, amountMinorUnits)
      val wallet = requireNotNull(database.walletDao().findById(walletId)) { "Wallet not found" }
      require(!wallet.isArchived) { "Wallet is archived" }
      require(wallet.currencyCode == loan.currencyCode) { "Wallet and loan currencies must match" }
      val newWalletBalance = when (loan.type) {
        "LENT" -> MoneyEngine.addExact(wallet.balanceMinorUnits, amountMinorUnits)
        "BORROWED" -> {
          require(wallet.balanceMinorUnits >= amountMinorUnits) { "Insufficient wallet balance for repayment" }
          MoneyEngine.subtractExact(wallet.balanceMinorUnits, amountMinorUnits)
        }
        else -> error("Unsupported loan type")
      }

      database.loanDao().update(loan.copy(repaidMinorUnits = newRepaid, updatedAtMillis = nowMillis))
      check(database.walletDao().updateBalance(walletId, newWalletBalance, nowMillis) == 1) {
        "Wallet balance update failed"
      }
      database.transactionDao().insert(
        TransactionEntity(
          id = transactionId,
          title = if (loan.type == "LENT") "Loan repayment received" else "Loan repayment sent",
          categoryId = "loan_repayment",
          type = "PEOPLE",
          amountMinorUnits = amountMinorUnits,
          currencyCode = loan.currencyCode,
          walletId = walletId,
          personId = loan.personId,
          occurredAtMillis = occurredAtMillis,
          note = "Repayment for loan $loanId",
          createdAtMillis = nowMillis,
          updatedAtMillis = nowMillis,
        ),
      )
    }
  }

}
