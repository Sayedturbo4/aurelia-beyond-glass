package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.DatePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MoneyEngine
import com.example.export.FinanceExportManager
import com.example.domain.report.CategoryExpenseSummary
import com.example.domain.report.FinanceReport
import com.example.domain.report.FinanceReportCalculator
import com.example.domain.report.ReportDateRange
import com.example.domain.report.ReportTransaction
import com.example.ui.components.AureliaBadge
import com.example.ui.components.AureliaGlassCard
import com.example.ui.components.GlassStyle
import com.example.ui.theme.AureliaThemeTokens
import com.example.ui.viewmodel.FinanceOverviewViewModel
import java.math.BigDecimal
import java.math.MathContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.TimeZone
import java.io.File
import java.util.Locale
import android.widget.Toast

private enum class ReportPeriod(val label: String) {
  DAY("Daily"), WEEK("Weekly"), MONTH("Monthly"), YEAR("Yearly"), CUSTOM("Custom")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
  viewModel: FinanceOverviewViewModel,
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  val context = LocalContext.current
  val transactions by viewModel.allTransactions.collectAsState()
  val wallets by viewModel.wallets.collectAsState()
  var selectedPeriod by remember { mutableStateOf(ReportPeriod.MONTH) }
  var selectedCurrency by remember { mutableStateOf("ALL") }
  var customStartMillis by remember { mutableStateOf<Long?>(null) }
  var customEndExclusiveMillis by remember { mutableStateOf<Long?>(null) }
  var showStartPicker by remember { mutableStateOf(false) }
  var showEndPicker by remember { mutableStateOf(false) }
  var pendingExportFile by remember { mutableStateOf<File?>(null) }

  val nowMillis = remember { System.currentTimeMillis() }
  val defaultMonth = remember(nowMillis) { FinanceReportCalculator.currentMonthRange(nowMillis) }
  val defaultEnd = remember(nowMillis) { FinanceReportCalculator.currentDayRange(nowMillis).untilExclusiveMillis }
  val range = remember(selectedPeriod, nowMillis, customStartMillis, customEndExclusiveMillis) {
    when (selectedPeriod) {
      ReportPeriod.DAY -> FinanceReportCalculator.currentDayRange(nowMillis)
      ReportPeriod.WEEK -> FinanceReportCalculator.currentWeekRange(nowMillis)
      ReportPeriod.MONTH -> FinanceReportCalculator.currentMonthRange(nowMillis)
      ReportPeriod.YEAR -> FinanceReportCalculator.currentYearRange(nowMillis)
      ReportPeriod.CUSTOM -> {
        val start = customStartMillis ?: defaultMonth.fromInclusiveMillis
        val end = customEndExclusiveMillis ?: defaultEnd
        if (start < end) ReportDateRange(start, end) else defaultMonth
      }
    }
  }
  val savePdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
    val file = pendingExportFile
    if (uri != null && file != null) runCatching { FinanceExportManager.saveToUri(context, file, uri) }
      .onSuccess { Toast.makeText(context, "PDF saved successfully", Toast.LENGTH_SHORT).show() }
      .onFailure { Toast.makeText(context, "PDF save failed: ${it.message ?: "Unknown error"}", Toast.LENGTH_LONG).show() }
    pendingExportFile = null
  }
  val saveCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
    val file = pendingExportFile
    if (uri != null && file != null) runCatching { FinanceExportManager.saveToUri(context, file, uri) }
      .onSuccess { Toast.makeText(context, "CSV saved successfully", Toast.LENGTH_SHORT).show() }
      .onFailure { Toast.makeText(context, "CSV save failed: ${it.message ?: "Unknown error"}", Toast.LENGTH_LONG).show() }
    pendingExportFile = null
  }
  val walletNames = remember(wallets) { wallets.associate { it.id to it.name } }
  val reportRows = remember(transactions) {
    transactions.map { row ->
      ReportTransaction(
        id = row.id,
        type = row.type,
        amountMinorUnits = row.amountMinorUnits,
        currencyCode = row.currencyCode,
        categoryId = row.categoryId,
        walletId = row.walletId,
        occurredAtMillis = row.occurredAtMillis,
        isVoided = row.isVoided,
      )
    }
  }
  val report = remember(reportRows, walletNames, range) {
    FinanceReportCalculator.calculate(reportRows, walletNames, range)
  }
  val availableCurrencies = remember(report) { report.currencySummaries.map { it.currencyCode } }
  val effectiveCurrency = if (selectedCurrency == "ALL" || selectedCurrency !in availableCurrencies) "ALL" else selectedCurrency
  val visibleSummaries = if (effectiveCurrency == "ALL") report.currencySummaries
    else report.currencySummaries.filter { it.currencyCode == effectiveCurrency }
  val visibleCategories = if (effectiveCurrency == "ALL") report.categoryExpenses
    else report.categoryExpenses.filter { it.currencyCode == effectiveCurrency }
  val visibleWallets = if (effectiveCurrency == "ALL") report.walletSummaries
    else report.walletSummaries.filter { it.currencyCode == effectiveCurrency }
  val visibleRecordCount = visibleSummaries.sumOf { it.incomeCount + it.expenseCount }
  val rangeFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
  val rangeLabel = "${rangeFormatter.format(Date(range.fromInclusiveMillis))} – ${rangeFormatter.format(Date(range.untilExclusiveMillis - 1L))}"

  if (showStartPicker) {
    val pickerState = rememberDatePickerState(initialSelectedDateMillis = customStartMillis ?: defaultMonth.fromInclusiveMillis)
    DatePickerDialog(
      onDismissRequest = { showStartPicker = false },
      confirmButton = {
        TextButton(onClick = {
          pickerState.selectedDateMillis?.let { selected ->
            val start = pickerUtcMillisToLocalStart(selected)
            customStartMillis = start
            if ((customEndExclusiveMillis ?: defaultEnd) <= start) {
              customEndExclusiveMillis = Calendar.getInstance().apply { timeInMillis = start; add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
            }
          }
          showStartPicker = false
          selectedPeriod = ReportPeriod.CUSTOM
        }) { Text("Set start") }
      },
      dismissButton = { TextButton(onClick = { showStartPicker = false }) { Text("Cancel") } },
    ) { DatePicker(state = pickerState) }
  }
  if (showEndPicker) {
    val pickerState = rememberDatePickerState(initialSelectedDateMillis = previousLocalDayStart(customEndExclusiveMillis ?: defaultEnd))
    DatePickerDialog(
      onDismissRequest = { showEndPicker = false },
      confirmButton = {
        TextButton(onClick = {
          val selected = pickerState.selectedDateMillis?.let { pickerUtcMillisToLocalStart(it) }
          if (selected != null) {
            val endExclusive = Calendar.getInstance().apply { timeInMillis = selected; add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
            val start = customStartMillis ?: defaultMonth.fromInclusiveMillis
            if (start < endExclusive) {
              customEndExclusiveMillis = endExclusive
              selectedPeriod = ReportPeriod.CUSTOM
            } else Toast.makeText(context, "End date must be after start date", Toast.LENGTH_SHORT).show()
          }
          showEndPicker = false
        }) { Text("Set end") }
      },
      dismissButton = { TextButton(onClick = { showEndPicker = false }) { Text("Cancel") } },
    ) { DatePicker(state = pickerState) }
  }

  LazyColumn(
    modifier = modifier.fillMaxSize().padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Spacer(Modifier.height(8.dp))
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
          Text("Reports & Analytics", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
          Text("A clear view of your local finances", fontSize = 12.sp, color = colors.textSecondary)
        }
        AureliaBadge(text = "Offline", color = colors.auroraMint)
      }
    }

    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Report period", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
          ReportPeriod.values().forEach { period ->
            FilterChip(
              selected = selectedPeriod == period,
              onClick = { selectedPeriod = period },
              label = { Text(period.label, fontSize = 11.sp) },
            )
          }
        }
        Text(rangeLabel, fontSize = 11.sp, color = colors.textSecondary)
        if (selectedPeriod == ReportPeriod.CUSTOM) {
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), onClick = { showStartPicker = true }) { Text("Start date", fontSize = 11.sp) }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = { showEndPicker = true }) { Text("End date", fontSize = 11.sp) }
          }
        }
      }
    }

    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Currency", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
          FilterChip(
            selected = effectiveCurrency == "ALL",
            onClick = { selectedCurrency = "ALL" },
            label = { Text("All currencies", fontSize = 11.sp) },
          )
          availableCurrencies.forEach { currency ->
            FilterChip(
              selected = effectiveCurrency == currency,
              onClick = { selectedCurrency = currency },
              label = { Text(currency, fontSize = 11.sp) },
            )
          }
        }
      }
    }

    item {
      AureliaGlassCard(Modifier.fillMaxWidth(), glassStyle = GlassStyle.PEARL, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Export report", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
          Text("Preview scope: $visibleRecordCount income/expense records · $effectiveCurrency · $rangeLabel", fontSize = 11.sp, color = colors.textSecondary)
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
              runCatching {
                val file = FinanceExportManager.createPdf(context, report, rangeLabel, effectiveCurrency)
                FinanceExportManager.share(context, file, "application/pdf")
              }.onFailure { Toast.makeText(context, "PDF share failed: ${it.message ?: "Unknown error"}", Toast.LENGTH_LONG).show() }
            }) { Text("Share PDF", fontSize = 11.sp) }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
              runCatching {
                val selectedRows = transactions.filter { !it.isVoided && it.occurredAtMillis >= range.fromInclusiveMillis && it.occurredAtMillis < range.untilExclusiveMillis }
                val file = FinanceExportManager.createCsv(context, selectedRows, rangeLabel, effectiveCurrency)
                FinanceExportManager.share(context, file, "text/csv")
              }.onFailure { Toast.makeText(context, "CSV share failed: ${it.message ?: "Unknown error"}", Toast.LENGTH_LONG).show() }
            }) { Text("Share CSV", fontSize = 11.sp) }
          }
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
              runCatching {
                val file = FinanceExportManager.createPdf(context, report, rangeLabel, effectiveCurrency)
                pendingExportFile = file
                savePdfLauncher.launch("aurelia_report.pdf")
              }.onFailure { Toast.makeText(context, "PDF preparation failed: ${it.message ?: "Unknown error"}", Toast.LENGTH_LONG).show() }
            }) { Text("Save PDF", fontSize = 11.sp) }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
              runCatching {
                val selectedRows = transactions.filter { !it.isVoided && it.occurredAtMillis >= range.fromInclusiveMillis && it.occurredAtMillis < range.untilExclusiveMillis }
                val file = FinanceExportManager.createCsv(context, selectedRows, rangeLabel, effectiveCurrency)
                pendingExportFile = file
                saveCsvLauncher.launch("aurelia_transactions.csv")
              }.onFailure { Toast.makeText(context, "CSV preparation failed: ${it.message ?: "Unknown error"}", Toast.LENGTH_LONG).show() }
            }) { Text("Save CSV", fontSize = 11.sp) }
          }
        }
      }
    }

    if (visibleSummaries.isEmpty()) {
      item {
        AureliaGlassCard(Modifier.fillMaxWidth(), glassStyle = GlassStyle.PEARL, shape = RoundedCornerShape(22.dp)) {
          Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("No report data yet", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
            Text("Income and expense records for this period will appear here. Transfers and loan entries are intentionally excluded.", fontSize = 12.sp, color = colors.textSecondary)
          }
        }
      }
    }

    items(visibleSummaries, key = { it.currencyCode }) { summary ->
      AureliaGlassCard(Modifier.fillMaxWidth(), glassStyle = GlassStyle.PEARL, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(summary.currencyCode, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            Text("${summary.incomeCount + summary.expenseCount} records", fontSize = 11.sp, color = colors.textSecondary)
          }
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricColumn("Income", MoneyEngine.formatMinor(summary.incomeMinorUnits, summary.currencyCode), colors.financialIncome, Modifier.weight(1f))
            MetricColumn("Expense", MoneyEngine.formatMinor(summary.expenseMinorUnits, summary.currencyCode), colors.financialExpense, Modifier.weight(1f))
          }
          Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(colors.borderFrosted.copy(alpha = 0.45f))) {
            val income = BigDecimal.valueOf(summary.incomeMinorUnits.coerceAtLeast(0L))
            val expense = BigDecimal.valueOf(summary.expenseMinorUnits.coerceAtLeast(0L))
            val total = income.add(expense)
            val incomeFraction = if (total.signum() == 0) 0f else income.divide(total, MathContext.DECIMAL64).toFloat()
            Box(Modifier.fillMaxWidth(incomeFraction.coerceIn(0f, 1f)).height(8.dp).clip(CircleShape).background(colors.financialIncome))
          }
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Net", fontSize = 12.sp, color = colors.textSecondary)
            Text(MoneyEngine.formatMinor(summary.netMinorUnits, summary.currencyCode), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (summary.netMinorUnits >= 0L) colors.financialIncome else colors.financialExpense)
          }
        }
      }
    }

    if (visibleCategories.isNotEmpty()) {
      val largestExpenseByCurrency = visibleCategories.groupBy { it.currencyCode }
        .mapValues { (_, rows) -> rows.maxOfOrNull { it.expenseMinorUnits }?.coerceAtLeast(1L) ?: 1L }
      item { SectionHeading("Category spending", "Expense breakdown for the selected period") }
      items(visibleCategories.take(12), key = { "${it.currencyCode}:${it.categoryId}" }) { category ->
        CategoryExpenseRow(category, largestExpenseByCurrency[category.currencyCode] ?: 1L, colors.textPrimary, colors.textSecondary, colors.financialExpense)
      }
    }

    if (visibleWallets.isNotEmpty()) {
      item { SectionHeading("Wallet activity", "Income and expense by wallet") }
      items(visibleWallets, key = { "${it.currencyCode}:${it.walletId}" }) { wallet ->
        AureliaGlassCard(Modifier.fillMaxWidth(), glassStyle = GlassStyle.SMOKE, shape = RoundedCornerShape(18.dp)) {
          Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(wallet.walletName, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
              Text(wallet.currencyCode, fontSize = 11.sp, color = colors.textSecondary)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("In  ${MoneyEngine.formatMinor(wallet.incomeMinorUnits, wallet.currencyCode)}", fontSize = 11.sp, color = colors.financialIncome)
              Text("Out  ${MoneyEngine.formatMinor(wallet.expenseMinorUnits, wallet.currencyCode)}", fontSize = 11.sp, color = colors.financialExpense)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Net activity", fontSize = 11.sp, color = colors.textSecondary)
              Text(MoneyEngine.formatMinor(wallet.netMinorUnits, wallet.currencyCode), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            }
          }
        }
      }
    }

    item {
      Text(
        "Reports include income and expense records only. Transfers and loan-related entries are excluded; different currencies are never combined.",
        fontSize = 10.sp,
        color = colors.textSecondary,
        modifier = Modifier.padding(vertical = 8.dp),
      )
    }
  }
}

@Composable
private fun MetricColumn(label: String, value: String, accent: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
  val colors = AureliaThemeTokens.colors
  Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
    Text(label, fontSize = 11.sp, color = colors.textSecondary)
    Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = accent)
  }
}

@Composable
private fun SectionHeading(title: String, subtitle: String) {
  val colors = AureliaThemeTokens.colors
  Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
    Text(subtitle, fontSize = 11.sp, color = colors.textSecondary)
  }
}

@Composable
private fun CategoryExpenseRow(
  category: CategoryExpenseSummary,
  maxExpenseMinorUnits: Long,
  primary: androidx.compose.ui.graphics.Color,
  secondary: androidx.compose.ui.graphics.Color,
  accent: androidx.compose.ui.graphics.Color,
) {
  val colors = AureliaThemeTokens.colors
  AureliaGlassCard(Modifier.fillMaxWidth(), glassStyle = GlassStyle.SMOKE, shape = RoundedCornerShape(16.dp)) {
    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(category.categoryId.replace('_', ' ').replaceFirstChar { it.uppercase() }, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = primary)
        Text(MoneyEngine.formatMinor(category.expenseMinorUnits, category.currencyCode), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent)
      }
      Text("${category.transactionCount} expense records · ${category.currencyCode}", fontSize = 10.sp, color = secondary)
      // Category values are compared only against the largest category in the same selected currency.
      val fraction = BigDecimal.valueOf(category.expenseMinorUnits)
        .divide(BigDecimal.valueOf(maxExpenseMinorUnits.coerceAtLeast(1L)), MathContext.DECIMAL64)
        .toFloat().coerceIn(0f, 1f)
      Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(colors.borderFrosted.copy(alpha = 0.4f))) {
        Box(Modifier.fillMaxWidth(fraction).height(5.dp).clip(CircleShape).background(accent.copy(alpha = 0.75f)))
      }
    }
  }
}

/** DatePicker exposes UTC-midnight millis; convert its calendar date to local midnight. */
private fun pickerUtcMillisToLocalStart(utcMillis: Long): Long {
  val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utcMillis }
  return Calendar.getInstance().apply {
    clear()
    set(utc.get(Calendar.YEAR), utc.get(Calendar.MONTH), utc.get(Calendar.DAY_OF_MONTH), 0, 0, 0)
    set(Calendar.MILLISECOND, 0)
  }.timeInMillis
}

private fun previousLocalDayStart(exclusiveEndMillis: Long): Long = Calendar.getInstance().apply {
  timeInMillis = exclusiveEndMillis
  add(Calendar.DAY_OF_MONTH, -1)
}.timeInMillis
