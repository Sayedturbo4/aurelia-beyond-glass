package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AURELIA — BEYOND GLASS Soft Pearlescent Palette

// Light Theme Tokens (Pearl Light)
val PearlBgCanvas = Color(0xFFF4F6F9)
val PearlBgCanvasAlt = Color(0xFFEEF1F5)
val PearlSurface = Color(0xFFFFFFFF)
val PearlSurfaceCloud = Color(0xFFEEF1F5)
val PearlSurfaceCrystal = Color(0xFFFFFFFF)
val PearlBorderSilver = Color(0xFFDCE2EA)
val PearlBorderSpecular = Color(0xFFF8F8FA)
val PearlTextPrimary = Color(0xFF151C28)
val PearlTextSecondary = Color(0xFF55657D)
val PearlTextTertiary = Color(0xFF8896AB)

// Dark Theme Tokens (Midnight Glass)
val MidnightBgCanvas = Color(0xFF10151D)
val MidnightBgCanvasAlt = Color(0xFF151C26)
val MidnightSurface = Color(0xFF1A222E)
val MidnightSurfaceElevated = Color(0xFF263140)
val MidnightBorderFrosted = Color(0xFF364356)
val MidnightBorderSpecular = Color(0xFF50607A)
val MidnightTextPrimary = Color(0xFFF3F5F9)
val MidnightTextSecondary = Color(0xFFB4BDCB)
val MidnightTextTertiary = Color(0xFF7E8A9E)

// Aurora Accents (Soft Opalescent - Balanced, Non-Neon & Elegant)
val AuroraBlueLight = Color(0xFF90B8EE)
val AuroraBlueDark = Color(0xFF9CBDF3)

val AuroraLavenderLight = Color(0xFFB8A6E8)
val AuroraLavenderDark = Color(0xFFC4B2EB)

val AuroraRoseLight = Color(0xFFE5B0C8)
val AuroraRoseDark = Color(0xFFF4688A)

val AuroraMintLight = Color(0xFFA0DCC8)
val AuroraMintDark = Color(0xFF2DD4BF)

// Financial Semantic Tokens
val FinancialIncomeLight = Color(0xFF0D9488) // Soft Emerald/Teal
val FinancialIncomeDark = Color(0xFF2DD4BF)

val FinancialExpenseLight = Color(0xFFE11D48) // Soft Ruby/Rose
val FinancialExpenseDark = Color(0xFFFB7185)

val DiamondCyanLight = Color(0xFF0284C7)
val DiamondCyanDark = Color(0xFF38BDF8)
