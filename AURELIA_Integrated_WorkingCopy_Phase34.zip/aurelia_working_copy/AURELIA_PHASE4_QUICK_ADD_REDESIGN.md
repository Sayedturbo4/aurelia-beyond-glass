# AURELIA Phase 4 — Quick Add UX & Validation Improvements

## Scope
This phase refines the existing native Compose Quick Add sheet without replacing the Room-backed persistence operations or changing the finance schema.

## Changes implemented

1. **Keyboard-aware, scrollable sheet**
   - Added IME insets and vertical scrolling to the sheet content.
   - Long forms can now scroll while the software keyboard is visible instead of relying on a fixed-height content column.

2. **Same-currency transfer destination filtering**
   - Destination choices now include only wallets whose currency matches the selected source wallet.
   - When no compatible destination exists, the UI explains that cross-currency transfers are not supported yet.
   - A final UI-side guard rejects a mismatched destination before dispatching the repository operation.
   - The Room repository remains the authoritative validation boundary and already rejects cross-currency transfers.

3. **Loan repayment pre-validation**
   - The selected repayment loan must use the same currency as the selected wallet.
   - The entered repayment amount is checked against that loan's outstanding amount before repository dispatch.
   - The repository continues to re-check currency, outstanding balance, wallet state and atomic ledger updates inside its database transaction.

## Preserved
- Existing Room entities and database schema.
- MoneyEngine parsing and minor-unit arithmetic.
- Existing repository transaction boundaries.
- Existing Income, Expense, Transfer, Loan creation and Repayment persistence APIs.
- AI Studio original project; this is only a separate ChatGPT working copy.

## Verification performed
- Source inspection of QuickAddSheet, FinanceOverviewViewModel, FinanceLocalRepository and MoneyEngine.
- Confirmed repository-level same-currency transfer enforcement.
- Confirmed repository-level loan repayment currency and outstanding-balance enforcement.
- Confirmed new sheet scroll/IME modifiers and pre-validation guards are present.
- ZIP integrity check performed after packaging.

## Not verified
- Full Android/Compose compilation.
- Room/KSP compilation.
- Runtime keyboard behavior on a physical Android device.
- Visual blur/backdrop rendering.
- End-to-end Quick Add operations on device.

The project archive does not include a Gradle Wrapper executable/jar, and this environment does not have a configured Android SDK/Gradle build, so no Android build success is claimed.

## Next
Phase 5 should refine Wallet selection, Category selection, Person selection and Loan selection into searchable, accessible pickers; then add dedicated Compose/UI tests and device verification.
