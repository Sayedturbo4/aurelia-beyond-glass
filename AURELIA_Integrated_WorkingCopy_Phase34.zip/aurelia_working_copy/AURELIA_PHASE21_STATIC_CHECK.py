from pathlib import Path
p = Path('app/src/main/java/com/example/ui/screens/PeopleScreen.kt')
s = p.read_text()
checks = {
    'person edit action exists': 'text = "Edit person"' in s,
    'person archive action exists': 'text = "Archive"' in s,
    'edit uses ViewModel update API': 'viewModel.updatePerson(' in s,
    'archive uses ViewModel archive API': 'viewModel.archivePerson(' in s,
    'archive confirmation explains unsettled loans': 'All outstanding loans must be settled first.' in s,
    'person name validation exists': 'Name is required' in s,
    'email field exists': 'Email (optional)' in s,
    'phone field exists': 'Phone (optional)' in s,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + label)
if not all(checks.values()):
    raise SystemExit(1)
print(f'{len(checks)}/{len(checks)} checks passed')
