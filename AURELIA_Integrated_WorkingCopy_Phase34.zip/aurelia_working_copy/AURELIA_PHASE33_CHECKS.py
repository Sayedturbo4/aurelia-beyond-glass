"""Offline structural preflight for AURELIA Phase 33 CI."""
from pathlib import Path
root = Path(__file__).parent
main = root / 'app/src/main/java/com/example'
tests = root / 'app/src/test/java/com/example'
workflow = (root / '.github/workflows/android-debug.yml').read_text()
checks = {
    'Android app module exists': (root / 'app/build.gradle.kts').is_file(),
    'Kotlin source tree exists': main.is_dir() and len(list(main.rglob('*.kt'))) >= 30,
    'Unit test source tree exists': tests.is_dir(),
    'Money engine tests present': (tests / 'MoneyEngineTest.kt').is_file(),
    'Finance domain tests present': (tests / 'FinanceDomainModelTest.kt').is_file(),
    'Budget progress tests present': (tests / 'domain/model/BudgetProgressTest.kt').is_file(),
    'Report calculator tests present': (tests / 'domain/report/FinanceReportCalculatorTest.kt').is_file(),
    'CSV export tests present': (tests / 'export/FinanceCsvExporterTest.kt').is_file(),
    'Security policy tests present': (tests / 'security/AppSecurityPolicyTest.kt').is_file(),
    'Picker filter tests present': (tests / 'ui/components/SearchPickerFilterTest.kt').is_file(),
    'CI runs Kotlin compilation': ':app:compileDebugKotlin' in workflow,
    'CI runs unit tests': ':app:testDebugUnitTest' in workflow,
    'CI assembles APK': ':app:assembleDebug' in workflow,
    'CI uploads APK artifact': 'actions/upload-artifact@v4' in workflow and '*.apk' in workflow,
    'CI emits SHA-256 checksum': 'sha256sum' in workflow,
    'CI emits build metadata': 'BUILD_INFO.txt' in workflow,
}
for label, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'} | {label}")
print(f"RESULT: {sum(checks.values())}/{len(checks)} passed")
if not all(checks.values()):
    raise SystemExit(1)
