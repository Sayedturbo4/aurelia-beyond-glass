from pathlib import Path
root=Path(__file__).parent
entity=(root/"app/src/main/java/com/example/data/local/FinanceEntities.kt").read_text()
dao=(root/"app/src/main/java/com/example/data/local/FinanceDao.kt").read_text()
db=(root/"app/src/main/java/com/example/data/local/AureliaDatabase.kt").read_text()
repo=(root/"app/src/main/java/com/example/data/local/FinanceLocalRepository.kt").read_text()
vm=(root/"app/src/main/java/com/example/ui/viewmodel/FinanceOverviewViewModel.kt").read_text()
checks={
"transaction soft-void field exists":"val isVoided: Boolean = false" in entity,
"Room migration 2 to 3 exists":"Migration(2, 3)" in db and "ALTER TABLE transactions ADD COLUMN isVoided" in db,
"active transaction query excludes voids":"WHERE isVoided = 0 ORDER BY occurredAtMillis DESC" in dao,
"cash edit is atomic":"suspend fun editCashTransaction" in repo and "database.withTransaction" in repo[repo.index("suspend fun editCashTransaction"):repo.index("suspend fun voidCashOrTransferTransaction")],
"cash and transfer void is atomic":"suspend fun voidCashOrTransferTransaction" in repo,
"loan generic reversal is rejected":"Loan and people transactions require loan-specific reversal" in repo,
"FX reversal is rejected":"FX transfer reversal requires a dedicated reviewed operation" in repo,
"ViewModel exposes edit and void":"fun editCashTransaction" in vm and "fun voidCashOrTransferTransaction" in vm,
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+" "+name)
print(f"{sum(checks.values())}/{len(checks)} checks passed")
raise SystemExit(0 if all(checks.values()) else 1)
