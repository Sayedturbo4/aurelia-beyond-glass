from pathlib import Path
root=Path(__file__).parent
entities=(root/'app/src/main/java/com/example/data/local/FinanceEntities.kt').read_text()
dao=(root/'app/src/main/java/com/example/data/local/FinanceDao.kt').read_text()
db=(root/'app/src/main/java/com/example/data/local/AureliaDatabase.kt').read_text()
repo=(root/'app/src/main/java/com/example/data/local/FinanceLocalRepository.kt').read_text()
vm=(root/'app/src/main/java/com/example/ui/viewmodel/FinanceOverviewViewModel.kt').read_text()
ui=(root/'app/src/main/java/com/example/ui/screens/CategoriesScreen.kt').read_text()
main=(root/'app/src/main/java/com/example/MainActivity.kt').read_text()
checks={
 'category Room entity exists':'data class CategoryEntity' in entities,
 'category DAO supports active and archived queries':'interface CategoryDao' in dao and 'observeArchived()' in dao,
 'database schema migrated to version 5':'version = 5' in db and 'Migration(4, 5)' in db,
 'migration seeds legacy-compatible default category IDs':'Food & Dining|Food & Dining|EXPENSE' in db and 'Shopping|Shopping|EXPENSE' in db,
 'repository validates category type and name':'Category type must be EXPENSE or INCOME' in repo and '1–40 characters' in repo,
 'system categories protected from edit/archive':'System categories cannot be edited' in repo and 'System categories cannot be archived' in repo,
 'archive and restore APIs preserve stable references':'suspend fun archiveCategory' in repo and 'suspend fun restoreCategory' in repo,
 'ViewModel exposes category flows and actions':'expenseCategories' in vm and 'fun createCategory' in vm and 'fun restoreCategory' in vm,
 'category screen supports create/edit/archive/restore':'CategoriesScreen' in ui and 'Add category' in ui and 'Restore' in ui and 'Archive' in ui and 'Edit category' in ui,
 'More navigation routes to categories':'onNavigateToCategories' in main and 'AureliaNavDestination.CATEGORIES' in main,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
