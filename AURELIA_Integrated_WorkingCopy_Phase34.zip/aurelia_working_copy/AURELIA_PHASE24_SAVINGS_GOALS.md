# AURELIA Phase 24 — Savings Goals & Contribution History

## Implemented in the consolidated working copy
- Added `SavingsContributionEntity` as an append-only record of each tracked contribution.
- Added Room DAO queries for contribution history and per-goal history.
- Added Room migration 3→4 creating the contribution table and `(goalId, occurredAtMillis)` index without modifying existing finance records.
- Updated contribution recording to update the goal and insert its history row inside the same Room transaction.
- Updated goal deletion to remove its contribution history and goal atomically.
- Exposed contribution history through the ViewModel.
- Added a per-goal contribution input and latest-five history rows to PlanningScreen.
- Kept the product rule explicit: savings contributions are tracking-only and do not move wallet funds or create ledger transactions.

## Safety
- Amounts remain integer minor units; UI parses using the goal currency scale.
- Repository validates positive contribution and uses exact overflow-checked addition.
- Contribution row currency is copied from the goal, not user-supplied independently.
- Goal progress and history insert are atomic.
- Existing Room migration chain 1→2→3 is retained and extended to 4.

## Verification
- Source assertions: passed for entity, DAO, migration, transactional insert/delete, ViewModel exposure and UI history.
- ZIP integrity: verified.
- Full Android Gradle/Room KSP/Compose compilation and device testing: not run in this environment; must be verified by GitHub Actions and on-device testing.
