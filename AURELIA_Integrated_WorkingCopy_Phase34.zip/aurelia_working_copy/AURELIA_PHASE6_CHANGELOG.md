# Phase 6 Changelog

1. Quick Add now resets the selected active-loan index when switching people.
2. Quick Add note is optional, multiline, and capped at 500 characters.
3. No schema or financial engine changes.
4. Android build/device verification remains pending.
