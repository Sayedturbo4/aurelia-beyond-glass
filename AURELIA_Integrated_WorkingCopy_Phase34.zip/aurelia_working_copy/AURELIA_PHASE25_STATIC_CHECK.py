from pathlib import Path
root = Path(__file__).parent
planning = (root / 'app/src/main/java/com/example/ui/screens/PlanningScreen.kt').read_text()
viewmodel = (root / 'app/src/main/java/com/example/ui/viewmodel/FinanceOverviewViewModel.kt').read_text()
repo = (root / 'app/src/main/java/com/example/data/local/FinanceLocalRepository.kt').read_text()
checks = {
    'budget edit state': 'var editingBudget by remember' in planning,
    'budget update path': 'viewModel.updateBudget(entity, save)' in planning,
    'budget deletion confirmation': 'Delete budget?' in planning,
    'deletion does not affect ledger copy': 'Your transactions and wallet balances will not change.' in planning,
    'overspend percentage visible': 'progress.progressPercent' in planning,
    'budget repository validation': 'private fun validateBudget' in repo,
    'viewmodel savings contribution import': 'import com.example.data.local.SavingsContributionEntity' in viewmodel,
    'budget progress remains exact minor units': 'Math.addExact(total, item.amountMinorUnits)' in (root / 'app/src/main/java/com/example/domain/model/BudgetProgress.kt').read_text(),
}
for name, passed in checks.items():
    assert passed, f'FAIL: {name}'
    print(f'PASS: {name}')
print(f'{len(checks)}/{len(checks)} checks passed')
