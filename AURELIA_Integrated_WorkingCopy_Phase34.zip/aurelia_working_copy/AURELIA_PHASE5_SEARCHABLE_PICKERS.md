# AURELIA Phase 5 — Searchable Picker Foundation

## Scope
This phase continues from the Phase 4 isolated ChatGPT Working Copy. It does not modify the Google AI Studio original project or the user's GitHub repository.

## Implemented
- Added reusable `SearchablePickerField` and stable-key `SearchPickerItem` Compose components.
- Added bounded, vertically scrollable search results to avoid long horizontal chip rows.
- Search matches option titles and subtitles without case sensitivity and trims surrounding whitespace.
- Replaced Quick Add horizontal chip selection for People, Active Loan, Source Wallet, Destination Wallet and Category with searchable selection fields.
- Wallet picker subtitles show currency and formatted balance; destination choices remain filtered to same-currency wallets by the Phase 4 rule.
- Person picker uses stable person IDs for selection mapping; selecting a person resets no underlying records.
- Active Loan picker shows outstanding balance and uses loan IDs to map the selection.
- Added an explicit Add New Person / Cancel New Person action rather than mixing a special pseudo-person chip into the same horizontal list.
- Added pure search-filter unit tests for blank query, case-insensitive title matching, subtitle/currency matching and no-result behavior.

## Files changed
- `app/src/main/java/com/example/ui/components/SearchablePickerField.kt` (new)
- `app/src/main/java/com/example/ui/screens/QuickAddSheet.kt`
- `app/src/test/java/com/example/ui/components/SearchPickerFilterTest.kt` (new)

## Verification performed
- Reviewed the existing Quick Add model fields and picker call sites before integration.
- Confirmed all five picker use cases are wired to stable IDs and selection callbacks.
- Confirmed destination wallet options are sourced only from the Phase 4 same-currency-compatible index list.
- Added four JUnit tests for the pure search filter function.
- ZIP integrity and Kotlin source delimiter/static checks are performed during packaging.

## Not verified
- Full Android/Compose compilation, KSP/Room compilation, JUnit execution, emulator rendering and physical-device interaction have not been run in this environment.
- Search focus/keyboard behavior and visual blur need device verification.
- Existing Quick Add flow still requires end-to-end tests for cash transactions, transfers, new-person-plus-loan, repayments, duplicate-submit prevention and persistence after restart.

## Known follow-up work
- Migrate picker selection state fully from indexes to IDs where lists can update while the sheet is open.
- Separate Income, Expense and Transfer into contextual forms rather than a single large multi-mode sheet.
- Replace the free-text note field with clear optional date/note fields where appropriate.
- Build dedicated Wallets, People & Loans, Activity, Budgets, Savings, Reports, Backup/Restore and Settings UX.
- Add full UI and repository integration tests, then validate using GitHub Actions and a real Android device.
