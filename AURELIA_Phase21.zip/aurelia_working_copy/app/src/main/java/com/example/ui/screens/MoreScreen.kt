package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AureliaBadge
import com.example.ui.components.AureliaGlassCard
import com.example.ui.components.GlassStyle
import com.example.ui.theme.AureliaThemeTokens

@Composable
fun MoreScreen(
  isDarkTheme: Boolean,
  onToggleTheme: () -> Unit,
  onNavigateToPeople: () -> Unit,
  onNavigateToPlanning: () -> Unit = {},
  onNavigateToReports: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val colors = AureliaThemeTokens.colors
  var isAppLockEnabled by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Header
    item {
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "AURELIA Hub",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
          )
          Text(
            text = "Extended features and settings",
            fontSize = 12.sp,
            color = colors.textSecondary,
          )
        }
        AureliaBadge(text = "Prototype Stage", color = colors.auroraLavender)
      }
    }

    // 2. Profile Card
    item {
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.PEARL,
        shape = RoundedCornerShape(22.dp),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(CircleShape)
              .background(colors.auroraLavender.copy(alpha = 0.35f)),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = "R",
              fontWeight = FontWeight.Bold,
              fontSize = 24.sp,
              color = colors.textPrimary,
            )
          }
          Spacer(modifier = Modifier.width(16.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Rahim Chowdhury",
              fontSize = 16.sp,
              fontWeight = FontWeight.SemiBold,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "rahim.aurelia@example.com",
              fontSize = 12.sp,
              color = colors.textSecondary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            AureliaBadge(text = "Local Offline Vault Active", color = colors.financialIncome)
          }
        }
      }
    }

    // 3. Featured Active Module: People & Interest-Free Loans
    item {
      Text(
        text = "Active Features",
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        color = colors.textPrimary,
      )
    }

    item {
      AureliaGlassCard(
        modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onNavigateToPeople)
          .testTag("nav_to_people_from_more"),
        glassStyle = GlassStyle.AURORA,
        shape = RoundedCornerShape(20.dp),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(colors.auroraBlue.copy(alpha = 0.3f)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Default.People,
                contentDescription = null,
                tint = colors.textPrimary,
                modifier = Modifier.size(22.dp),
              )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
              Text(
                text = "People & Interest-Free Loans",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
              )
              Text(
                text = "Track money lent, borrowed & repayments",
                fontSize = 12.sp,
                color = colors.textSecondary,
              )
            }
          }
          Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = colors.textPrimary,
            modifier = Modifier.size(20.dp),
          )
        }
      }
    }

    item {
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onNavigateToPlanning).testTag("nav_to_planning_from_more"),
        glassStyle = GlassStyle.PEARL,
        shape = RoundedCornerShape(20.dp),
      ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(colors.auroraMint.copy(alpha = 0.28f)), contentAlignment = Alignment.Center) {
              Icon(imageVector = Icons.Default.PieChart, contentDescription = null, tint = colors.textPrimary, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column {
              Text("Budgets & Savings Goals", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
              Text("Plan spending and track savings", fontSize = 12.sp, color = colors.textSecondary)
            }
          }
          Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = colors.textPrimary, modifier = Modifier.size(20.dp))
        }
      }
    }

    item {
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onNavigateToReports).testTag("nav_to_reports_from_more"),
        glassStyle = GlassStyle.PEARL,
        shape = RoundedCornerShape(20.dp),
      ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(colors.auroraBlue.copy(alpha = 0.28f)), contentAlignment = Alignment.Center) {
              Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, tint = colors.textPrimary, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column {
              Text("Reports & Analytics", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
              Text("Review income, expenses and trends", fontSize = 12.sp, color = colors.textSecondary)
            }
          }
          Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = colors.textPrimary, modifier = Modifier.size(20.dp))
        }
      }
    }

    // 4. Appearance & Preferences
    item {
      Text(
        text = "Appearance & System",
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        color = colors.textPrimary,
      )
    }

    item {
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.SMOKE,
        shape = RoundedCornerShape(20.dp),
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Theme Switcher row
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable(onClick = onToggleTheme)
              .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(colors.surfaceElevated),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = if (isDarkTheme) Icons.Default.DarkMode else Icons.Default.LightMode,
                  contentDescription = null,
                  tint = colors.auroraLavender,
                  modifier = Modifier.size(20.dp),
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column {
                Text(
                  text = if (isDarkTheme) "Midnight Glass Theme" else "Pearl Light Theme",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = colors.textPrimary,
                )
                Text(
                  text = if (isDarkTheme) "Dark spatial translucent surfaces" else "Soft opalescent pearl atmosphere",
                  fontSize = 12.sp,
                  color = colors.textSecondary,
                )
              }
            }
            Switch(
              checked = isDarkTheme,
              onCheckedChange = { onToggleTheme() },
              colors = SwitchDefaults.colors(
                checkedThumbColor = colors.auroraLavender,
                checkedTrackColor = colors.auroraLavender.copy(alpha = 0.4f),
              ),
              modifier = Modifier.testTag("switch_dark_theme"),
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Biometric App Lock Toggle
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(colors.surfaceElevated),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Default.Lock,
                  contentDescription = null,
                  tint = colors.auroraBlue,
                  modifier = Modifier.size(20.dp),
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column {
                Text(
                  text = "Biometric App Lock",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = colors.textPrimary,
                )
                Text(
                  text = "Fingerprint / PIN protection",
                  fontSize = 12.sp,
                  color = colors.textSecondary,
                )
              }
            }
            Switch(
              checked = isAppLockEnabled,
              onCheckedChange = { isAppLockEnabled = it },
              colors = SwitchDefaults.colors(
                checkedThumbColor = colors.auroraBlue,
                checkedTrackColor = colors.auroraBlue.copy(alpha = 0.4f),
              ),
            )
          }
        }
      }
    }

    // 5. Secondary Features Roadmap (Clearly Labeled Placeholders)
    item {
      Text(
        text = "Future Online Modules Roadmap",
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        color = colors.textPrimary,
      )
    }

    item {
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.SMOKE,
        shape = RoundedCornerShape(20.dp),
      ) {
        Column(modifier = Modifier.padding(8.dp)) {
          HubFeatureRow(
            icon = Icons.Default.Savings,
            title = "Budgets & Savings Goals",
            subtitle = "Pacing caps and visual milestones",
            badgeText = "Roadmap",
          )
          HubFeatureRow(
            icon = Icons.Default.PieChart,
            title = "Reports & Analytics",
            subtitle = "Exportable cash flow statements",
            badgeText = "Roadmap",
          )
          HubFeatureRow(
            icon = Icons.Default.TrendingUp,
            title = "Crypto Portfolio Tracking",
            subtitle = "Manual offline asset tracker",
            badgeText = "Roadmap",
          )
          HubFeatureRow(
            icon = Icons.Default.Diamond,
            title = "Digital Diamonds & Gifting",
            subtitle = "Virtual tokens and creator rewards",
            badgeText = "Offline Demo",
          )
        }
      }
    }

    // 6. App Identity & Blueprint Information
    item {
      AureliaGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glassStyle = GlassStyle.AURORA,
        shape = RoundedCornerShape(20.dp),
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = "AURELIA — BEYOND GLASS",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Version 1.2 (Prototype Refinement V2)\n100% Native Kotlin & Jetpack Compose. Absolute Offline-First Architecture.",
            fontSize = 12.sp,
            color = colors.textSecondary,
            lineHeight = 18.sp,
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(84.dp))
    }
  }
}

@Composable
private fun HubFeatureRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  badgeText: String,
) {
  val colors = AureliaThemeTokens.colors
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 10.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(colors.surfaceElevated),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = colors.textSecondary,
          modifier = Modifier.size(18.dp),
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        Text(text = subtitle, fontSize = 11.sp, color = colors.textSecondary)
      }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
      AureliaBadge(text = badgeText, color = colors.auroraLavender)
      Spacer(modifier = Modifier.width(4.dp))
      Icon(
        imageVector = Icons.Default.ChevronRight,
        contentDescription = null,
        tint = colors.textSecondary.copy(alpha = 0.5f),
        modifier = Modifier.size(18.dp),
      )
    }
  }
}
