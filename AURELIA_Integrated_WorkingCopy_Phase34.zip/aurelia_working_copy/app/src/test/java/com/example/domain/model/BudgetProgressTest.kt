package com.example.domain.model

import org.junit.Assert.*
import org.junit.Test

class BudgetProgressTest {
  @Test fun countsOnlyMatchingExpenseWithinPeriod() {
    val rows = listOf(
      BudgetExpenseRecord("food", "BDT", "EXPENSE", 1_000, 10),
      BudgetExpenseRecord("food", "BDT", "EXPENSE", 2_000, 20),
      BudgetExpenseRecord("food", "USD", "EXPENSE", 9_000, 20),
      BudgetExpenseRecord("travel", "BDT", "EXPENSE", 8_000, 20),
      BudgetExpenseRecord("food", "BDT", "INCOME", 7_000, 20),
      BudgetExpenseRecord("food", "BDT", "EXPENSE", 5_000, 100),
    )
    val result = calculateBudgetProgress("b1", "food", "BDT", 5_000, 0, 100, rows)
    assertEquals(3_000L, result.spentMinorUnits)
    assertEquals(2_000L, result.remainingMinorUnits)
    assertFalse(result.isOverBudget)
  }

  @Test fun marksOverspendWithoutClampingAccountingValue() {
    val result = calculateBudgetProgress(
      "b1", "food", "BDT", 1_000, 0, 10,
      listOf(BudgetExpenseRecord("food", "BDT", "EXPENSE", 1_500, 5)),
    )
    assertEquals(1_500L, result.spentMinorUnits)
    assertEquals(-500L, result.remainingMinorUnits)
    assertTrue(result.isOverBudget)
  }

  @Test(expected = ArithmeticException::class)
  fun rejectsOverflow() {
    calculateBudgetProgress("b1", "food", "BDT", Long.MAX_VALUE, 0, 10, listOf(
      BudgetExpenseRecord("food", "BDT", "EXPENSE", Long.MAX_VALUE, 1),
      BudgetExpenseRecord("food", "BDT", "EXPENSE", 1, 2),
    ))
  }
}
